import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, AlertTriangle, Info } from "lucide-react";
import { getProfile, listenProfile, type Profile } from "./db";
import { sfx } from "./lib/sounds";

/* ================= auth ================= */

type AuthCtx = {
  user: Profile | null;
  ready: boolean;
  signIn: (p: Profile) => void;
  signOut: () => void;
  refresh: () => Promise<void>;
};

const AuthContext = createContext<AuthCtx>({
  user: null,
  ready: false,
  signIn: () => undefined,
  signOut: () => undefined,
  refresh: async () => undefined,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<Profile | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let alive = true;
    const saved = localStorage.getItem("bg_session");
    if (!saved) {
      setReady(true);
      return;
    }
    getProfile(saved)
      .then((p) => {
        if (alive) setUser(p);
        if (alive && !p) localStorage.removeItem("bg_session");
      })
      .catch(() => undefined)
      .finally(() => alive && setReady(true));
    return () => {
      alive = false;
    };
  }, []);

  // живые обновления своего профиля: бан, роль, правки из других вкладок
  useEffect(() => {
    if (!user?.uid) return;
    return listenProfile(user.uid, (p) => {
      if (p) setUser(p);
    });
  }, [user?.uid]);

  const signIn = useCallback((p: Profile) => {
    localStorage.setItem("bg_session", p.uid);
    setUser(p);
  }, []);

  const signOut = useCallback(() => {
    localStorage.removeItem("bg_session");
    setUser(null);
  }, []);

  const refresh = useCallback(async () => {
    const saved = localStorage.getItem("bg_session");
    if (!saved) return;
    const p = await getProfile(saved).catch(() => null);
    if (p) setUser(p);
  }, []);

  return (
    <AuthContext.Provider value={{ user, ready, signIn, signOut, refresh }}>{children}</AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

/* ================= toasts ================= */

type ToastKind = "ok" | "err" | "info";
type ToastItem = { id: number; msg: string; kind: ToastKind };

type ToastCtx = { toast: (msg: string, kind?: ToastKind) => void };

const ToastContext = createContext<ToastCtx>({ toast: () => undefined });

let toastId = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const timers = useRef<number[]>([]);

  const toast = useCallback((msg: string, kind: ToastKind = "info") => {
    const id = ++toastId;
    setItems((prev) => [...prev.slice(-3), { id, msg, kind }]);
    if (kind === "ok") sfx.success();
    if (kind === "err") sfx.error();
    const t = window.setTimeout(() => {
      setItems((prev) => prev.filter((x) => x.id !== id));
    }, 3600);
    timers.current.push(t);
  }, []);

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="pointer-events-none fixed left-1/2 top-5 z-[100] flex w-[min(92vw,420px)] -translate-x-1/2 flex-col items-center gap-2">
        <AnimatePresence>
          {items.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -16, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.94 }}
              transition={{ type: "spring", stiffness: 420, damping: 30 }}
              className={`pointer-events-auto flex w-full items-center gap-3 rounded-2xl border px-4 py-3 shadow-warm backdrop-blur-xl ${
                t.kind === "ok"
                  ? "border-emerald-200/80 bg-white/90 text-emerald-900"
                  : t.kind === "err"
                    ? "border-red-200/80 bg-white/90 text-red-900"
                    : "border-orange-200/80 bg-white/90 text-cocoa"
              }`}
            >
              {t.kind === "ok" ? (
                <CheckCircle2 size={18} className="shrink-0 text-emerald-500" />
              ) : t.kind === "err" ? (
                <AlertTriangle size={18} className="shrink-0 text-red-500" />
              ) : (
                <Info size={18} className="shrink-0 text-orange-500" />
              )}
              <span className="text-sm font-medium leading-snug">{t.msg}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  return useContext(ToastContext);
}
