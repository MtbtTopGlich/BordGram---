import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { sfx } from "./sounds";

export type ThemeId = "cream" | "sand" | "dim" | "night" | "cocoa";

export type Prefs = {
  accent: string;
  theme: ThemeId;
  wallpaper: WallpaperId;
  radius: number;
  fontScale: number;
  motion: boolean;
  density: "cozy" | "compact";
  enterToSend: boolean;
  volume: number;
};

/** Палитры фона — подобраны так, чтобы не слепить глаза */
export const THEMES: Array<{
  id: ThemeId;
  name: string;
  hint: string;
  dark: boolean;
  swatch: string;
  vars: Record<string, string>;
}> = [
  {
    id: "cream",
    name: "Кремовая",
    hint: "светлая, по умолчанию",
    dark: false,
    swatch: "#fff4e9",
    vars: {
      "--color-cream": "#fff4e9",
      "--color-cream-2": "#ffe9d6",
      "--color-cocoa": "#3a2113",
      "--color-cocoa-soft": "#a1734f",
      "--surface": "#ffffff",
      "--surface-soft": "rgba(255,255,255,0.72)",
      "--line": "rgba(255,170,100,0.28)",
      "--blob": "0.5",
    },
  },
  {
    id: "sand",
    name: "Песочная",
    hint: "мягче для глаз днём",
    dark: false,
    swatch: "#f5ece0",
    vars: {
      "--color-cream": "#f4ebdf",
      "--color-cream-2": "#ece0d0",
      "--color-cocoa": "#3b2a1c",
      "--color-cocoa-soft": "#8d7259",
      "--surface": "#fbf6ef",
      "--surface-soft": "rgba(251,246,239,0.78)",
      "--line": "rgba(190,150,110,0.26)",
      "--blob": "0.32",
    },
  },
  {
    id: "dim",
    name: "Приглушённая",
    hint: "тёмная, мягкий контраст",
    dark: true,
    swatch: "#2a2520",
    vars: {
      "--color-cream": "#262220",
      "--color-cream-2": "#2f2a26",
      "--color-cocoa": "#ece4dc",
      "--color-cocoa-soft": "#a99c90",
      "--surface": "#322c28",
      "--surface-soft": "rgba(50,44,40,0.82)",
      "--line": "rgba(255,180,120,0.14)",
      "--blob": "0.2",
    },
  },
  {
    id: "night",
    name: "Ночная",
    hint: "тёмная, глубокая",
    dark: true,
    swatch: "#16181d",
    vars: {
      "--color-cream": "#15171c",
      "--color-cream-2": "#1c1f25",
      "--color-cocoa": "#e6e8ec",
      "--color-cocoa-soft": "#949aa6",
      "--surface": "#1f232a",
      "--surface-soft": "rgba(31,35,42,0.84)",
      "--line": "rgba(255,255,255,0.09)",
      "--blob": "0.16",
    },
  },
  {
    id: "cocoa",
    name: "Какао",
    hint: "тёмно-тёплая",
    dark: true,
    swatch: "#231713",
    vars: {
      "--color-cream": "#201512",
      "--color-cream-2": "#2a1c17",
      "--color-cocoa": "#f0e2d8",
      "--color-cocoa-soft": "#b08f79",
      "--surface": "#2c1e19",
      "--surface-soft": "rgba(44,30,25,0.84)",
      "--line": "rgba(255,170,110,0.16)",
      "--blob": "0.24",
    },
  },
];

export type WallpaperId = "none" | "dots" | "grid" | "waves" | "sunset";

export const ACCENTS: Array<{ id: string; name: string; hex: string }> = [
  { id: "orange", name: "Апельсин", hex: "#FF6A00" },
  { id: "amber", name: "Мёд", hex: "#F59E0B" },
  { id: "rose", name: "Закат", hex: "#F43F5E" },
  { id: "violet", name: "Лаванда", hex: "#8B5CF6" },
  { id: "ocean", name: "Океан", hex: "#0EA5E9" },
  { id: "mint", name: "Мята", hex: "#10B981" },
  { id: "cherry", name: "Вишня", hex: "#DC2626" },
  { id: "graphite", name: "Графит", hex: "#64748B" },
];

export const WALLPAPERS: Array<{ id: WallpaperId; name: string }> = [
  { id: "none", name: "Чистый" },
  { id: "dots", name: "Точки" },
  { id: "grid", name: "Сетка" },
  { id: "waves", name: "Волны" },
  { id: "sunset", name: "Градиент" },
];

export const DEFAULT_PREFS: Prefs = {
  accent: "#FF6A00",
  theme: "cream",
  wallpaper: "dots",
  radius: 24,
  fontScale: 1,
  motion: true,
  density: "cozy",
  enterToSend: true,
  volume: 1,
};

const KEY = "bg_prefs_v1";

function load(): Prefs {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_PREFS, volume: sfx.volume };
    return { ...DEFAULT_PREFS, ...(JSON.parse(raw) as Partial<Prefs>) };
  } catch {
    return DEFAULT_PREFS;
  }
}

/** Строит палитру 50..900 от любого hex через color-mix */
function applyAccent(hex: string) {
  const root = document.documentElement.style;
  const mixW = (p: number) => `color-mix(in oklab, ${hex} ${p}%, white)`;
  const mixB = (p: number) => `color-mix(in oklab, ${hex} ${p}%, black)`;
  const ramp: Array<[string, string]> = [
    ["50", mixW(7)],
    ["100", mixW(15)],
    ["200", mixW(28)],
    ["300", mixW(45)],
    ["400", mixW(70)],
    ["500", hex],
    ["600", mixB(88)],
    ["700", mixB(74)],
    ["800", mixB(60)],
    ["900", mixB(48)],
  ];
  for (const [k, v] of ramp) root.setProperty(`--color-orange-${k}`, v);
  // амбер используется в градиентах — делаем его светлым спутником акцента
  const amber: Array<[string, string]> = [
    ["100", mixW(18)],
    ["200", mixW(30)],
    ["300", mixW(48)],
    ["400", mixW(72)],
    ["500", mixW(88)],
  ];
  for (const [k, v] of amber) root.setProperty(`--color-amber-${k}`, v);

  root.setProperty("--color-brand", hex);
  root.setProperty("--accent", hex);
  root.setProperty("--shadow-orangeSoft", `0 6px 18px color-mix(in srgb, ${hex} 32%, transparent)`);
  root.setProperty("--shadow-orangeGlow", `0 8px 26px color-mix(in srgb, ${hex} 36%, transparent)`);
  root.setProperty("--shadow-orangeGlowBig", `0 14px 38px color-mix(in srgb, ${hex} 46%, transparent)`);
  root.setProperty("--shadow-warm", `0 4px 18px color-mix(in srgb, ${hex} 14%, transparent)`);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", hex);
}

function applyTheme(id: ThemeId) {
  const t = THEMES.find((x) => x.id === id) ?? THEMES[0];
  const root = document.documentElement;
  Object.entries(t.vars).forEach(([k, v]) => root.style.setProperty(k, v));
  root.dataset.theme = t.id;
  root.dataset.dark = t.dark ? "1" : "0";
  root.style.colorScheme = t.dark ? "dark" : "light";
}

function applyAll(p: Prefs) {
  const root = document.documentElement;
  applyTheme(p.theme);
  applyAccent(p.accent);
  root.style.setProperty("--bubble-radius", `${p.radius}px`);
  root.style.fontSize = `${16 * p.fontScale}px`;
  root.dataset.wallpaper = p.wallpaper;
  root.dataset.density = p.density;
  root.classList.toggle("no-anim", !p.motion);
  sfx.setVolume(p.volume);
}

type Ctx = {
  prefs: Prefs;
  setPref: <K extends keyof Prefs>(k: K, v: Prefs[K]) => void;
  reset: () => void;
};

const PrefsContext = createContext<Ctx>({ prefs: DEFAULT_PREFS, setPref: () => undefined, reset: () => undefined });

export function PrefsProvider({ children }: { children: ReactNode }) {
  const [prefs, setPrefs] = useState<Prefs>(() => load());

  useEffect(() => {
    applyAll(prefs);
    try {
      localStorage.setItem(KEY, JSON.stringify(prefs));
    } catch {
      /* noop */
    }
  }, [prefs]);

  const value = useMemo<Ctx>(
    () => ({
      prefs,
      setPref: (k, v) => setPrefs((p) => ({ ...p, [k]: v })),
      reset: () => setPrefs({ ...DEFAULT_PREFS }),
    }),
    [prefs]
  );

  return <PrefsContext.Provider value={value}>{children}</PrefsContext.Provider>;
}

export function usePrefs() {
  return useContext(PrefsContext);
}
