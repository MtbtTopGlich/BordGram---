/* Сохранение выбранных устройств ввода (микрофон / веб-камера) */

const KEYS = { mic: "bg_mic_device", cam: "bg_cam_device" } as const;

export type DeviceKind = keyof typeof KEYS;

export function getSavedDeviceId(kind: DeviceKind): string {
  try {
    return localStorage.getItem(KEYS[kind]) ?? "";
  } catch {
    return "";
  }
}

export function saveDeviceId(kind: DeviceKind, id: string): void {
  try {
    localStorage.setItem(KEYS[kind], id);
  } catch {
    /* noop */
  }
}

export function mediaDevicesSupported(): boolean {
  return typeof navigator !== "undefined" && !!navigator.mediaDevices?.enumerateDevices;
}

export async function listInputDevices(): Promise<{ mics: MediaDeviceInfo[]; cams: MediaDeviceInfo[] }> {
  try {
    const all = await navigator.mediaDevices.enumerateDevices();
    return {
      mics: all.filter((d) => d.kind === "audioinput"),
      cams: all.filter((d) => d.kind === "videoinput"),
    };
  } catch {
    return { mics: [], cams: [] };
  }
}
