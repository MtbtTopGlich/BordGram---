import { initializeApp } from "firebase/app";
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  type Firestore,
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAw9GuyOnjU40qgePrJJGy7UTOE9viVkFw",
  authDomain: "bordgram1.firebaseapp.com",
  projectId: "bordgram1",
  storageBucket: "bordgram1.firebasestorage.app",
  messagingSenderId: "986920979240",
  appId: "1:986920979240:web:773cda48baa604244c9e1d",
  measurementId: "G-DSGPXDZYYH",
};

export const app = initializeApp(firebaseConfig);

/**
 * Локальный кеш + синхронизация между вкладками:
 * данные появляются мгновенно и переживают обрыв сети без перезагрузки.
 */
function createDb(): Firestore {
  try {
    return initializeFirestore(app, {
      localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    });
  } catch {
    return initializeFirestore(app, {});
  }
}

export const db = createDb();
