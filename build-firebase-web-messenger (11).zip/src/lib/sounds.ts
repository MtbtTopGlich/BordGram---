/*
 * Мягкий WebAudio ASMR-звуковой движок.
 * Все звуки синтезируются — никаких внешних файлов.
 */

type ToneOpts = {
  from: number;
  to?: number;
  dur?: number;
  type?: OscillatorType;
  gain?: number;
  delay?: number;
};

class SfxEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  enabled: boolean;
  /** 0..1.5 — пользовательская громкость */
  volume: number;

  constructor() {
    this.enabled = typeof localStorage !== "undefined" ? localStorage.getItem("bg_sfx") !== "0" : true;
    const saved = typeof localStorage !== "undefined" ? Number(localStorage.getItem("bg_sfx_vol")) : NaN;
    this.volume = Number.isFinite(saved) && saved > 0 ? saved : 1;
  }

  setEnabled(v: boolean) {
    this.enabled = v;
    try {
      localStorage.setItem("bg_sfx", v ? "1" : "0");
    } catch {
      /* noop */
    }
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1.6, v));
    if (this.master) this.master.gain.value = 0.62 * this.volume;
    try {
      localStorage.setItem("bg_sfx_vol", String(this.volume));
    } catch {
      /* noop */
    }
  }

  private ensure(): AudioContext | null {
    if (!this.enabled) return null;
    try {
      if (!this.ctx) {
        const AC: typeof AudioContext | undefined =
          window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AC) return null;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.62 * this.volume;
        // Тёплый фильтр — срезает резкости, звук «бархатный»
        const lp = this.ctx.createBiquadFilter();
        lp.type = "lowpass";
        lp.frequency.value = 6200;
        this.master.connect(lp);
        lp.connect(this.ctx.destination);
      }
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return this.ctx;
    } catch {
      return null;
    }
  }

  private tone(o: ToneOpts) {
    const ctx = this.ensure();
    if (!ctx || !this.master) return;
    const t0 = ctx.currentTime + (o.delay ?? 0);
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = o.type ?? "sine";
    osc.frequency.setValueAtTime(o.from, t0);
    if (o.to) osc.frequency.exponentialRampToValueAtTime(Math.max(o.to, 1), t0 + (o.dur ?? 0.15));
    const peak = o.gain ?? 0.35;
    const dur = o.dur ?? 0.15;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(peak, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g);
    g.connect(this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  private getNoise(ctx: AudioContext): AudioBuffer {
    if (!this.noiseBuf) {
      const len = ctx.sampleRate * 0.4;
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 1.6);
      this.noiseBuf = buf;
    }
    return this.noiseBuf;
  }

  private whoosh(gain = 0.1, freq = 900, dur = 0.28) {
    const ctx = this.ensure();
    if (!ctx || !this.master) return;
    const t0 = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.getNoise(ctx);
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.Q.value = 1.1;
    bp.frequency.setValueAtTime(freq * 0.5, t0);
    bp.frequency.exponentialRampToValueAtTime(freq * 1.8, t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.04);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(bp);
    bp.connect(g);
    g.connect(this.master);
    src.start(t0);
    src.stop(t0 + dur + 0.02);
  }

  /** Мягкий клик — наведение/нажатие на кнопки */
  click() {
    this.tone({ from: 620, to: 340, dur: 0.09, gain: 0.16 });
  }

  /** Тик переключателя */
  tick() {
    this.tone({ from: 900, to: 700, dur: 0.05, gain: 0.12, type: "triangle" });
  }

  /** Отправка сообщения — лёгкий взмывающий «блup» */
  send() {
    this.tone({ from: 520, to: 940, dur: 0.13, gain: 0.2 });
    this.tone({ from: 1250, to: 1500, dur: 0.07, gain: 0.08, delay: 0.07 });
  }

  /** Входящее сообщение — тёплый «поп» */
  receive() {
    this.tone({ from: 880, to: 520, dur: 0.16, gain: 0.2 });
    this.tone({ from: 660, to: 440, dur: 0.12, gain: 0.1, delay: 0.05 });
  }

  /** Открытие чата / панели — шелест */
  open() {
    this.whoosh(0.07, 700, 0.22);
  }

  /** Закрытие */
  close() {
    this.whoosh(0.05, 420, 0.18);
  }

  /** Успех — тёплый бубенчик */
  success() {
    this.tone({ from: 523, dur: 0.12, gain: 0.16 });
    this.tone({ from: 659, dur: 0.12, gain: 0.15, delay: 0.09 });
    this.tone({ from: 784, dur: 0.2, gain: 0.15, delay: 0.18 });
  }

  /** Ошибка — глухое ворчание */
  error() {
    this.tone({ from: 210, to: 140, dur: 0.24, gain: 0.18, type: "triangle" });
  }

  /** Новая заявка / уведомление */
  notify() {
    this.tone({ from: 740, to: 990, dur: 0.1, gain: 0.16 });
    this.tone({ from: 990, dur: 0.22, gain: 0.13, delay: 0.1 });
  }

  /** Набор текста в поле кода */
  key() {
    this.tone({ from: 700 + Math.random() * 120, dur: 0.035, gain: 0.07 });
  }
}

export const sfx = new SfxEngine();
