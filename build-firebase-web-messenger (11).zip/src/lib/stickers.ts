import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  limit as qLimit,
  type Unsubscribe,
} from "firebase/firestore";
import { db } from "./firebase";

export type StickerPack = {
  id: string;
  title: string;
  ownerUid: string;
  ownerName: string;
  ownerUsername: string;
  cover?: string;
  count?: number;
  createdAt?: unknown;
};

export type Sticker = {
  id: string;
  packId: string;
  packTitle?: string;
  emoji: string;
  image: string;
  ownerUid: string;
  createdAt?: unknown;
};

/* ================= паки ================= */

export async function createPack(input: {
  title: string;
  ownerUid: string;
  ownerName: string;
  ownerUsername: string;
}): Promise<string> {
  const ref = await addDoc(collection(db, "stickerPacks"), {
    title: input.title,
    ownerUid: input.ownerUid,
    ownerName: input.ownerName,
    ownerUsername: input.ownerUsername,
    cover: "",
    count: 0,
    createdAt: serverTimestamp(),
  });
  // автор сразу подписан на свой пак
  await addPackToLibrary(input.ownerUid, ref.id);
  return ref.id;
}

export async function getPack(packId: string): Promise<StickerPack | null> {
  const snap = await getDoc(doc(db, "stickerPacks", packId));
  return snap.exists() ? ({ ...(snap.data() as object), id: snap.id } as StickerPack) : null;
}

export async function deletePack(packId: string): Promise<void> {
  // сами стикеры
  const items = await getDocs(collection(db, "stickerPacks", packId, "stickers"));
  await Promise.all(items.docs.map((d) => deleteDoc(d.ref).catch(() => undefined)));
  // записи в поисковом индексе
  try {
    const idx = await getDocs(query(collection(db, "stickersIndex"), where("packId", "==", packId)));
    await Promise.all(idx.docs.map((d) => deleteDoc(d.ref).catch(() => undefined)));
  } catch {
    /* best-effort */
  }
  await deleteDoc(doc(db, "stickerPacks", packId)).catch(() => undefined);
}

/** Убрать пак из библиотек всех, кто его добавил (для своих подписок) */
export async function forgetPackLocally(uid: string, packId: string): Promise<void> {
  await deleteDoc(doc(db, "users", uid, "stickerLibrary", packId)).catch(() => undefined);
}

/** Мои созданные паки */
export function listenMyPacks(uid: string, cb: (packs: StickerPack[]) => void): Unsubscribe {
  return onSnapshot(
    query(collection(db, "stickerPacks"), where("ownerUid", "==", uid)),
    (snap) => cb(snap.docs.map((d) => ({ ...(d.data() as object), id: d.id } as StickerPack))),
    () => cb([])
  );
}

/* ================= библиотека (добавленные паки) ================= */

export function listenLibrary(uid: string, cb: (packIds: string[]) => void): Unsubscribe {
  return onSnapshot(
    collection(db, "users", uid, "stickerLibrary"),
    (snap) => cb(snap.docs.map((d) => d.id)),
    () => cb([])
  );
}

export async function addPackToLibrary(uid: string, packId: string): Promise<void> {
  await setDoc(doc(db, "users", uid, "stickerLibrary", packId), { at: serverTimestamp() });
}

export async function removePackFromLibrary(uid: string, packId: string): Promise<void> {
  await deleteDoc(doc(db, "users", uid, "stickerLibrary", packId)).catch(() => undefined);
}

/* ================= стикеры ================= */

export function listenPackStickers(packId: string, cb: (items: Sticker[]) => void): Unsubscribe {
  return onSnapshot(
    collection(db, "stickerPacks", packId, "stickers"),
    (snap) => {
      const items = snap.docs.map((d) => ({ ...(d.data() as object), id: d.id, packId } as Sticker));
      items.sort((a, b) => {
        const ta = (a.createdAt as { seconds?: number } | undefined)?.seconds ?? 0;
        const tb = (b.createdAt as { seconds?: number } | undefined)?.seconds ?? 0;
        return ta - tb;
      });
      cb(items);
    },
    () => cb([])
  );
}

export async function getPackStickers(packId: string): Promise<Sticker[]> {
  const snap = await getDocs(collection(db, "stickerPacks", packId, "stickers"));
  return snap.docs.map((d) => ({ ...(d.data() as object), id: d.id, packId } as Sticker));
}

export async function addSticker(input: {
  packId: string;
  packTitle: string;
  emoji: string;
  image: string;
  ownerUid: string;
}): Promise<void> {
  // создаём ссылку заранее — так индекс получает тот же id и его легко удалить
  const ref = doc(collection(db, "stickerPacks", input.packId, "stickers"));
  await setDoc(ref, {
    emoji: input.emoji,
    image: input.image,
    ownerUid: input.ownerUid,
    packTitle: input.packTitle,
    createdAt: serverTimestamp(),
  });
  // зеркало для быстрого поиска по эмодзи
  await setDoc(doc(db, "stickersIndex", `${input.packId}_${ref.id}`), {
    emoji: input.emoji,
    image: input.image,
    packId: input.packId,
    stickerId: ref.id,
    packTitle: input.packTitle,
    ownerUid: input.ownerUid,
    createdAt: serverTimestamp(),
  }).catch(() => undefined);

  const packRef = doc(db, "stickerPacks", input.packId);
  const cur = await getDoc(packRef);
  const count = ((cur.data() as { count?: number } | undefined)?.count ?? 0) + 1;
  const cover = (cur.data() as { cover?: string } | undefined)?.cover;
  await updateDoc(packRef, { count, ...(cover ? {} : { cover: input.image }) }).catch(() => undefined);
}

export async function deleteSticker(packId: string, stickerId: string): Promise<void> {
  await deleteDoc(doc(db, "stickerPacks", packId, "stickers", stickerId)).catch(() => undefined);
  // чистим индекс, чтобы стикер пропал из подсказок по эмодзи
  await deleteDoc(doc(db, "stickersIndex", `${packId}_${stickerId}`)).catch(() => undefined);

  const packRef = doc(db, "stickerPacks", packId);
  const cur = await getDoc(packRef);
  const data = cur.data() as { count?: number; cover?: string } | undefined;
  const rest = await getDocs(collection(db, "stickerPacks", packId, "stickers"));
  const nextCover = rest.docs[0]?.get("image") ?? "";
  await updateDoc(packRef, {
    count: Math.max(0, rest.size),
    // если удалили обложку — ставим следующий стикер
    ...(data?.cover && rest.docs.every((d) => d.get("image") !== data.cover) ? { cover: nextCover } : {}),
  }).catch(() => undefined);
}

/** Поиск стикеров по эмодзи — 5 случайных из всех паков */
export async function findStickersByEmoji(emoji: string, take = 5): Promise<Sticker[]> {
  try {
    const snap = await getDocs(
      query(collection(db, "stickersIndex"), where("emoji", "==", emoji), qLimit(40))
    );
    const all = snap.docs.map((d) => ({ ...(d.data() as object), id: d.id } as Sticker));
    // перемешиваем и берём нужное количество
    for (let i = all.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [all[i], all[j]] = [all[j], all[i]];
    }
    return all.slice(0, take);
  } catch {
    return [];
  }
}

/* ================= подготовка картинки ================= */

/** Приводит изображение к квадрату 512×512 с прозрачным фоном (PNG) */
export function fileToSticker(file: File, size = 512): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("not image"));
      return;
    }
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        URL.revokeObjectURL(url);
        reject(new Error("no ctx"));
        return;
      }
      // вписываем целиком, сохраняя пропорции
      const scale = Math.min(size / img.width, size / img.height);
      const w = img.width * scale;
      const h = img.height * scale;
      ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
      URL.revokeObjectURL(url);
      let out = canvas.toDataURL("image/png");
      if (out.length > 900_000) out = canvas.toDataURL("image/webp", 0.92);
      if (out.length > 900_000) out = canvas.toDataURL("image/webp", 0.8);
      if (out.length > 900_000) {
        reject(new Error("too big"));
        return;
      }
      resolve(out);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("bad image"));
    };
    img.src = url;
  });
}

/** Эмодзи для выбора под стикер */
export const EMOJI_CHOICES = [
  "😀", "😂", "🥰", "😎", "🤔", "😴", "😭", "😡",
  "👍", "👎", "👋", "🙏", "💪", "🔥", "❤️", "💔",
  "🎉", "🎁", "⭐", "✨", "💯", "👀", "🤝", "🫡",
  "🐱", "🐶", "🦊", "🐻", "🍕", "☕", "🌙", "☀️",
];

/** Берём первое эмодзи из текста (если сообщение — только эмодзи) */
export function extractSoloEmoji(text: string): string | null {
  const t = text.trim();
  if (!t || t.length > 8) return null;
  const re = /\p{Extended_Pictographic}/u;
  if (!re.test(t)) return null;
  const chars = Array.from(t).filter((c) => c.trim().length > 0);
  const onlyEmoji = chars.every((c) => re.test(c) || /[\u200d\ufe0f\u{1f3fb}-\u{1f3ff}]/u.test(c));
  if (!onlyEmoji) return null;
  const match = t.match(/\p{Extended_Pictographic}(\u200d\p{Extended_Pictographic})*\ufe0f?/u);
  return match ? match[0] : null;
}
