import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  onSnapshot,
  serverTimestamp,
  setDoc,
  type Unsubscribe,
} from "firebase/firestore";
import { db } from "./firebase";

/** Детерминированный id пары — одинаковый у обоих участников */
export function pairId(a: string, b: string): string {
  return [a, b].sort().join("__");
}

/** «Вежливая» сторона — та, чей uid больше: разруливает коллизии offer-ов */
export function isPolite(me: string, other: string): boolean {
  return me > other;
}

const pairRef = (gid: string, pid: string) => collection(db, "groups", gid, "rtc", pid, "signals");

export type Signal =
  | { kind: "desc"; from: string; type: "offer" | "answer"; sdp: string; at: number }
  | { kind: "ice"; from: string; candidate: string; sdpMid: string | null; sdpMLineIndex: number | null };

export async function sendDesc(
  gid: string,
  pid: string,
  from: string,
  desc: RTCSessionDescription | null
): Promise<void> {
  if (!desc) return;
  await setDoc(doc(db, "groups", gid, "rtc", pid, "signals", `desc_${from}`), {
    kind: "desc",
    from,
    type: desc.type,
    sdp: desc.sdp ?? "",
    at: Date.now(),
  });
}

export async function sendIce(
  gid: string,
  pid: string,
  from: string,
  c: RTCIceCandidateInit
): Promise<void> {
  await addDoc(pairRef(gid, pid), {
    kind: "ice",
    from,
    candidate: c.candidate ?? "",
    sdpMid: c.sdpMid ?? null,
    sdpMLineIndex: c.sdpMLineIndex ?? null,
    at: serverTimestamp(),
  }).catch(() => undefined);
}

export function listenPair(
  gid: string,
  pid: string,
  myUid: string,
  onDesc: (d: { type: "offer" | "answer"; sdp: string; at: number }) => void,
  onIce: (c: RTCIceCandidateInit) => void
): Unsubscribe {
  return onSnapshot(
    pairRef(gid, pid),
    (snap) => {
      snap.docChanges().forEach((ch) => {
        if (ch.type !== "added" && ch.type !== "modified") return;
        const d = ch.doc.data() as Signal;
        if (d.from === myUid) return;
        if (d.kind === "desc") onDesc({ type: d.type, sdp: d.sdp, at: d.at });
        else if (d.candidate) {
          onIce({ candidate: d.candidate, sdpMid: d.sdpMid, sdpMLineIndex: d.sdpMLineIndex });
        }
      });
    },
    () => undefined
  );
}

/** Чистим сигналы пары, когда выходим из звонка */
export async function clearPair(gid: string, pid: string): Promise<void> {
  try {
    const snap = await getDocs(pairRef(gid, pid));
    await Promise.all(snap.docs.map((d) => deleteDoc(d.ref).catch(() => undefined)));
  } catch {
    /* best-effort */
  }
}
