import { useEffect, useRef, useState } from "react";
import type { Unsubscribe } from "firebase/firestore";
import { listenChatDoc, listenPresence, listenProfile, touchPresence, type ContactDoc } from "../db";
import { chatIdOf } from "./utils";

export const ONLINE_WINDOW = 65_000;

/** Я в сети: сердцебиение, пока вкладка открыта */
export function usePresenceHeartbeat(uid: string | undefined) {
  useEffect(() => {
    if (!uid) return;
    let alive = true;
    const beat = () => {
      if (!alive || document.visibilityState === "hidden") return;
      void touchPresence(uid).catch(() => undefined);
    };
    beat();
    const id = window.setInterval(beat, 25_000);
    document.addEventListener("visibilitychange", beat);
    window.addEventListener("focus", beat);
    return () => {
      alive = false;
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", beat);
      window.removeEventListener("focus", beat);
    };
  }, [uid]);
}

/** Онлайн ли конкретный пользователь (живое обновление + тик времени) */
export function usePeerOnline(uid: string | null | undefined) {
  const [lastSeen, setLastSeen] = useState(0);
  const [, force] = useState(0);

  useEffect(() => {
    if (!uid) {
      setLastSeen(0);
      return;
    }
    return listenPresence(uid, setLastSeen);
  }, [uid]);

  useEffect(() => {
    const id = window.setInterval(() => force((n) => n + 1), 15_000);
    return () => window.clearInterval(id);
  }, []);

  return { online: lastSeen > 0 && Date.now() - lastSeen < ONLINE_WINDOW, lastSeen };
}

/**
 * Живая сводка по всем чатам контактов:
 * непрочитанные, кто онлайн, свежие ник/аватар — без перезагрузки.
 */
export function useLiveContacts(myUid: string | undefined, contacts: ContactDoc[]) {
  const [unread, setUnread] = useState<Record<string, boolean>>({});
  const [online, setOnline] = useState<Record<string, number>>({});
  const [fresh, setFresh] = useState<Record<string, { nickname: string; avatar: string }>>({});
  const [, force] = useState(0);
  const subs = useRef<Map<string, Unsubscribe[]>>(new Map());

  const ids = contacts.map((c) => c.uid).sort().join(",");

  useEffect(() => {
    if (!myUid) return;
    const wanted = new Set(contacts.map((c) => c.uid));

    // отписываемся от ушедших
    for (const [uid, fns] of subs.current) {
      if (!wanted.has(uid)) {
        fns.forEach((f) => f());
        subs.current.delete(uid);
      }
    }

    // подписываемся на новых
    for (const uid of wanted) {
      if (subs.current.has(uid)) continue;
      const chatId = chatIdOf(myUid, uid);
      const fns: Unsubscribe[] = [
        listenChatDoc(chatId, (d) => {
          const lastAt = d.lastAt?.seconds ?? 0;
          const mine = d.lastFrom === myUid;
          const myRead = d.reads?.[myUid]?.seconds ?? 0;
          setUnread((p) => ({ ...p, [uid]: !mine && lastAt > 0 && lastAt > myRead }));
        }),
        listenPresence(uid, (ms) => setOnline((p) => ({ ...p, [uid]: ms }))),
        listenProfile(uid, (p) => {
          if (p) setFresh((prev) => ({ ...prev, [uid]: { nickname: p.nickname, avatar: p.avatar } }));
        }),
      ];
      subs.current.set(uid, fns);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [myUid, ids]);

  // размонтирование
  useEffect(() => {
    const map = subs.current;
    return () => {
      for (const fns of map.values()) fns.forEach((f) => f());
      map.clear();
    };
  }, []);

  // пересчёт «онлайн» по времени
  useEffect(() => {
    const id = window.setInterval(() => force((n) => n + 1), 15_000);
    return () => window.clearInterval(id);
  }, []);

  const now = Date.now();
  const isOnline = (uid: string) => {
    const ms = online[uid] ?? 0;
    return ms > 0 && now - ms < ONLINE_WINDOW;
  };

  return { unread, isOnline, fresh, unreadTotal: Object.values(unread).filter(Boolean).length };
}

/** Статус сети браузера — показываем плашку без перезагрузки */
export function useNetworkStatus() {
  const [online, setOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);
  useEffect(() => {
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, []);
  return online;
}
