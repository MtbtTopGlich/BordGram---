import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limitToLast,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
  type Unsubscribe,
} from "firebase/firestore";
import { db } from "./firebase";
import type { Message, MessageType, Profile, ReplyInfo } from "../db";

export type GroupRole = "owner" | "admin" | "member";

export type Group = {
  id: string;
  title: string;
  bio: string;
  avatar: string;
  ownerUid: string;
  invite: string;
  members: string[];
  createdAt?: unknown;
  lastAt?: unknown;
  lastSnippet?: string;
  lastFrom?: string;
  lastFromName?: string;
};

export type GroupMember = {
  uid: string;
  nickname: string;
  usernameDisplay: string;
  avatar: string;
  role: GroupRole;
  joinedAt?: unknown;
};

const groupRef = (id: string) => doc(db, "groups", id);
const memberRef = (gid: string, uid: string) => doc(db, "groups", gid, "members", uid);

export function canManage(role: GroupRole | undefined): boolean {
  return role === "owner" || role === "admin";
}

export function normalizeInvite(raw: string): string {
  return raw.trim().replace(/^.*\/join\//, "").replace(/[^a-zA-Z0-9_-]/g, "").toLowerCase();
}

export function isValidInvite(code: string): boolean {
  return /^[a-z0-9_-]{4,32}$/.test(code);
}

export async function inviteTaken(code: string): Promise<boolean> {
  const snap = await getDoc(doc(db, "groupInvites", code));
  return snap.exists();
}

/* ================= создание ================= */

export async function createGroup(input: {
  title: string;
  bio: string;
  avatar: string;
  invite: string;
  owner: Profile;
  memberProfiles: Array<Pick<Profile, "uid" | "nickname" | "usernameDisplay" | "avatar">>;
}): Promise<string> {
  const gid = doc(collection(db, "groups")).id;
  const batch = writeBatch(db);
  const now = serverTimestamp();
  const uids = [input.owner.uid, ...input.memberProfiles.map((m) => m.uid)];

  batch.set(groupRef(gid), {
    title: input.title,
    bio: input.bio,
    avatar: input.avatar,
    ownerUid: input.owner.uid,
    invite: input.invite,
    members: uids,
    createdAt: now,
    lastAt: now,
    lastSnippet: "Группа создана",
  } satisfies Omit<Group, "id">);

  batch.set(memberRef(gid, input.owner.uid), {
    uid: input.owner.uid,
    nickname: input.owner.nickname,
    usernameDisplay: input.owner.usernameDisplay,
    avatar: input.owner.avatar,
    role: "owner" as GroupRole,
    joinedAt: now,
  });

  input.memberProfiles.forEach((m) => {
    batch.set(memberRef(gid, m.uid), {
      uid: m.uid,
      nickname: m.nickname,
      usernameDisplay: m.usernameDisplay,
      avatar: m.avatar,
      role: "member" as GroupRole,
      joinedAt: now,
    });
  });

  batch.set(doc(db, "groupInvites", input.invite), { groupId: gid, title: input.title });
  await batch.commit();
  return gid;
}

/* ================= чтение ================= */

export function listenMyGroups(uid: string, cb: (groups: Group[]) => void): Unsubscribe {
  return onSnapshot(
    query(collection(db, "groups"), where("members", "array-contains", uid)),
    (snap) => {
      const items = snap.docs.map((d) => ({ ...(d.data() as object), id: d.id } as Group));
      items.sort((a, b) => {
        const ta = (a.lastAt as { seconds?: number } | undefined)?.seconds ?? 0;
        const tb = (b.lastAt as { seconds?: number } | undefined)?.seconds ?? 0;
        return tb - ta;
      });
      cb(items);
    },
    () => cb([])
  );
}

export function listenGroup(gid: string, cb: (g: Group | null) => void): Unsubscribe {
  return onSnapshot(
    groupRef(gid),
    (snap) => cb(snap.exists() ? ({ ...(snap.data() as object), id: snap.id } as Group) : null),
    () => cb(null)
  );
}

export function listenMembers(gid: string, cb: (m: GroupMember[]) => void): Unsubscribe {
  return onSnapshot(
    collection(db, "groups", gid, "members"),
    (snap) => {
      const items = snap.docs.map((d) => d.data() as GroupMember);
      const order: Record<GroupRole, number> = { owner: 0, admin: 1, member: 2 };
      items.sort((a, b) => order[a.role] - order[b.role] || a.nickname.localeCompare(b.nickname));
      cb(items);
    },
    () => cb([])
  );
}

export async function getGroupByInvite(code: string): Promise<Group | null> {
  const idx = await getDoc(doc(db, "groupInvites", code));
  if (!idx.exists()) return null;
  const { groupId } = idx.data() as { groupId: string };
  const snap = await getDoc(groupRef(groupId));
  return snap.exists() ? ({ ...(snap.data() as object), id: snap.id } as Group) : null;
}

/* ================= участники ================= */

export async function joinGroup(gid: string, p: Profile): Promise<void> {
  const g = await getDoc(groupRef(gid));
  if (!g.exists()) throw new Error("no group");
  const members = ((g.data() as Group).members ?? []) as string[];
  if (!members.includes(p.uid)) {
    await updateDoc(groupRef(gid), { members: [...members, p.uid] });
  }
  await setDoc(
    memberRef(gid, p.uid),
    {
      uid: p.uid,
      nickname: p.nickname,
      usernameDisplay: p.usernameDisplay,
      avatar: p.avatar,
      role: "member" as GroupRole,
      joinedAt: serverTimestamp(),
    },
    { merge: true }
  );
}

export async function addMembers(
  gid: string,
  people: Array<Pick<Profile, "uid" | "nickname" | "usernameDisplay" | "avatar">>
): Promise<void> {
  const g = await getDoc(groupRef(gid));
  if (!g.exists()) return;
  const members = new Set(((g.data() as Group).members ?? []) as string[]);
  const batch = writeBatch(db);
  people.forEach((p) => {
    members.add(p.uid);
    batch.set(
      memberRef(gid, p.uid),
      { ...p, role: "member" as GroupRole, joinedAt: serverTimestamp() },
      { merge: true }
    );
  });
  batch.update(groupRef(gid), { members: Array.from(members) });
  await batch.commit();
}

export async function setMemberRole(gid: string, uid: string, role: GroupRole): Promise<void> {
  await updateDoc(memberRef(gid, uid), { role });
}

export async function removeMember(gid: string, uid: string): Promise<void> {
  const g = await getDoc(groupRef(gid));
  if (!g.exists()) return;
  const members = ((g.data() as Group).members ?? []).filter((m: string) => m !== uid);
  const batch = writeBatch(db);
  batch.update(groupRef(gid), { members });
  batch.delete(memberRef(gid, uid));
  await batch.commit();
}

export async function updateGroup(
  gid: string,
  fields: Partial<Pick<Group, "title" | "bio" | "avatar">>
): Promise<void> {
  await updateDoc(groupRef(gid), fields);
}

export async function deleteGroup(gid: string, invite: string): Promise<void> {
  const members = await getDocs(collection(db, "groups", gid, "members"));
  await Promise.all(members.docs.map((d) => deleteDoc(d.ref).catch(() => undefined)));
  await deleteDoc(doc(db, "groupInvites", invite)).catch(() => undefined);
  await deleteDoc(groupRef(gid)).catch(() => undefined);
}

/* ================= сообщения ================= */

export type GroupMessage = Message & { fromName?: string; fromAvatar?: string };

export function listenGroupMessages(gid: string, cb: (items: GroupMessage[]) => void): Unsubscribe {
  return onSnapshot(
    query(collection(db, "groups", gid, "messages"), orderBy("createdAt", "asc"), limitToLast(300)),
    (snap) => cb(snap.docs.map((d) => ({ ...(d.data() as object), id: d.id } as GroupMessage))),
    () => cb([])
  );
}

export async function sendGroupMessage(
  gid: string,
  author: Profile,
  body: {
    type: MessageType;
    text?: string;
    image?: string;
    audio?: string;
    duration?: number;
    emoji?: string;
    packId?: string;
    replyTo?: ReplyInfo | null;
    callOutcome?: string;
    callKind?: "audio" | "video";
    callDuration?: number;
  }
): Promise<void> {
  const snippet =
    body.type === "image"
      ? "Фотография"
      : body.type === "voice"
        ? "Голосовое сообщение"
        : body.type === "sticker"
          ? `${body.emoji ?? "🙂"} Стикер`
          : body.type === "call"
            ? "Групповой звонок"
            : (body.text ?? "").slice(0, 60);

  await addDoc(collection(db, "groups", gid, "messages"), {
    from: author.uid,
    fromName: author.nickname,
    fromAvatar: author.avatar,
    type: body.type,
    ...(body.text !== undefined ? { text: body.text } : {}),
    ...(body.image ? { image: body.image } : {}),
    ...(body.audio ? { audio: body.audio } : {}),
    ...(body.duration !== undefined ? { duration: body.duration } : {}),
    ...(body.emoji ? { emoji: body.emoji } : {}),
    ...(body.packId ? { packId: body.packId } : {}),
    ...(body.replyTo ? { replyTo: body.replyTo } : {}),
    ...(body.callOutcome ? { callOutcome: body.callOutcome } : {}),
    ...(body.callKind ? { callKind: body.callKind } : {}),
    ...(body.callDuration !== undefined ? { callDuration: body.callDuration } : {}),
    createdAt: serverTimestamp(),
  });

  await updateDoc(groupRef(gid), {
    lastAt: serverTimestamp(),
    lastSnippet: snippet,
    lastFrom: author.uid,
    lastFromName: author.nickname,
  }).catch(() => undefined);
}

export async function editGroupMessage(gid: string, id: string, text: string): Promise<void> {
  await updateDoc(doc(db, "groups", gid, "messages", id), { text, editedAt: serverTimestamp() });
}

export async function deleteGroupMessage(gid: string, id: string): Promise<void> {
  await updateDoc(doc(db, "groups", gid, "messages", id), {
    deleted: true,
    text: "",
    image: "",
    audio: "",
    reactions: {},
  });
}

export async function toggleGroupReaction(
  gid: string,
  id: string,
  uid: string,
  emoji: string
): Promise<void> {
  const ref = doc(db, "groups", gid, "messages", id);
  const snap = await getDoc(ref);
  if (!snap.exists()) return;
  const cur = ((snap.data() as Message).reactions ?? {}) as Record<string, string>;
  const next = { ...cur };
  if (next[uid] === emoji) delete next[uid];
  else next[uid] = emoji;
  await updateDoc(ref, { reactions: next });
}

/* ================= групповой звонок ================= */

export type GroupCallState = {
  active: boolean;
  startedBy?: string;
  startedName?: string;
  kind?: "audio" | "video";
  at?: unknown;
  participants?: string[];
};

export function listenGroupCall(gid: string, cb: (c: GroupCallState) => void): Unsubscribe {
  return onSnapshot(
    doc(db, "groups", gid, "meta", "call"),
    (snap) => cb((snap.data() as GroupCallState) ?? { active: false }),
    () => cb({ active: false })
  );
}

export async function startGroupCall(
  gid: string,
  starter: Profile,
  kind: "audio" | "video"
): Promise<void> {
  await setDoc(doc(db, "groups", gid, "meta", "call"), {
    active: true,
    startedBy: starter.uid,
    startedName: starter.nickname,
    kind,
    at: serverTimestamp(),
    participants: [starter.uid],
  });
}

export async function joinGroupCall(gid: string, uid: string): Promise<void> {
  const ref = doc(db, "groups", gid, "meta", "call");
  const snap = await getDoc(ref);
  const cur = ((snap.data() as GroupCallState)?.participants ?? []) as string[];
  if (!cur.includes(uid)) await updateDoc(ref, { participants: [...cur, uid] });
}

export async function leaveGroupCall(gid: string, uid: string): Promise<void> {
  const ref = doc(db, "groups", gid, "meta", "call");
  const snap = await getDoc(ref);
  const cur = ((snap.data() as GroupCallState)?.participants ?? []) as string[];
  const next = cur.filter((x) => x !== uid);
  if (next.length === 0) await setDoc(ref, { active: false, participants: [] });
  else await updateDoc(ref, { participants: next });
}
