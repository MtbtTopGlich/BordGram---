import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  serverTimestamp,
  setDoc,
  updateDoc,
  type Unsubscribe,
} from "firebase/firestore";
import { db } from "./firebase";

/**
 * STUN находит внешний адрес, но между разными сетями (мобильный интернет,
 * строгий NAT, корпоративный Wi-Fi) прямое соединение часто невозможно.
 * TURN-серверы работают ретранслятором — звук и видео идут через них.
 */
export const ICE_CONFIG: RTCConfiguration = {
  iceServers: [
    {
      urls: [
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
        "stun:stun.cloudflare.com:3478",
      ],
    },
    // ретрансляторы: UDP, затем TCP и TLS/443 — пробиваются через firewall
    {
      urls: "turn:openrelay.metered.ca:80",
      username: "openrelayproject",
      credential: "openrelayproject",
    },
    {
      urls: "turn:openrelay.metered.ca:443",
      username: "openrelayproject",
      credential: "openrelayproject",
    },
    {
      urls: "turn:openrelay.metered.ca:443?transport=tcp",
      username: "openrelayproject",
      credential: "openrelayproject",
    },
    {
      urls: "turns:openrelay.metered.ca:443?transport=tcp",
      username: "openrelayproject",
      credential: "openrelayproject",
    },
    {
      urls: ["turn:global.relay.metered.ca:80", "turn:global.relay.metered.ca:443?transport=tcp"],
      username: "openrelayproject",
      credential: "openrelayproject",
    },
  ],
  iceCandidatePoolSize: 10,
  bundlePolicy: "max-bundle",
  rtcpMuxPolicy: "require",
};

export type CallType = "audio" | "video";
export type CallStatus = "ringing" | "accepted" | "declined" | "ended";

export type CallDoc = {
  id: string;
  from: string;
  to: string;
  type: CallType;
  status: CallStatus;
  fromName: string;
  fromAvatar: string;
  fromUsername: string;
  toName: string;
  toAvatar: string;
  toUsername: string;
  offer?: RTCSessionDescriptionInit | null;
  answer?: RTCSessionDescriptionInit | null;
  sharingFrom?: string | null;
  media?: Record<string, { cam: boolean; screen: boolean }>;
};

const callRef = (id: string) => doc(db, "calls", id);
const incomingRef = (uid: string, id: string) => doc(db, "users", uid, "incoming", id);

export async function createCallDoc(
  payload: Omit<CallDoc, "id" | "status" | "offer" | "answer">
): Promise<string> {
  const ref = await addDoc(collection(db, "calls"), {
    ...payload,
    status: "ringing" as CallStatus,
    createdAt: serverTimestamp(),
  });
  await setDoc(incomingRef(payload.to, ref.id), {
    callId: ref.id,
    from: payload.from,
    type: payload.type,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export function listenCall(id: string, cb: (d: CallDoc | null) => void): Unsubscribe {
  return onSnapshot(
    callRef(id),
    (snap) => cb(snap.exists() ? ({ ...(snap.data() as object), id: snap.id } as CallDoc) : null),
    () => cb(null)
  );
}

/** Входящие звонки: отдельная ветка пользователя — без составных индексов */
export function listenIncoming(uid: string, cb: (callIds: string[]) => void): Unsubscribe {
  return onSnapshot(
    collection(db, "users", uid, "incoming"),
    (snap) => cb(snap.docs.map((d) => (d.data() as { callId: string }).callId).filter(Boolean)),
    () => cb([])
  );
}

export async function setOffer(id: string, offer: RTCSessionDescriptionInit): Promise<void> {
  await updateDoc(callRef(id), { offer: { type: offer.type, sdp: offer.sdp ?? "" } });
}

export async function setAnswer(id: string, answer: RTCSessionDescriptionInit): Promise<void> {
  await updateDoc(callRef(id), {
    answer: { type: answer.type, sdp: answer.sdp ?? "" },
    status: "accepted" as CallStatus,
  });
}

/* ---------- повторное согласование (renegotiation) ---------- */

export type Side = "caller" | "callee";
export const otherSide = (s: Side): Side => (s === "caller" ? "callee" : "caller");

/** Публикуем своё описание — его заберёт собеседник */
export async function writeDesc(id: string, side: Side, desc: RTCSessionDescription | null): Promise<void> {
  if (!desc) return;
  await setDoc(doc(db, "calls", id, "desc", side), {
    type: desc.type,
    sdp: desc.sdp ?? "",
    at: Date.now(),
  });
}

export function listenDesc(
  id: string,
  side: Side,
  cb: (d: RTCSessionDescriptionInit & { at: number }) => void
): Unsubscribe {
  return onSnapshot(
    doc(db, "calls", id, "desc", side),
    (snap) => {
      const d = snap.data() as (RTCSessionDescriptionInit & { at: number }) | undefined;
      if (d?.sdp && d.type) cb(d);
    },
    () => undefined
  );
}

/** Кто сейчас демонстрирует экран — чтобы собеседник показал его крупно */
export async function setSharingFlag(id: string, uid: string | null): Promise<void> {
  await updateDoc(callRef(id), { sharingFrom: uid }).catch(() => undefined);
}

/**
 * Явное состояние медиа участника.
 * Нужно, чтобы у собеседника мгновенно пропадала картинка,
 * а не висел «вмёрзший» последний кадр.
 */
export async function setMediaFlags(
  id: string,
  uid: string,
  flags: { cam: boolean; screen: boolean }
): Promise<void> {
  await setDoc(callRef(id), { media: { [uid]: flags } }, { merge: true }).catch(() => undefined);
}

export async function setCallStatus(id: string, status: CallStatus): Promise<void> {
  await updateDoc(callRef(id), { status }).catch(() => undefined);
}

export async function clearIncoming(uid: string, id: string): Promise<void> {
  await deleteDoc(incomingRef(uid, id)).catch(() => undefined);
}

export async function addCandidate(
  id: string,
  side: "caller" | "callee",
  c: RTCIceCandidateInit
): Promise<void> {
  await addDoc(collection(db, "calls", id, side === "caller" ? "callerCandidates" : "calleeCandidates"), {
    candidate: c.candidate ?? "",
    sdpMid: c.sdpMid ?? null,
    sdpMLineIndex: c.sdpMLineIndex ?? null,
  }).catch(() => undefined);
}

export function listenCandidates(
  id: string,
  side: "caller" | "callee",
  cb: (c: RTCIceCandidateInit) => void
): Unsubscribe {
  return onSnapshot(
    collection(db, "calls", id, side === "caller" ? "callerCandidates" : "calleeCandidates"),
    (snap) => {
      snap.docChanges().forEach((ch) => {
        if (ch.type === "added") cb(ch.doc.data() as RTCIceCandidateInit);
      });
    },
    () => undefined
  );
}

/* ---------- качество медиа ---------- */

/** Запрос камеры/микрофона с учётом выбранных устройств */
export async function getLocalStream(opts: {
  video: boolean;
  micId?: string;
  camId?: string;
}): Promise<MediaStream> {
  const audio: MediaTrackConstraints = {
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true,
    ...(opts.micId ? { deviceId: { exact: opts.micId } } : {}),
  };
  const video: MediaTrackConstraints = {
    width: { ideal: 1280 },
    height: { ideal: 720 },
    frameRate: { ideal: 30 },
    ...(opts.camId ? { deviceId: { exact: opts.camId } } : {}),
  };
  try {
    return await navigator.mediaDevices.getUserMedia({ audio, video: opts.video ? video : false });
  } catch {
    // откат без точных устройств
    return navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true },
      video: opts.video,
    });
  }
}

/** Демонстрация экрана в высоком качестве */
export async function getDisplayStream(): Promise<MediaStream> {
  const stream = await navigator.mediaDevices.getDisplayMedia({
    video: {
      frameRate: { ideal: 60, max: 60 },
      width: { ideal: 2560, max: 3840 },
      height: { ideal: 1440, max: 2160 },
    } as MediaTrackConstraints,
    audio: {
      echoCancellation: false,
      noiseSuppression: false,
      autoGainControl: false,
    },
  });
  const track = stream.getVideoTracks()[0];
  if (track && "contentHint" in track) track.contentHint = "detail";
  return stream;
}

/** Поднимаем битрейт и запрещаем ронять разрешение — экран остаётся чётким */
export async function tuneSenderForScreen(sender: RTCRtpSender, screen: boolean): Promise<void> {
  try {
    const params = sender.getParameters();
    if (!params.encodings || params.encodings.length === 0) params.encodings = [{}];
    params.encodings[0].maxBitrate = screen ? 8_000_000 : 2_500_000;
    params.encodings[0].maxFramerate = screen ? 60 : 30;
    params.degradationPreference = screen ? "maintain-resolution" : "balanced";
    await sender.setParameters(params);
  } catch {
    /* браузер может не поддерживать — не критично */
  }
}

export function stopStream(s: MediaStream | null): void {
  s?.getTracks().forEach((t) => t.stop());
}

export function fmtCallTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
