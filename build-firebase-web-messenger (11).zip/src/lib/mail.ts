import emailjs from "@emailjs/browser";

/**
 * Конфигурация EmailJS.
 * service_id уже прописан. Чтобы письма улетали на почту —
 * впиши template_id и public_key из кабинета https://dashboard.emailjs.com/
 * Без них приложение работает в dev-режиме и показывает код прямо в интерфейсе.
 */
export const EMAIL_CONFIG = {
  serviceId: "service_6th6xkd",
  templateId: "template_ms0qtol",
  publicKey: "ixXMYd98ks5udWfPK",
};

export type SendCodeResult = {
  /** письмо реально отправлено */
  delivered: boolean;
  /** код показан в интерфейсе (dev-режим) */
  dev: boolean;
};

export function generateCode(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

export async function sendVerificationCode(toEmail: string, code: string, nickname: string): Promise<SendCodeResult> {
  const { serviceId, templateId, publicKey } = EMAIL_CONFIG;
  if (!templateId || !publicKey) return { delivered: false, dev: true };
  try {
    await emailjs.send(
      serviceId,
      templateId,
      {
        to_email: toEmail,
        email: toEmail,
        user_email: toEmail,
        passcode: code,
        code,
        message: code,
        name: nickname,
        nickname,
      },
      { publicKey }
    );
    return { delivered: true, dev: false };
  } catch {
    return { delivered: false, dev: true };
  }
}
