import {
  collection,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  addDoc,
  writeBatch,
  onSnapshot,
  query,
  orderBy,
  limitToLast,
  serverTimestamp,
  type Unsubscribe,
} from "firebase/firestore";
import { db } from "./lib/firebase";
import { chatIdOf, hashPassword, uid as newUid } from "./lib/utils";

/* ================= types ================= */

export type Profile = {
  uid: string;
  username: string;
  usernameDisplay: string;
  nickname: string;
  email: string;
  bio: string;
  avatar: string;
  role?: "admin" | "user";
  banned?: boolean;
  banReason?: string;
  /** значок у имени: проверенный аккаунт или тестировщик */
  badge?: BadgeKind;
  createdAt?: unknown;
};

export type BadgeKind = "none" | "verified" | "tester";

/** Владелец сервиса — всегда админ, снять нельзя */
export const OWNER_USERNAME = "dmitry_kuleshov";

export function isOwner(p: { username?: string } | null | undefined): boolean {
  return !!p?.username && p.username.toLowerCase() === OWNER_USERNAME;
}

export function isAdmin(p: { username?: string; role?: string } | null | undefined): boolean {
  return isOwner(p) || p?.role === "admin";
}

export type ContactDoc = {
  uid: string;
  nickname: string;
  usernameDisplay: string;
  avatar: string;
  fav?: boolean;
  addedAt?: unknown;
  lastAt?: unknown;
  lastSnippet?: string;
};

export type RequestDoc = {
  fromUid: string;
  nickname: string;
  usernameDisplay: string;
  avatar: string;
  createdAt?: unknown;
};

/** Моя исходящая заявка: карточка того, КОМУ я отправил */
export type OutgoingDoc = {
  toUid: string;
  nickname: string;
  usernameDisplay: string;
  avatar: string;
  createdAt?: unknown;
};

export type MessageType = "text" | "image" | "voice" | "sticker" | "call";

/** Итог звонка для системного сообщения */
export type CallOutcome = "ended" | "missed" | "declined" | "cancelled";

export type ReplyInfo = { id: string; from: string; preview: string; kind: MessageType };

export type Message = {
  id: string;
  from: string;
  to: string;
  type?: MessageType;
  text?: string;
  image?: string;
  audio?: string;
  duration?: number;
  createdAt?: unknown;
  clientKey?: string;
  editedAt?: unknown;
  deleted?: boolean;
  packId?: string;
  emoji?: string;
  callOutcome?: CallOutcome;
  callKind?: "audio" | "video";
  callDuration?: number;
  /** uid -> эмодзи */
  reactions?: Record<string, string>;
  replyTo?: ReplyInfo | null;
};

const userRef = (uid: string) => doc(db, "users", uid);
const contactRef = (uid: string, other: string) => doc(db, "users", uid, "contacts", other);
const requestRef = (uid: string, from: string) => doc(db, "users", uid, "requests", from);
const outgoingRef = (uid: string, to: string) => doc(db, "users", uid, "outgoing", to);
const blockRef = (uid: string, other: string) => doc(db, "users", uid, "blocked", other);

/* ================= users ================= */

export async function getProfile(uid: string): Promise<Profile | null> {
  const snap = await getDoc(userRef(uid));
  return snap.exists() ? ({ ...(snap.data() as object), uid } as Profile) : null;
}

export async function getUserByUsername(usernameLower: string): Promise<Profile | null> {
  const idx = await getDoc(doc(db, "usernames", usernameLower));
  if (!idx.exists()) return null;
  const { uid } = idx.data() as { uid: string };
  return getProfile(uid);
}

export async function usernameExists(usernameLower: string): Promise<boolean> {
  const snap = await getDoc(doc(db, "usernames", usernameLower));
  return snap.exists();
}

export async function emailExists(emailLower: string): Promise<boolean> {
  const snap = await getDoc(doc(db, "emails", emailLower));
  return snap.exists();
}

export async function getUidByEmail(emailLower: string): Promise<string | null> {
  const snap = await getDoc(doc(db, "emails", emailLower));
  return snap.exists() ? ((snap.data() as { uid: string }).uid ?? null) : null;
}

export async function createUser(input: {
  nickname: string;
  username: string;
  usernameDisplay: string;
  email: string;
  bio: string;
  avatar: string;
  passwordHash: string;
}): Promise<Profile> {
  const uid = newUid();
  const batch = writeBatch(db);
  const profile: Profile = {
    uid,
    nickname: input.nickname,
    username: input.username,
    usernameDisplay: input.usernameDisplay,
    email: input.email,
    bio: input.bio,
    avatar: input.avatar,
    createdAt: serverTimestamp(),
  };
  batch.set(userRef(uid), profile);
  batch.set(doc(db, "usernames", input.username), { uid, email: input.email });
  batch.set(doc(db, "emails", input.email), { uid, username: input.username });
  await batch.commit();
  return profile;
}

export type LoginCheck =
  | { status: "ok"; profile: Profile }
  | { status: "wrong-password" }
  | { status: "no-email" }
  | { status: "stale-index" };

/**
 * Точная проверка входа с самолечением:
 * — если индекс почты ссылается на удалённый аккаунт (базу чистили частично),
 *   старые записи удаляются автоматически.
 * — пароль проверяется сразу по нескольким хешам (обрезанный/сырой вариант).
 */
export async function checkLogin(emailLower: string, candidateHashes: string[]): Promise<LoginCheck> {
  const idx = await getDoc(doc(db, "emails", emailLower));
  if (!idx.exists()) return { status: "no-email" };
  const { uid, username } = idx.data() as { uid: string; username?: string };
  const snap = await getDoc(userRef(uid));
  if (!snap.exists()) {
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, "emails", emailLower));
      if (username) batch.delete(doc(db, "usernames", username));
      await batch.commit();
    } catch {
      /* best-effort */
    }
    return { status: "stale-index" };
  }
  const data = snap.data() as { passwordHash?: string };
  if (data.passwordHash && candidateHashes.includes(data.passwordHash)) {
    return { status: "ok", profile: { ...(snap.data() as object), uid } as Profile };
  }
  return { status: "wrong-password" };
}

/** Сброс пароля по доказанному владению почтой (код уже подтверждён) */
export async function resetPasswordByEmail(emailLower: string, newPlain: string): Promise<boolean> {
  const idx = await getDoc(doc(db, "emails", emailLower));
  if (!idx.exists()) return false;
  const { uid } = idx.data() as { uid: string };
  const snap = await getDoc(userRef(uid));
  if (!snap.exists()) return false;
  const hash = await hashPassword(newPlain.trim());
  await updateDoc(userRef(uid), { passwordHash: hash });
  return true;
}

export type PwChangeResult = "ok" | "mismatch" | "nouser";

export async function changeUserPassword(uid: string, oldPlain: string, newPlain: string): Promise<PwChangeResult> {
  const snap = await getDoc(userRef(uid));
  if (!snap.exists()) return "nouser";
  const data = snap.data() as { passwordHash?: string };
  const oldHash = await hashPassword(oldPlain.trim());
  if (data.passwordHash !== oldHash) return "mismatch";
  const newHash = await hashPassword(newPlain.trim());
  await updateDoc(userRef(uid), { passwordHash: newHash });
  return "ok";
}

export async function updateProfileFields(
  uid: string,
  fields: Partial<Pick<Profile, "nickname" | "bio" | "avatar">>
): Promise<void> {
  await updateDoc(userRef(uid), fields);
}

/** Лучшая попытка обновить наши данные в чужих списках контактов */
export async function propagateProfile(uid: string, fields: { nickname: string; avatar: string }): Promise<void> {
  try {
    const snap = await getDoc(userRef(uid));
    if (!snap.exists()) return;
    const myContacts = await import("firebase/firestore").then(({ getDocs }) =>
      getDocs(collection(db, "users", uid, "contacts"))
    );
    const batch = writeBatch(db);
    myContacts.forEach((c) => {
      batch.set(contactRef(c.id, uid), { uid, ...fields }, { merge: true });
    });
    myContacts.forEach((c) => {
      batch.set(requestRef(c.id, uid), { uid, ...fields }, { merge: true });
    });
    await batch.commit();
  } catch {
    /* best-effort */
  }
}

/* ================= contacts ================= */

export function listenContacts(uid: string, cb: (items: ContactDoc[]) => void): Unsubscribe {
  return onSnapshot(
    collection(db, "users", uid, "contacts"),
    (snap) => {
      const items = snap.docs.map((d) => d.data() as ContactDoc);
      items.sort((a, b) => {
        const ta = (a.lastAt ?? a.addedAt) as { seconds?: number } | undefined;
        const tb = (b.lastAt ?? b.addedAt) as { seconds?: number } | undefined;
        return (tb?.seconds ?? 0) - (ta?.seconds ?? 0);
      });
      cb(items);
    },
    () => cb([])
  );
}

export async function isContact(uid: string, other: string): Promise<boolean> {
  const snap = await getDoc(contactRef(uid, other));
  return snap.exists();
}

/** Избранное: закрепить контакт наверху списка */
export async function setContactFavorite(myUid: string, otherUid: string, fav: boolean): Promise<void> {
  await updateDoc(contactRef(myUid, otherUid), { fav });
}

/* ================= админка ================= */

export async function setUserBanned(uid: string, banned: boolean, reason = ""): Promise<void> {
  await updateDoc(userRef(uid), banned ? { banned: true, banReason: reason } : { banned: false, banReason: "" });
}

export async function setUserAdmin(uid: string, admin: boolean): Promise<void> {
  await updateDoc(userRef(uid), { role: admin ? "admin" : "user" });
}

/** Значок у имени: верификация или тестировщик */
export async function setUserBadge(uid: string, badge: BadgeKind): Promise<void> {
  await updateDoc(userRef(uid), { badge });
}

/** Живое наблюдение за своим профилем (бан/роль прилетают мгновенно) */
export function listenProfile(uid: string, cb: (p: Profile | null) => void): Unsubscribe {
  return onSnapshot(
    userRef(uid),
    (snap) => cb(snap.exists() ? ({ ...(snap.data() as object), uid } as Profile) : null),
    () => cb(null)
  );
}

/* ================= requests ================= */

export function listenRequests(uid: string, cb: (items: RequestDoc[]) => void): Unsubscribe {
  return onSnapshot(
    collection(db, "users", uid, "requests"),
    (snap) => {
      const items = snap.docs.map((d) => d.data() as RequestDoc);
      items.sort((a, b) => {
        const ta = a.createdAt as { seconds?: number } | undefined;
        const tb = b.createdAt as { seconds?: number } | undefined;
        return (tb?.seconds ?? 0) - (ta?.seconds ?? 0);
      });
      cb(items);
    },
    () => cb([])
  );
}

/** Есть ли уже моя исходящая заявка у этого пользователя */
export function listenOutgoingRequest(targetUid: string, myUid: string, cb: (exists: boolean) => void): Unsubscribe {
  return onSnapshot(requestRef(targetUid, myUid), (snap) => cb(snap.exists()), () => cb(false));
}

export function listenOutgoing(uid: string, cb: (items: OutgoingDoc[]) => void): Unsubscribe {
  return onSnapshot(
    collection(db, "users", uid, "outgoing"),
    (snap) => {
      const items = snap.docs.map((d) => d.data() as OutgoingDoc);
      items.sort((a, b) => {
        const ta = a.createdAt as { seconds?: number } | undefined;
        const tb = b.createdAt as { seconds?: number } | undefined;
        return (tb?.seconds ?? 0) - (ta?.seconds ?? 0);
      });
      cb(items);
    },
    () => cb([])
  );
}

/** Зеркало заявки у себя — отдельной записью, чтобы не терялось при сбое */
export async function ensureOutgoingMirror(me: Profile, target: Profile): Promise<void> {
  await setDoc(
    outgoingRef(me.uid, target.uid),
    {
      toUid: target.uid,
      nickname: target.nickname,
      usernameDisplay: target.usernameDisplay,
      avatar: target.avatar,
      createdAt: serverTimestamp(),
    } satisfies OutgoingDoc,
    { merge: true }
  );
}

export async function sendContactRequest(me: Profile, target: Profile): Promise<void> {
  // пишем раздельно: даже если одна операция упадёт, вторая сохранится
  await setDoc(requestRef(target.uid, me.uid), {
    fromUid: me.uid,
    nickname: me.nickname,
    usernameDisplay: me.usernameDisplay,
    avatar: me.avatar,
    createdAt: serverTimestamp(),
  } satisfies RequestDoc);
  await ensureOutgoingMirror(me, target);
}

/** Отозвать свою заявку */
export async function cancelContactRequest(myUid: string, targetUid: string): Promise<void> {
  const batch = writeBatch(db);
  batch.delete(requestRef(targetUid, myUid));
  batch.delete(outgoingRef(myUid, targetUid));
  await batch.commit();
}

export async function acceptContactRequest(myUid: string, req: RequestDoc): Promise<void> {
  const me = await getProfile(myUid);
  if (!me) throw new Error("no profile");
  const batch = writeBatch(db);
  const now = serverTimestamp();
  batch.set(contactRef(myUid, req.fromUid), {
    uid: req.fromUid,
    nickname: req.nickname,
    usernameDisplay: req.usernameDisplay,
    avatar: req.avatar,
    addedAt: now,
  });
  batch.set(contactRef(req.fromUid, myUid), {
    uid: myUid,
    nickname: me.nickname,
    usernameDisplay: me.usernameDisplay,
    avatar: me.avatar,
    addedAt: now,
  });
  batch.delete(requestRef(myUid, req.fromUid));
  batch.delete(outgoingRef(req.fromUid, myUid));
  await batch.commit();
}

/* ================= blocks ================= */

export function listenBlock(uid: string, other: string, cb: (v: boolean) => void): Unsubscribe {
  return onSnapshot(blockRef(uid, other), (s) => cb(s.exists()), () => cb(false));
}

export async function blockUser(myUid: string, otherUid: string): Promise<void> {
  const batch = writeBatch(db);
  batch.set(blockRef(myUid, otherUid), { at: serverTimestamp() });
  batch.delete(contactRef(myUid, otherUid));
  batch.delete(contactRef(otherUid, myUid));
  batch.delete(requestRef(myUid, otherUid));
  batch.delete(requestRef(otherUid, myUid));
  batch.delete(outgoingRef(myUid, otherUid));
  batch.delete(outgoingRef(otherUid, myUid));
  await batch.commit();
}

export async function unblockUser(myUid: string, otherUid: string): Promise<void> {
  await deleteDoc(blockRef(myUid, otherUid));
}

/* ================= присутствие (онлайн) ================= */

const presenceRef = (uid: string) => doc(db, "presence", uid);

/** Сердцебиение: отмечаем, что пользователь сейчас в сети */
export async function touchPresence(uid: string): Promise<void> {
  await setDoc(presenceRef(uid), { at: serverTimestamp() }, { merge: true });
}

export function listenPresence(uid: string, cb: (lastSeenMs: number) => void): Unsubscribe {
  return onSnapshot(
    presenceRef(uid),
    (snap) => {
      const v = snap.data() as { at?: { seconds?: number } } | undefined;
      cb(v?.at?.seconds ? v.at.seconds * 1000 : 0);
    },
    () => cb(0)
  );
}

/* ================= набор текста ================= */

const typingRef = (chatId: string, uid: string) => doc(db, "chats", chatId, "typing", uid);

export async function setTyping(chatId: string, uid: string, on: boolean): Promise<void> {
  if (on) await setDoc(typingRef(chatId, uid), { at: serverTimestamp() });
  else await deleteDoc(typingRef(chatId, uid)).catch(() => undefined);
}

export function listenTyping(chatId: string, peerUid: string, cb: (typing: boolean) => void): Unsubscribe {
  return onSnapshot(
    typingRef(chatId, peerUid),
    (snap) => {
      const v = snap.data() as { at?: { seconds?: number } } | undefined;
      const ms = v?.at?.seconds ? v.at.seconds * 1000 : 0;
      cb(Date.now() - ms < 6000);
    },
    () => cb(false)
  );
}

/* ================= живые метаданные чата ================= */

export type ChatDoc = {
  lastAt?: { seconds?: number } | null;
  lastFrom?: string;
  lastSnippet?: string;
  reads?: Record<string, { seconds?: number } | null>;
  pinned?: PinnedInfo | null;
};

export function listenChatDoc(chatId: string, cb: (d: ChatDoc) => void): Unsubscribe {
  return onSnapshot(
    doc(db, "chats", chatId),
    (snap) => cb(snap.exists() ? ((snap.data() as ChatDoc) ?? {}) : {}),
    () => cb({})
  );
}

/* ================= прочтение ================= */

export type ChatMeta = { reads?: Record<string, { seconds?: number } | null> };

export function listenChatMeta(chatId: string, cb: (m: ChatMeta) => void): Unsubscribe {
  return onSnapshot(
    doc(db, "chats", chatId),
    (snap) => cb(snap.exists() ? ((snap.data() as ChatMeta) ?? {}) : {}),
    () => cb({})
  );
}

/** Отметить чат прочитанным до текущего момента */
export async function markChatRead(chatId: string, myUid: string): Promise<void> {
  await setDoc(doc(db, "chats", chatId), { reads: { [myUid]: serverTimestamp() } }, { merge: true });
}

/* ================= messages ================= */

export function listenMessages(chatId: string, cb: (items: Message[]) => void): Unsubscribe {
  const q = query(
    collection(db, "chats", chatId, "messages"),
    orderBy("createdAt", "asc"),
    limitToLast(300)
  );
  return onSnapshot(
    q,
    (snap) => {
      cb(snap.docs.map((d) => ({ ...(d.data() as object), id: d.id } as Message)));
    },
    () => cb([])
  );
}

const msgRef = (chatId: string, id: string) => doc(db, "chats", chatId, "messages", id);

/** «2 часа 5 минут», «3 минуты 12 секунд», «45 секунд» */
export function humanDuration(totalSec: number): string {
  const s = Math.max(0, Math.round(totalSec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const plural = (n: number, forms: [string, string, string]) => {
    const n10 = n % 10;
    const n100 = n % 100;
    if (n10 === 1 && n100 !== 11) return forms[0];
    if (n10 >= 2 && n10 <= 4 && (n100 < 10 || n100 >= 20)) return forms[1];
    return forms[2];
  };
  const parts: string[] = [];
  if (h > 0) parts.push(`${h} ${plural(h, ["час", "часа", "часов"])}`);
  if (m > 0) parts.push(`${m} ${plural(m, ["минута", "минуты", "минут"])}`);
  if (sec > 0 && h === 0) parts.push(`${sec} ${plural(sec, ["секунда", "секунды", "секунд"])}`);
  return parts.length ? parts.join(" ") : "0 секунд";
}

export function callLabel(m: Message, mine: boolean): string {
  const kind = m.callKind === "video" ? "Видеозвонок" : "Звонок";
  switch (m.callOutcome) {
    case "ended":
      return `${kind} · ${humanDuration(m.callDuration ?? 0)}`;
    case "declined":
      return mine ? `${kind} отклонён` : `Отклонённый ${kind.toLowerCase()}`;
    case "cancelled":
      return mine ? `Отменённый ${kind.toLowerCase()}` : `Пропущенный ${kind.toLowerCase()}`;
    default:
      return mine ? `${kind} без ответа` : `Пропущенный ${kind.toLowerCase()}`;
  }
}

/** Системная запись о звонке в переписке */
export async function logCall(
  fromUid: string,
  toUid: string,
  info: { outcome: CallOutcome; kind: "audio" | "video"; duration: number }
): Promise<void> {
  await deliverMessage(fromUid, toUid, {
    type: "call",
    callOutcome: info.outcome,
    callKind: info.kind,
    callDuration: info.duration,
  });
}

export function previewOf(m: Message): string {
  if (m.type === "image") return "Фотография";
  if (m.type === "voice") return "Голосовое сообщение";
  if (m.type === "sticker") return `${m.emoji ?? "🙂"} Стикер`;
  if (m.type === "call") return m.callOutcome === "ended" ? "Звонок" : "Пропущенный звонок";
  const t = m.text ?? "";
  return t.length > 70 ? t.slice(0, 70) + "…" : t;
}

/** Редактирование своего текста */
export async function editMessage(chatId: string, id: string, text: string): Promise<void> {
  await updateDoc(msgRef(chatId, id), { text, editedAt: serverTimestamp() });
}

/** Мягкое удаление — у обоих */
export async function deleteMessage(chatId: string, id: string): Promise<void> {
  await updateDoc(msgRef(chatId, id), {
    deleted: true,
    text: "",
    image: "",
    audio: "",
    reactions: {},
    replyTo: null,
  });
}

/** Поставить/снять реакцию */
export async function toggleReaction(chatId: string, id: string, uid: string, emoji: string): Promise<void> {
  const snap = await getDoc(msgRef(chatId, id));
  if (!snap.exists()) return;
  const cur = (snap.data() as Message).reactions ?? {};
  const next = { ...cur };
  if (next[uid] === emoji) delete next[uid];
  else next[uid] = emoji;
  await updateDoc(msgRef(chatId, id), { reactions: next });
}

/* ---------- закрепления ---------- */

export type PinnedInfo = { id: string; preview: string; from: string; at?: unknown };

/** Закрепить для обоих (в документе чата) */
export async function pinForEveryone(chatId: string, info: PinnedInfo | null): Promise<void> {
  await setDoc(doc(db, "chats", chatId), { pinned: info ? { ...info, at: serverTimestamp() } : null }, { merge: true });
}

/** Закрепить только у себя (в личной ветке пользователя) */
export async function pinForMe(myUid: string, chatId: string, info: PinnedInfo | null): Promise<void> {
  await setDoc(
    doc(db, "users", myUid, "pins", chatId),
    info ? { ...info, at: serverTimestamp() } : { cleared: true, id: "" },
    { merge: false }
  );
}

export function listenMyPin(myUid: string, chatId: string, cb: (p: PinnedInfo | null) => void): Unsubscribe {
  return onSnapshot(
    doc(db, "users", myUid, "pins", chatId),
    (snap) => {
      const d = snap.data() as (PinnedInfo & { cleared?: boolean }) | undefined;
      cb(d && d.id ? d : null);
    },
    () => cb(null)
  );
}

export async function deliverMessage(
  fromUid: string,
  toUid: string,
  body: {
    type: MessageType;
    text?: string;
    image?: string;
    audio?: string;
    duration?: number;
    replyTo?: ReplyInfo | null;
    packId?: string;
    emoji?: string;
    callOutcome?: CallOutcome;
    callKind?: "audio" | "video";
    callDuration?: number;
  }
): Promise<void> {
  const chatId = chatIdOf(fromUid, toUid);
  const snippet =
    body.type === "image"
      ? "Фотография"
      : body.type === "voice"
        ? "Голосовое сообщение"
        : body.type === "sticker"
          ? `${body.emoji ?? "🙂"} Стикер`
          : body.type === "call"
            ? body.callOutcome === "ended"
              ? "Звонок"
              : "Пропущенный звонок"
            : (body.text ?? "").length > 60
              ? (body.text ?? "").slice(0, 60) + "…"
              : (body.text ?? "");
  await addDoc(collection(db, "chats", chatId, "messages"), {
    from: fromUid,
    to: toUid,
    type: body.type,
    ...(body.text !== undefined ? { text: body.text } : {}),
    ...(body.image ? { image: body.image } : {}),
    ...(body.audio ? { audio: body.audio } : {}),
    ...(body.duration !== undefined ? { duration: body.duration } : {}),
    ...(body.replyTo ? { replyTo: body.replyTo } : {}),
    ...(body.packId ? { packId: body.packId } : {}),
    ...(body.emoji ? { emoji: body.emoji } : {}),
    ...(body.callOutcome ? { callOutcome: body.callOutcome } : {}),
    ...(body.callKind ? { callKind: body.callKind } : {}),
    ...(body.callDuration !== undefined ? { callDuration: body.callDuration } : {}),
    createdAt: serverTimestamp(),
  });
  await setDoc(
    doc(db, "chats", chatId),
    { participants: [fromUid, toUid], lastSnippet: snippet, lastAt: serverTimestamp(), lastFrom: fromUid },
    { merge: true }
  );
  // обновляем подписи в списках контактов (если они есть)
  const now = serverTimestamp();
  for (const [a, b] of [
    [fromUid, toUid],
    [toUid, fromUid],
  ] as const) {
    try {
      await updateDoc(contactRef(a, b), { lastAt: now, lastSnippet: snippet });
    } catch {
      /* контакт не добавлен — нормально */
    }
  }
}
