import { useEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MessagesSquare, Volume2, VolumeX, X } from "lucide-react";
import { cx, gradientFor, initials } from "../lib/utils";
import { sfx } from "../lib/sounds";

/* ================= avatar ================= */

export function Avatar({
  src,
  name,
  seed,
  size = 44,
  className,
  active = false,
}: {
  src?: string;
  name: string;
  seed?: string;
  size?: number;
  className?: string;
  active?: boolean;
}) {
  const [g1, g2] = gradientFor(seed ?? name);
  return (
    <div
      className={cx(
        "relative flex shrink-0 select-none items-center justify-center overflow-hidden rounded-full font-display font-semibold text-white",
        className
      )}
      style={{
        width: size,
        height: size,
        background: src ? undefined : `linear-gradient(135deg, ${g1}, ${g2})`,
        fontSize: size * 0.36,
        boxShadow: active ? "0 0 0 2px #fff, 0 0 0 4.5px #FF6A00" : "0 2px 10px rgba(190,80,0,0.18)",
      }}
    >
      {src ? (
        <img src={src} alt={name} className="h-full w-full object-cover" draggable={false} />
      ) : (
        <span>{initials(name)}</span>
      )}
    </div>
  );
}

/* ================= значок аккаунта ================= */

export function BadgeMark({
  badge,
  size = 13,
  withText = false,
}: {
  badge?: "none" | "verified" | "tester";
  size?: number;
  withText?: boolean;
}) {
  if (!badge || badge === "none") return null;
  const verified = badge === "verified";
  const title = verified ? "Проверенный аккаунт" : "Тестировщик BordGram";

  const icon = verified ? (
    // галочка в «звёздочном» щите, как у соцсетей
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden>
      <path
        fill="#1d9bf0"
        d="M12 1.5l2.4 2.1 3.2-.3.9 3.1 2.8 1.6-1.2 3 1.2 3-2.8 1.6-.9 3.1-3.2-.3L12 22.5l-2.4-2.1-3.2.3-.9-3.1L2.7 16l1.2-3-1.2-3 2.8-1.6.9-3.1 3.2.3L12 1.5z"
      />
      <path
        fill="#fff"
        d="M10.6 15.4l-3-3 1.3-1.3 1.7 1.7 4.2-4.2 1.3 1.3-5.5 5.5z"
      />
    </svg>
  ) : (
    // колбочка тестировщика
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden>
      <circle cx="12" cy="12" r="11" fill="#8b5cf6" />
      <path
        fill="#fff"
        d="M10 5h4v1.6h-.8v3.1l3.1 5.6c.7 1.3-.2 2.9-1.7 2.9H9.4c-1.5 0-2.4-1.6-1.7-2.9l3.1-5.6V6.6H10V5zm2.4 7.6a.9.9 0 100 1.8.9.9 0 000-1.8z"
      />
    </svg>
  );

  if (!withText) {
    return (
      <span className="inline-flex shrink-0 items-center" title={title}>
        {icon}
      </span>
    );
  }

  return (
    <span
      className={cx(
        "inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold",
        verified ? "bg-sky-50 text-sky-600" : "bg-violet-50 text-violet-600"
      )}
      title={title}
    >
      {icon}
      {verified ? "проверен" : "тестировщик"}
    </span>
  );
}

/* ================= logo ================= */

export function Logo({ size = 40, withWord = true, className }: { size?: number; withWord?: boolean; className?: string }) {
  return (
    <div className={cx("flex items-center gap-3", className)}>
      <div
        className="logo-sheen relative flex items-center justify-center overflow-hidden rounded-[28%] bg-gradient-to-br from-orange-500 via-orange-500 to-amber-400 text-white shadow-orangeSoft"
        style={{ width: size, height: size }}
      >
        <MessagesSquare size={size * 0.52} strokeWidth={2.2} />
      </div>
      {withWord && (
        <div className="leading-none">
          <div className="font-display text-[19px] font-bold tracking-tight text-cocoa">
            Bord<span className="text-orange-600">Gram</span>
          </div>
          <div className="mt-1 text-[10px] font-semibold uppercase tracking-[0.22em] text-cocoa-soft/80">
            warm messenger
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= spinner ================= */

export function Spinner({ size = 18, className }: { size?: number; className?: string }) {
  return (
    <div
      className={cx("animate-spin rounded-full border-2 border-orange-500/25 border-t-orange-500", className)}
      style={{ width: size, height: size }}
    />
  );
}

/* ================= sound toggle ================= */

export function SoundToggle({ compact = false }: { compact?: boolean }) {
  const [on, setOn] = useState(sfx.enabled);
  return (
    <button
      type="button"
      onClick={() => {
        const v = !on;
        sfx.setEnabled(v);
        setOn(v);
        sfx.tick();
      }}
      className={cx(
        "btn-press flex items-center justify-center gap-2 rounded-full text-cocoa-soft transition-colors hover:text-orange-600",
        compact ? "h-10 w-10 bg-white/80 shadow-warm" : "px-4 py-2"
      )}
      title={on ? "Выключить звуки" : "Включить звуки"}
    >
      {on ? <Volume2 size={17} /> : <VolumeX size={17} />}
    </button>
  );
}

/* ================= тёплый фон ================= */

export function WarmBackdrop() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-cream">
      <div className="blob absolute -left-40 -top-40 h-[34rem] w-[34rem] rounded-full bg-orange-300/50 blur-[110px]" />
      <div className="blob-d2 absolute -right-48 top-1/4 h-[30rem] w-[30rem] rounded-full bg-amber-300/45 blur-[120px]" />
      <div className="blob-d3 absolute -bottom-52 left-1/3 h-[32rem] w-[32rem] rounded-full bg-orange-400/25 blur-[130px]" />
      <div className="grain absolute inset-0 opacity-[0.5]" />
    </div>
  );
}

/* ================= инпут кода ================= */

export function CodeInput({
  value,
  onChange,
  length = 6,
  autoFocus = false,
  invalid = false,
}: {
  value: string;
  onChange: (v: string) => void;
  length?: number;
  autoFocus?: boolean;
  invalid?: boolean;
}) {
  const ref = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (autoFocus) {
      const t = setTimeout(() => ref.current?.focus(), 350);
      return () => clearTimeout(t);
    }
  }, [autoFocus]);

  const setVal = (raw: string) => {
    const digits = raw.replace(/\D/g, "").slice(0, length);
    if (digits.length > value.length) sfx.key();
    onChange(digits);
  };

  return (
    <div className="relative" onClick={() => ref.current?.focus()}>
      <input
        ref={ref}
        value={value}
        onChange={(e) => setVal(e.target.value)}
        inputMode="numeric"
        autoComplete="one-time-code"
        className="absolute inset-0 h-full w-full cursor-text opacity-0"
        aria-label="Код подтверждения"
      />
      <div className={cx("flex justify-center gap-2", invalid && "animate-shake")}> 
        {Array.from({ length }).map((_, i) => {
          const ch = value[i] ?? "";
          const isCursor = i === value.length;
          return (
            <motion.div
              key={i}
              animate={{ scale: ch ? [1.14, 1] : 1 }}
              transition={{ duration: 0.16 }}
              className={cx(
                "flex h-13 w-11 items-center justify-center rounded-2xl border-2 font-display text-xl font-bold transition-colors duration-200",
                ch
                  ? "border-orange-500 bg-white text-cocoa shadow-orangeSoft"
                  : isCursor
                    ? "border-orange-400/80 bg-white/70 text-cocoa"
                    : "border-orange-200/80 bg-white/50 text-cocoa-soft"
              )}
            >
              {ch || <span className={cx("h-1.5 w-1.5 rounded-full", isCursor ? "bg-orange-400" : "bg-orange-200")} />}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

/* ================= модалка ================= */

export function ModalShell({
  open,
  onClose,
  children,
  maxW = "max-w-md",
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  maxW?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[90] flex items-center justify-center bg-cocoa/25 p-4 backdrop-blur-sm"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
        >
          <motion.div
            initial={{ opacity: 0, y: 26, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 18, scale: 0.97 }}
            transition={{ type: "spring", stiffness: 380, damping: 32 }}
            className={cx("relative w-full rounded-[28px] border border-orange-100 bg-cream p-6 shadow-2xl", maxW)}
          >
            <button
              onClick={() => {
                sfx.close();
                onClose();
              }}
              className="btn-press absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-white/80 text-cocoa-soft transition-colors hover:text-orange-600"
              aria-label="Закрыть"
            >
              <X size={16} />
            </button>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ================= кнопка ================= */

export function PrimaryButton({
  children,
  onClick,
  disabled,
  loading,
  className,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  loading?: boolean;
  className?: string;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      onClick={onClick}
      className={cx(
        "btn-press relative flex items-center justify-center gap-2 overflow-hidden rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-6 py-3.5 font-semibold text-white shadow-orangeGlow transition-all duration-300",
        "hover:shadow-orangeGlowBig hover:brightness-105 disabled:cursor-not-allowed disabled:opacity-50 disabled:saturate-50",
        className
      )}
    >
      {loading ? <Spinner size={18} className="border-white/30 border-t-white" /> : children}
    </button>
  );
}
