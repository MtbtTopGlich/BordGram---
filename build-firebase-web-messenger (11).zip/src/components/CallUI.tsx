import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ChevronDown,
  Maximize2,
  Minimize2,
  Users,
  Mic,
  MicOff,
  Monitor,
  MonitorOff,
  Phone,
  PhoneOff,
  Settings2,
  Video,
  VideoOff,
} from "lucide-react";
import { Avatar } from "./bits";
import { useToast } from "../state";
import {
  addCandidate,
  clearIncoming,
  createCallDoc,
  fmtCallTime,
  getDisplayStream,
  getLocalStream,
  ICE_CONFIG,
  listenCall,
  listenCandidates,
  listenDesc,
  listenIncoming,
  otherSide,
  setCallStatus,
  setMediaFlags,
  setSharingFlag,
  stopStream,
  tuneSenderForScreen,
  writeDesc,
  type CallDoc,
  type CallType,
  type Side,
} from "../lib/calls";
import { getSavedDeviceId, listInputDevices, saveDeviceId } from "../lib/devices";
import { logCall, type CallOutcome, type Profile } from "../db";
import GroupCallScreen from "./GroupCallScreen";
import { listenGroupCall, startGroupCall as startGroupCallDoc, type Group, type GroupCallState } from "../lib/groups";
import { cx } from "../lib/utils";
import { sfx } from "../lib/sounds";

type Phase = "idle" | "outgoing" | "incoming" | "active";

type Ctx = {
  startCall: (peer: Profile, type: CallType) => void;
  startGroupCall: (group: Group, kind: CallType) => void;
  busy: boolean;
};
const CallContext = createContext<Ctx>({
  startCall: () => undefined,
  startGroupCall: () => undefined,
  busy: false,
});
export const useCalls = () => useContext(CallContext);

export function CallProvider({
  me,
  groups = [],
  children,
}: {
  me: Profile | null;
  groups?: Group[];
  children: ReactNode;
}) {
  const { toast } = useToast();

  const [phase, setPhase] = useState<Phase>("idle");
  const [call, setCall] = useState<CallDoc | null>(null);
  const [callType, setCallType] = useState<CallType>("video");
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [peerSharing, setPeerSharing] = useState(false);
  const [peerCam, setPeerCam] = useState(false);
  const [remoteVideo, setRemoteVideo] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [busyBtn, setBusyBtn] = useState("");
  const [netState, setNetState] = useState<RTCPeerConnectionState>("new");
  const [relayed, setRelayed] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [groupCall, setGroupCall] = useState<{ group: Group; kind: CallType } | null>(null);
  const [ringingGroup, setRingingGroup] = useState<{ group: Group; state: GroupCallState } | null>(null);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const audioSender = useRef<RTCRtpSender | null>(null);
  const videoSender = useRef<RTCRtpSender | null>(null);
  const camStream = useRef<MediaStream | null>(null);
  const micStream = useRef<MediaStream | null>(null);
  const screenStream = useRef<MediaStream | null>(null);
  const remoteStream = useRef<MediaStream>(new MediaStream());
  const unsubs = useRef<Array<() => void>>([]);
  const callIdRef = useRef("");
  const sideRef = useRef<Side>("caller");
  const peerRef = useRef<{ uid: string; name: string; avatar: string; username: string } | null>(null);
  const ringTimer = useRef<number | null>(null);

  // флаги «идеального согласования»
  const makingOffer = useRef(false);
  const ignoreOffer = useRef(false);
  const settingAnswer = useRef(false);
  const lastDescAt = useRef(0);
  /** кандидаты, пришедшие раньше описания — применим позже */
  const pendingIce = useRef<RTCIceCandidateInit[]>([]);
  const restarted = useRef(false);

  // журнал звонка: кто инициатор, когда соединились, записали ли итог
  const isCaller = useRef(false);
  const connectedAt = useRef(0);
  const logged = useRef(false);
  const callKindRef = useRef<CallType>("video");

  /* ================= очистка ================= */

  const cleanup = useCallback(() => {
    unsubs.current.forEach((f) => f());
    unsubs.current = [];
    try {
      pcRef.current?.close();
    } catch {
      /* noop */
    }
    pcRef.current = null;
    audioSender.current = null;
    videoSender.current = null;
    stopStream(camStream.current);
    stopStream(micStream.current);
    stopStream(screenStream.current);
    camStream.current = null;
    micStream.current = null;
    screenStream.current = null;
    remoteStream.current = new MediaStream();
    callIdRef.current = "";
    peerRef.current = null;
    isCaller.current = false;
    connectedAt.current = 0;
    logged.current = false;
    makingOffer.current = false;
    ignoreOffer.current = false;
    lastDescAt.current = 0;
    pendingIce.current = [];
    restarted.current = false;
    setNetState("new");
    setRelayed(false);
    setPhase("idle");
    setCall(null);
    setSharing(false);
    setPeerSharing(false);
    setPeerCam(false);
    setRemoteVideo(false);
    setMicOn(true);
    setCamOn(false);
    setSeconds(0);
    setBusyBtn("");
  }, []);

  /**
   * Пишем системное сообщение о звонке.
   * Запись делает только инициатор — чтобы в чате не было дублей,
   * а видна она обоим собеседникам.
   */
  const writeLog = useCallback(
    (outcome: CallOutcome) => {
      if (logged.current || !me || !peerRef.current) return;
      if (!isCaller.current) return;
      logged.current = true;
      const duration = connectedAt.current > 0 ? Math.round((Date.now() - connectedAt.current) / 1000) : 0;
      const finalOutcome: CallOutcome = connectedAt.current > 0 ? "ended" : outcome;
      void logCall(me.uid, peerRef.current.uid, {
        outcome: finalOutcome,
        kind: callKindRef.current,
        duration,
      }).catch(() => undefined);
    },
    [me]
  );

  const endCall = useCallback(
    (silent = false) => {
      const id = callIdRef.current;
      writeLog("cancelled");
      if (id) {
        void setCallStatus(id, "ended");
        if (me) void clearIncoming(me.uid, id);
        if (peerRef.current) void clearIncoming(peerRef.current.uid, id);
      }
      if (!silent) sfx.close();
      cleanup();
    },
    [cleanup, me, writeLog]
  );

  /* ================= соединение ================= */

  /**
   * Транссиверы создаём заранее (аудио + видео) — тогда камеру и экран
   * можно подменять на лету через replaceTrack, и собеседник сразу их видит.
   */
  const setupPeer = useCallback(
    (callId: string, side: Side) => {
      const pc = new RTCPeerConnection(ICE_CONFIG);
      pcRef.current = pc;
      sideRef.current = side;
      const polite = side === "callee";

      const aT = pc.addTransceiver("audio", { direction: "sendrecv" });
      const vT = pc.addTransceiver("video", { direction: "sendrecv" });
      audioSender.current = aT.sender;
      videoSender.current = vT.sender;

      pc.onicecandidate = (e) => {
        if (e.candidate) void addCandidate(callId, side, e.candidate.toJSON());
      };

      pc.ontrack = (e) => {
        const track = e.track;
        if (!remoteStream.current.getTracks().some((t) => t.id === track.id)) {
          remoteStream.current.addTrack(track);
        }
        const refresh = () => {
          const v = remoteStream.current.getVideoTracks().find((t) => t.readyState === "live" && !t.muted);
          setRemoteVideo(!!v);
        };
        track.onunmute = refresh;
        track.onmute = refresh;
        track.onended = refresh;
        refresh();
      };

      // автоматическое повторное согласование
      pc.onnegotiationneeded = async () => {
        try {
          makingOffer.current = true;
          await pc.setLocalDescription();
          await writeDesc(callId, side, pc.localDescription);
        } catch {
          /* noop */
        } finally {
          makingOffer.current = false;
        }
      };

      pc.onconnectionstatechange = () => {
        setNetState(pc.connectionState);
        if (pc.connectionState === "connected") {
          restarted.current = false;
          // узнаём, идёт ли медиа через ретранслятор
          void pc.getStats().then((stats) => {
            stats.forEach((r) => {
              if (r.type === "candidate-pair" && r.state === "succeeded") {
                const local = stats.get((r as { localCandidateId?: string }).localCandidateId ?? "");
                if (local?.candidateType === "relay") setRelayed(true);
              }
            });
          });
        }
        if (pc.connectionState === "failed") {
          // одна попытка перезапустить подбор маршрута
          if (!restarted.current) {
            restarted.current = true;
            toast("Переподключаемся…", "info");
            try {
              pc.restartIce();
            } catch {
              /* noop */
            }
          } else {
            toast("Не удалось установить соединение", "err");
            endCall(true);
          }
        }
      };

      pc.oniceconnectionstatechange = () => {
        if (pc.iceConnectionState === "disconnected" && !restarted.current) {
          restarted.current = true;
          try {
            pc.restartIce();
          } catch {
            /* noop */
          }
        }
      };

      // приём описаний собеседника
      const unDesc = listenDesc(callId, otherSide(side), async (d) => {
        if (!pcRef.current || d.at <= lastDescAt.current) return;
        lastDescAt.current = d.at;
        const desc: RTCSessionDescriptionInit = { type: d.type, sdp: d.sdp };
        try {
          const ready = !makingOffer.current && (pc.signalingState === "stable" || settingAnswer.current);
          const collision = desc.type === "offer" && !ready;
          ignoreOffer.current = !polite && collision;
          if (ignoreOffer.current) return;

          settingAnswer.current = desc.type === "answer";
          await pc.setRemoteDescription(desc);
          settingAnswer.current = false;

          // применяем кандидатов, пришедших раньше описания
          const queued = pendingIce.current;
          pendingIce.current = [];
          for (const c of queued) {
            await pc.addIceCandidate(new RTCIceCandidate(c)).catch(() => undefined);
          }

          if (desc.type === "offer") {
            await pc.setLocalDescription();
            await writeDesc(callId, side, pc.localDescription);
          }
        } catch {
          settingAnswer.current = false;
        }
      });

      const unIce = listenCandidates(callId, otherSide(side), (c) => {
        // без remoteDescription кандидата принимать нельзя — складываем в очередь
        if (!pc.remoteDescription) {
          pendingIce.current.push(c);
          return;
        }
        pc.addIceCandidate(new RTCIceCandidate(c)).catch(() => {
          pendingIce.current.push(c);
        });
      });

      unsubs.current.push(unDesc, unIce);
      return pc;
    },
    [endCall, toast]
  );

  /** Берём микрофон и (при видеозвонке) камеру */
  const attachLocalMedia = useCallback(async (wantVideo: boolean) => {
    const stream = await getLocalStream({
      video: wantVideo,
      micId: getSavedDeviceId("mic"),
      camId: getSavedDeviceId("cam"),
    });
    const aTrack = stream.getAudioTracks()[0] ?? null;
    const vTrack = stream.getVideoTracks()[0] ?? null;

    if (aTrack) {
      micStream.current = new MediaStream([aTrack]);
      await audioSender.current?.replaceTrack(aTrack);
    }
    if (vTrack) {
      camStream.current = new MediaStream([vTrack]);
      await videoSender.current?.replaceTrack(vTrack);
      if (videoSender.current) await tuneSenderForScreen(videoSender.current, false);
      setCamOn(true);
    } else {
      setCamOn(false);
    }
  }, []);

  /* ================= исходящий ================= */

  const startCall = useCallback(
    async (peer: Profile, type: CallType) => {
      if (!me || phase !== "idle" || peer.uid === me.uid) return;
      setCallType(type);
      setPhase("outgoing");
      isCaller.current = true;
      logged.current = false;
      connectedAt.current = 0;
      callKindRef.current = type;
      peerRef.current = { uid: peer.uid, name: peer.nickname, avatar: peer.avatar, username: peer.usernameDisplay };

      try {
        const id = await createCallDoc({
          from: me.uid,
          to: peer.uid,
          type,
          fromName: me.nickname,
          fromAvatar: me.avatar,
          fromUsername: me.usernameDisplay,
          toName: peer.nickname,
          toAvatar: peer.avatar,
          toUsername: peer.usernameDisplay,
        });
        callIdRef.current = id;

        setupPeer(id, "caller");
        await attachLocalMedia(type === "video");

        unsubs.current.push(
          listenCall(id, (d) => {
            if (!d) return;
            setCall(d);
            const pm = d.media?.[peer.uid];
            setPeerCam(!!pm?.cam);
            setPeerSharing(pm ? !!pm.screen : !!d.sharingFrom && d.sharingFrom !== me.uid);
            if (d.status === "accepted") {
              if (connectedAt.current === 0) connectedAt.current = Date.now();
              setPhase("active");
            }
            if (d.status === "declined") {
              toast("Звонок отклонён", "info");
              writeLog("declined");
              cleanup();
            }
            if (d.status === "ended") {
              writeLog("cancelled");
              cleanup();
            }
          })
        );
      } catch {
        toast("Не удалось начать звонок — проверь доступ к микрофону", "err");
        endCall(true);
      }
    },
    [me, phase, setupPeer, attachLocalMedia, cleanup, endCall, toast, writeLog]
  );

  /* ================= входящий ================= */

  useEffect(() => {
    if (!me) return;
    return listenIncoming(me.uid, (ids) => {
      if (phase !== "idle" || ids.length === 0) return;
      const id = ids[0];
      const un = listenCall(id, (d) => {
        if (!d) return;
        if (d.status === "ringing" && d.to === me.uid) {
          callIdRef.current = id;
          peerRef.current = { uid: d.from, name: d.fromName, avatar: d.fromAvatar, username: d.fromUsername };
          isCaller.current = false;
          logged.current = false;
          connectedAt.current = 0;
          callKindRef.current = d.type;
          setCall(d);
          setCallType(d.type);
          setPhase("incoming");
        } else if (d.status === "ended" || d.status === "declined") {
          void clearIncoming(me.uid, id);
        }
      });
      unsubs.current.push(un);
    });
  }, [me, phase]);

  const accept = useCallback(async () => {
    const id = callIdRef.current;
    if (!me || !call || !id) return;
    sfx.success();
    try {
      setupPeer(id, "callee");
      await attachLocalMedia(call.type === "video");
      await clearIncoming(me.uid, id);
      await setCallStatus(id, "accepted");
      connectedAt.current = Date.now();

      unsubs.current.push(
        listenCall(id, (d) => {
          if (!d) return;
          setCall(d);
          const pm = d.media?.[d.from === me.uid ? d.to : d.from];
          setPeerCam(!!pm?.cam);
          setPeerSharing(pm ? !!pm.screen : !!d.sharingFrom && d.sharingFrom !== me.uid);
          if (d.status === "ended" || d.status === "declined") cleanup();
        })
      );
      setPhase("active");
    } catch {
      toast("Нет доступа к микрофону или камере", "err");
      endCall(true);
    }
  }, [me, call, setupPeer, attachLocalMedia, cleanup, endCall, toast]);

  const decline = useCallback(() => {
    const id = callIdRef.current;
    if (id) {
      void setCallStatus(id, "declined");
      if (me) void clearIncoming(me.uid, id);
    }
    sfx.close();
    cleanup();
  }, [cleanup, me]);

  /* ================= таймер / рингтон ================= */

  useEffect(() => {
    if (phase !== "active") return;
    const t = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(t);
  }, [phase]);

  useEffect(() => {
    if (phase !== "incoming" && phase !== "outgoing") {
      if (ringTimer.current) window.clearInterval(ringTimer.current);
      return;
    }
    const ring = () => (phase === "incoming" ? sfx.notify() : sfx.tick());
    ring();
    ringTimer.current = window.setInterval(ring, phase === "incoming" ? 2200 : 3400);
    return () => {
      if (ringTimer.current) window.clearInterval(ringTimer.current);
    };
  }, [phase]);

  // публикуем своё состояние медиа — у собеседника картинка исчезает мгновенно
  useEffect(() => {
    if (!me || !callIdRef.current || (phase !== "active" && phase !== "outgoing")) return;
    void setMediaFlags(callIdRef.current, me.uid, { cam: camOn, screen: sharing });
  }, [me, phase, camOn, sharing]);

  useEffect(() => () => cleanup(), [cleanup]);

  /* ================= управление ================= */

  const toggleMic = () => {
    const t = micStream.current?.getAudioTracks()[0];
    if (!t) return;
    t.enabled = !t.enabled;
    setMicOn(t.enabled);
    sfx.tick();
  };

  /** Камера включается по требованию — даже в аудиозвонке */
  const toggleCam = async () => {
    if (busyBtn) return;
    setBusyBtn("cam");
    try {
      // выключаем: полностью гасим дорожку, чтобы и лампочка камеры погасла,
      // и у собеседника не остался «вмёрзший» кадр
      if (camOn) {
        if (!sharing) await videoSender.current?.replaceTrack(null);
        stopStream(camStream.current);
        camStream.current = null;
        setCamOn(false);
        if (me && callIdRef.current) void setMediaFlags(callIdRef.current, me.uid, { cam: false, screen: sharing });
        sfx.tick();
        return;
      }
      // включаем — запрашиваем свежую камеру
      const s = await getLocalStream({ video: true, camId: getSavedDeviceId("cam"), micId: getSavedDeviceId("mic") });
      const v = s.getVideoTracks()[0];
      s.getAudioTracks().forEach((t) => t.stop());
      if (!v) throw new Error("no camera");
      camStream.current = new MediaStream([v]);
      if (!sharing) {
        await videoSender.current?.replaceTrack(v);
        if (videoSender.current) await tuneSenderForScreen(videoSender.current, false);
      }
      setCamOn(true);
      sfx.success();
    } catch {
      toast("Камера недоступна — проверь разрешения браузера", "err");
    } finally {
      setBusyBtn("");
    }
  };

  const stopShare = useCallback(async () => {
    const cam = camOn ? (camStream.current?.getVideoTracks()[0] ?? null) : null;
    // сначала убираем картинку у собеседника, потом гасим поток
    await videoSender.current?.replaceTrack(cam);
    if (videoSender.current) await tuneSenderForScreen(videoSender.current, false);
    stopStream(screenStream.current);
    screenStream.current = null;
    setSharing(false);
    if (callIdRef.current) {
      void setSharingFlag(callIdRef.current, null);
      if (me) void setMediaFlags(callIdRef.current, me.uid, { cam: !!cam, screen: false });
    }
  }, [camOn, me]);

  const startShare = async () => {
    if (busyBtn) return;
    setBusyBtn("share");
    try {
      const screen = await getDisplayStream();
      screenStream.current = screen;
      const track = screen.getVideoTracks()[0];
      await videoSender.current?.replaceTrack(track);
      if (videoSender.current) await tuneSenderForScreen(videoSender.current, true);
      track.onended = () => void stopShare();
      setSharing(true);
      if (me && callIdRef.current) void setSharingFlag(callIdRef.current, me.uid);
      sfx.success();
    } catch {
      toast("Демонстрация отменена", "info");
    } finally {
      setBusyBtn("");
    }
  };

  /** Смена устройства на лету */
  const switchDevice = async (kind: "mic" | "cam", deviceId: string) => {
    saveDeviceId(kind, deviceId);
    if (!pcRef.current) return;
    try {
      if (kind === "mic") {
        const s = await getLocalStream({ video: false, micId: deviceId });
        const a = s.getAudioTracks()[0];
        if (!a) return;
        a.enabled = micOn;
        stopStream(micStream.current);
        micStream.current = new MediaStream([a]);
        await audioSender.current?.replaceTrack(a);
      } else {
        const s = await getLocalStream({ video: true, camId: deviceId });
        const v = s.getVideoTracks()[0];
        s.getAudioTracks().forEach((t) => t.stop());
        if (!v) return;
        v.enabled = camOn;
        stopStream(camStream.current);
        camStream.current = new MediaStream([v]);
        if (!sharing && camOn) await videoSender.current?.replaceTrack(v);
      }
      sfx.tick();
    } catch {
      toast("Не удалось переключить устройство", "err");
    }
  };

  const peer = peerRef.current;

  /* ================= групповые звонки ================= */

  // уведомление о начатом звонке в любой из моих групп
  useEffect(() => {
    if (!me || groups.length === 0) return;
    const unsubs = groups.map((g) =>
      listenGroupCall(g.id, (state) => {
        const iAmIn = (state.participants ?? []).includes(me.uid);
        if (state.active && !iAmIn && state.startedBy !== me.uid) {
          setRingingGroup({ group: g, state });
          sfx.notify();
        } else {
          setRingingGroup((cur) => (cur?.group.id === g.id ? null : cur));
        }
      })
    );
    return () => unsubs.forEach((u) => u());
  }, [me, groups]);

  const beginGroupCall = useCallback(
    async (group: Group, kind: CallType) => {
      if (!me || phase !== "idle" || groupCall) return;
      setRingingGroup(null);
      setMinimized(false);
      try {
        await startGroupCallDoc(group.id, me, kind);
        setGroupCall({ group, kind });
      } catch {
        toast("Не удалось начать групповой звонок", "err");
      }
    },
    [me, phase, groupCall, toast]
  );

  const inAnyCall = phase === "active" || phase === "outgoing" || !!groupCall;

  return (
    <CallContext.Provider
      value={{
        startCall: (p, t) => void startCall(p, t),
        startGroupCall: (g, k) => void beginGroupCall(g, k),
        busy: inAnyCall,
      }}
    >
      {children}

      <AnimatePresence>
        {phase === "incoming" && call && (
          <IncomingCard call={call} onAccept={() => void accept()} onDecline={decline} />
        )}
      </AnimatePresence>

      {/* входящий групповой звонок */}
      <AnimatePresence>
        {ringingGroup && !inAnyCall && (
          <motion.div
            initial={{ opacity: 0, y: -30, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed left-1/2 top-5 z-[200] w-[min(94vw,400px)] -translate-x-1/2 rounded-[26px] border border-orange-200 bg-white/95 p-5 shadow-2xl backdrop-blur-xl"
          >
            <div className="flex items-center gap-4">
              <div className="relative shrink-0">
                <motion.span
                  animate={{ scale: [1, 1.35], opacity: [0.5, 0] }}
                  transition={{ duration: 1.6, repeat: Infinity }}
                  className="absolute inset-0 rounded-full bg-orange-400"
                />
                <Avatar
                  src={ringingGroup.group.avatar}
                  name={ringingGroup.group.title}
                  seed={ringingGroup.group.invite}
                  size={58}
                />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="truncate font-display text-[16px] font-bold">{ringingGroup.group.title}</span>
                  <span className="flex shrink-0 items-center gap-1 rounded-full bg-orange-100 px-2 py-0.5 text-[10px] font-bold text-orange-700">
                    <Users size={9} /> группа
                  </span>
                </div>
                <div className="truncate text-[12px] font-semibold text-cocoa-soft">
                  {ringingGroup.state.startedName} начал(а) звонок
                </div>
                <div className="text-[11.5px] font-semibold text-orange-600">
                  {ringingGroup.state.participants?.length ?? 0} уже в звонке
                </div>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2.5">
              <button
                onClick={() => {
                  sfx.close();
                  setRingingGroup(null);
                }}
                className="btn-press rounded-2xl bg-orange-100/80 py-3.5 text-sm font-bold text-cocoa-soft"
              >
                Не сейчас
              </button>
              <button
                onClick={() => void beginGroupCall(ringingGroup.group, ringingGroup.state.kind ?? "audio")}
                className="btn-press flex items-center justify-center gap-2 rounded-2xl bg-emerald-500 py-3.5 text-sm font-bold text-white shadow-lg hover:bg-emerald-600"
              >
                <Phone size={16} /> Присоединиться
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* групповой звонок */}
      {groupCall && me && (
        <GroupCallScreen
          group={groupCall.group}
          me={me}
          kind={groupCall.kind}
          minimized={minimized}
          onMinimize={() => {
            sfx.tick();
            setMinimized(true);
          }}
          onLeave={() => {
            setGroupCall(null);
            setMinimized(false);
          }}
        />
      )}

      {/* свёрнутый звонок */}
      <AnimatePresence>
        {inAnyCall && minimized && (
          <MiniCall
            title={groupCall ? groupCall.group.title : (peer?.name ?? "Звонок")}
            avatar={groupCall ? groupCall.group.avatar : (peer?.avatar ?? "")}
            seed={groupCall ? groupCall.group.invite : (peer?.username ?? "")}
            isGroup={!!groupCall}
            seconds={seconds}
            stream={groupCall ? null : remoteStream.current}
            onExpand={() => {
              sfx.tick();
              setMinimized(false);
            }}
            onHangup={() => {
              setMinimized(false);
              if (groupCall) setGroupCall(null);
              else endCall();
            }}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {(phase === "outgoing" || phase === "active") && peer && !minimized && (
          <CallScreen
            peer={peer}
            phase={phase}
            onMinimize={() => {
              sfx.tick();
              setMinimized(true);
            }}
            type={callType}
            seconds={seconds}
            micOn={micOn}
            camOn={camOn}
            sharing={sharing}
            peerSharing={peerSharing}
            netState={netState}
            relayed={relayed}
            remoteVideo={remoteVideo && (peerCam || peerSharing)}
            busyBtn={busyBtn}
            remoteStream={remoteStream.current}
            camStream={camStream.current}
            screenStream={screenStream.current}
            onMic={toggleMic}
            onCam={() => void toggleCam()}
            onShare={() => (sharing ? void stopShare() : void startShare())}
            onHangup={() => endCall()}
            onSwitchDevice={(k, id) => void switchDevice(k, id)}
          />
        )}
      </AnimatePresence>
    </CallContext.Provider>
  );
}

/* ================= входящий звонок ================= */

function IncomingCard({
  call,
  onAccept,
  onDecline,
}: {
  call: CallDoc;
  onAccept: () => void;
  onDecline: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -30, scale: 0.94 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -20, scale: 0.95 }}
      transition={{ type: "spring", stiffness: 360, damping: 28 }}
      className="fixed left-1/2 top-5 z-[200] w-[min(94vw,400px)] -translate-x-1/2 overflow-hidden rounded-[26px] border border-orange-200 bg-white/95 p-5 shadow-2xl backdrop-blur-xl"
    >
      <div className="flex items-center gap-4">
        <div className="relative shrink-0">
          <motion.span
            animate={{ scale: [1, 1.35], opacity: [0.5, 0] }}
            transition={{ duration: 1.6, repeat: Infinity }}
            className="absolute inset-0 rounded-full bg-orange-400"
          />
          <Avatar src={call.fromAvatar} name={call.fromName} seed={call.fromUsername} size={58} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate font-display text-[17px] font-bold">{call.fromName}</div>
          <div className="truncate text-[12.5px] font-semibold text-orange-600">@{call.fromUsername}</div>
          <div className="mt-0.5 flex items-center gap-1.5 text-[12px] font-semibold text-cocoa-soft">
            {call.type === "video" ? <Video size={12} /> : <Phone size={12} />}
            входящий {call.type === "video" ? "видеозвонок" : "аудиозвонок"}
          </div>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2.5">
        <button
          onClick={onDecline}
          className="btn-press flex items-center justify-center gap-2 rounded-2xl bg-red-500 py-3.5 text-sm font-bold text-white shadow-lg transition hover:bg-red-600"
        >
          <PhoneOff size={17} /> Отклонить
        </button>
        <motion.button
          onClick={onAccept}
          animate={{ scale: [1, 1.035, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="btn-press flex items-center justify-center gap-2 rounded-2xl bg-emerald-500 py-3.5 text-sm font-bold text-white shadow-lg transition hover:bg-emerald-600"
        >
          <Phone size={17} /> Принять
        </motion.button>
      </div>
    </motion.div>
  );
}

/* ================= свёрнутый звонок ================= */

function MiniCall({
  title,
  avatar,
  seed,
  isGroup,
  seconds,
  stream,
  onExpand,
  onHangup,
}: {
  title: string;
  avatar: string;
  seed: string;
  isGroup: boolean;
  seconds: number;
  stream: MediaStream | null;
  onExpand: () => void;
  onHangup: () => void;
}) {
  const [mode, setMode] = useState<"pill" | "window">("pill");
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const el = videoRef.current;
    if (el && stream && el.srcObject !== stream) el.srcObject = stream;
  }, [stream, mode]);

  if (mode === "window") {
    return (
      <motion.div
        drag
        dragMomentum={false}
        dragElastic={0.03}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="fixed bottom-24 right-6 z-[195] w-[250px] cursor-grab overflow-hidden rounded-2xl border border-white/20 bg-[#1b0f08] shadow-2xl active:cursor-grabbing"
      >
        <div className="relative aspect-video bg-black">
          {stream ? (
            <video ref={videoRef} autoPlay playsInline muted className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full items-center justify-center">
              <Avatar src={avatar} name={title} seed={seed} size={52} />
            </div>
          )}
          <span className="absolute left-2 top-2 flex items-center gap-1.5 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-bold text-white">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            {fmtCallTime(seconds)}
          </span>
        </div>
        <div className="flex items-center gap-2 px-2.5 py-2">
          <span className="min-w-0 flex-1 truncate text-[12px] font-bold text-white">{title}</span>
          <button
            onClick={() => setMode("pill")}
            title="Свернуть в плашку"
            className="btn-press rounded-full p-1.5 text-white/70 hover:text-white"
          >
            <Minimize2 size={13} />
          </button>
          <button
            onClick={onExpand}
            title="На весь экран"
            className="btn-press rounded-full p-1.5 text-white/70 hover:text-white"
          >
            <Maximize2 size={13} />
          </button>
          <button
            onClick={onHangup}
            title="Завершить"
            className="btn-press flex h-7 w-7 items-center justify-center rounded-full bg-red-500 text-white"
          >
            <PhoneOff size={13} />
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="fixed left-1/2 top-4 z-[195] flex -translate-x-1/2 items-center gap-2.5 rounded-full border border-emerald-300/40 bg-emerald-600/95 px-3 py-2 shadow-2xl backdrop-blur-xl"
    >
      <span className="relative flex h-2.5 w-2.5 shrink-0">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-70" />
        <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-white" />
      </span>
      <Avatar src={avatar} name={title} seed={seed} size={26} />
      <div className="min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="max-w-[140px] truncate text-[12.5px] font-bold text-white">{title}</span>
          {isGroup && (
            <span className="flex items-center gap-0.5 rounded-full bg-white/20 px-1.5 py-0.5 text-[9px] font-bold text-white">
              <Users size={8} /> группа
            </span>
          )}
        </div>
        <div className="text-[10.5px] font-semibold text-white/80">идёт звонок · {fmtCallTime(seconds)}</div>
      </div>
      <button
        onClick={() => setMode("window")}
        title="В мини-окно"
        className="btn-press ml-1 flex h-8 w-8 items-center justify-center rounded-full bg-white/20 text-white hover:bg-white/30"
      >
        <Monitor size={14} />
      </button>
      <button
        onClick={onExpand}
        title="Вернуться в звонок"
        className="btn-press flex h-8 w-8 items-center justify-center rounded-full bg-white/20 text-white hover:bg-white/30"
      >
        <Maximize2 size={14} />
      </button>
      <button
        onClick={onHangup}
        title="Завершить звонок"
        className="btn-press flex h-8 w-8 items-center justify-center rounded-full bg-red-500 text-white hover:bg-red-600"
      >
        <PhoneOff size={14} />
      </button>
    </motion.div>
  );
}

/* ================= звук собеседника ================= */

/** Отдельный аудиовыход: надёжнее, чем звук из <video>, и переживает автоблокировку */
function RemoteAudio({ stream }: { stream: MediaStream }) {
  const ref = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.srcObject = stream;
    el.volume = 1;
    const tryPlay = () => void el.play().catch(() => undefined);
    tryPlay();
    // если браузер заблокировал автозапуск — включим по первому клику
    const onClick = () => tryPlay();
    window.addEventListener("click", onClick, { once: true });
    const retry = window.setInterval(tryPlay, 1200);
    const stop = window.setTimeout(() => window.clearInterval(retry), 8000);
    return () => {
      window.removeEventListener("click", onClick);
      window.clearInterval(retry);
      window.clearTimeout(stop);
    };
  }, [stream]);

  return <audio ref={ref} autoPlay playsInline />;
}

/* ================= видео-элемент ================= */

function Stream({
  stream,
  muted,
  mirror,
  className,
}: {
  stream: MediaStream | null;
  muted?: boolean;
  mirror?: boolean;
  className?: string;
}) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (el.srcObject !== stream) el.srcObject = stream;
    if (stream) void el.play().catch(() => undefined);
  }, [stream]);
  return (
    <video
      ref={ref}
      autoPlay
      playsInline
      muted={muted}
      className={cx(className, mirror && "-scale-x-100")}
    />
  );
}

/* ================= экран звонка ================= */

function CallScreen({
  peer,
  phase,
  onMinimize,
  type,
  seconds,
  micOn,
  camOn,
  sharing,
  peerSharing,
  netState,
  relayed,
  remoteVideo,
  busyBtn,
  remoteStream,
  camStream,
  screenStream,
  onMic,
  onCam,
  onShare,
  onHangup,
  onSwitchDevice,
}: {
  peer: { uid: string; name: string; avatar: string; username: string };
  phase: Phase;
  onMinimize: () => void;
  type: CallType;
  seconds: number;
  micOn: boolean;
  camOn: boolean;
  sharing: boolean;
  peerSharing: boolean;
  netState: RTCPeerConnectionState;
  relayed: boolean;
  remoteVideo: boolean;
  busyBtn: string;
  remoteStream: MediaStream;
  camStream: MediaStream | null;
  screenStream: MediaStream | null;
  onMic: () => void;
  onCam: () => void;
  onShare: () => void;
  onHangup: () => void;
  onSwitchDevice: (kind: "mic" | "cam", id: string) => void;
}) {
  const [showDevices, setShowDevices] = useState(false);
  const [swapped, setSwapped] = useState(false);
  const [mics, setMics] = useState<MediaDeviceInfo[]>([]);
  const [cams, setCams] = useState<MediaDeviceInfo[]>([]);
  const [micId, setMicId] = useState(getSavedDeviceId("mic"));
  const [camId, setCamId] = useState(getSavedDeviceId("cam"));

  useEffect(() => {
    if (!showDevices) return;
    void listInputDevices().then((d) => {
      setMics(d.mics);
      setCams(d.cams);
    });
  }, [showDevices]);

  // когда собеседник начал демонстрацию — его экран автоматически крупно
  useEffect(() => {
    if (peerSharing) setSwapped(false);
  }, [peerSharing]);

  const myVideo = sharing ? screenStream : camOn ? camStream : null;
  const hasRemote = phase === "active" && remoteVideo;

  // раскладка: крупно — собеседник, в углу — я (можно поменять местами)
  const mainIsRemote = !swapped;
  const mainStream = mainIsRemote ? (hasRemote ? remoteStream : null) : myVideo;
  const pipStream = mainIsRemote ? myVideo : hasRemote ? remoteStream : null;
  const mainIsScreen = mainIsRemote ? peerSharing : sharing;
  const pipIsScreen = mainIsRemote ? sharing : peerSharing;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex flex-col bg-[#1b0f08]"
    >
      {/* ---------- основная область ---------- */}
      <div className="relative min-h-0 flex-1 overflow-hidden">
        {/* звук собеседника идёт всегда, даже без картинки */}
        <RemoteAudio stream={remoteStream} />

        {mainStream ? (
          <Stream
            stream={mainStream}
            muted
            mirror={!mainIsRemote && !sharing}
            className="h-full w-full bg-[#140b05] object-contain"
          />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
            <div className="relative">
              <motion.span
                animate={{ scale: [1, 1.5], opacity: [0.35, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 rounded-full bg-orange-500"
              />
              <Avatar src={peer.avatar} name={peer.name} seed={peer.username} size={116} />
            </div>
            <div className="text-center">
              <div className="font-display text-2xl font-bold text-white">{peer.name}</div>
              <div className="mt-1 text-sm font-semibold text-orange-300">@{peer.username}</div>
              <div className="mt-2 text-[13px] font-medium text-white/60">
                {phase === "outgoing" ? "Вызываем…" : type === "audio" ? "Аудиозвонок" : "Камера выключена"}
              </div>
            </div>
          </div>
        )}

        {/* верхняя панель */}
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-center gap-3 bg-gradient-to-b from-black/70 to-transparent px-5 py-4">
          <Avatar src={peer.avatar} name={peer.name} seed={peer.username} size={38} />
          <div className="min-w-0 flex-1">
            <div className="truncate text-[15px] font-bold text-white">{peer.name}</div>
            <div className="flex items-center gap-2 text-[12px] font-semibold text-white/65">
              {phase === "active" && netState === "connected" ? (
                <>
                  {fmtCallTime(seconds)}
                  {relayed && (
                    <span className="rounded-full bg-white/15 px-1.5 py-0.5 text-[9.5px] font-bold text-white/70">
                      через ретранслятор
                    </span>
                  )}
                </>
              ) : phase === "outgoing" ? (
                "вызов…"
              ) : netState === "failed" ? (
                <span className="text-red-300">нет соединения</span>
              ) : (
                <span className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-amber-400" />
                  соединяем…
                </span>
              )}
            </div>
          </div>
          {mainIsScreen && (
            <span className="flex items-center gap-1.5 rounded-full bg-orange-500/90 px-3 py-1 text-[11px] font-bold text-white">
              <Monitor size={11} /> {mainIsRemote ? "экран собеседника" : "твой экран"}
            </span>
          )}
          <button
            onClick={onMinimize}
            title="Свернуть звонок"
            className="btn-press pointer-events-auto flex h-10 w-10 items-center justify-center rounded-full bg-white/15 text-white backdrop-blur transition-colors hover:bg-white/25"
          >
            <Minimize2 size={17} />
          </button>
        </div>

        {/* окно в углу */}
        <AnimatePresence>
          {pipStream && (
            <motion.div
              drag
              dragMomentum={false}
              dragElastic={0.04}
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.85 }}
              onClick={() => {
                setSwapped((v) => !v);
                sfx.tick();
              }}
              className={cx(
                "group absolute bottom-6 right-5 cursor-pointer overflow-hidden rounded-2xl border-2 border-white/25 bg-black shadow-2xl active:cursor-grabbing",
                pipIsScreen ? "h-[108px] w-[176px] sm:h-[132px] sm:w-[220px]" : "h-[132px] w-[99px] sm:h-[168px] sm:w-[126px]"
              )}
            >
              <Stream
                stream={pipStream}
                muted
                mirror={mainIsRemote && !sharing}
                className="h-full w-full object-cover"
              />
              <span className="absolute bottom-1 left-1.5 text-[9.5px] font-bold text-white/85">
                {mainIsRemote ? (sharing ? "твой экран" : "ты") : peer.name}
              </span>
              <span className="absolute right-1.5 top-1.5 rounded-md bg-black/55 p-1 text-white opacity-0 transition-opacity group-hover:opacity-100">
                <Maximize2 size={11} />
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ---------- панель управления ---------- */}
      <div className="relative shrink-0 bg-black/50 px-4 pb-6 pt-4 backdrop-blur-xl">
        <AnimatePresence>
          {showDevices && (
            <motion.div
              initial={{ opacity: 0, y: 12, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.98 }}
              className="absolute bottom-[calc(100%-6px)] left-1/2 w-[min(92vw,380px)] -translate-x-1/2 rounded-2xl border border-white/15 bg-[#241408]/96 p-4 shadow-2xl backdrop-blur-xl"
            >
              <div className="mb-3 flex items-center justify-between">
                <span className="text-[13px] font-bold text-white">Устройства</span>
                <button onClick={() => setShowDevices(false)} className="btn-press text-white/60 hover:text-white">
                  <ChevronDown size={16} />
                </button>
              </div>

              <label className="mb-3 block">
                <span className="mb-1.5 flex items-center gap-1.5 text-[11.5px] font-bold text-white/70">
                  <Mic size={12} /> Микрофон
                </span>
                <select
                  value={micId}
                  onChange={(e) => {
                    setMicId(e.target.value);
                    onSwitchDevice("mic", e.target.value);
                  }}
                  className="w-full rounded-xl border border-white/15 bg-white/10 px-3 py-2.5 text-[13px] font-medium text-white outline-none"
                >
                  <option value="" className="text-black">По умолчанию</option>
                  {mics.map((d, i) => (
                    <option key={d.deviceId || i} value={d.deviceId} className="text-black">
                      {d.label || `Микрофон ${i + 1}`}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block">
                <span className="mb-1.5 flex items-center gap-1.5 text-[11.5px] font-bold text-white/70">
                  <Video size={12} /> Камера
                </span>
                <select
                  value={camId}
                  onChange={(e) => {
                    setCamId(e.target.value);
                    onSwitchDevice("cam", e.target.value);
                  }}
                  className="w-full rounded-xl border border-white/15 bg-white/10 px-3 py-2.5 text-[13px] font-medium text-white outline-none"
                >
                  <option value="" className="text-black">По умолчанию</option>
                  {cams.map((d, i) => (
                    <option key={d.deviceId || i} value={d.deviceId} className="text-black">
                      {d.label || `Камера ${i + 1}`}
                    </option>
                  ))}
                </select>
              </label>
              {sharing && (
                <p className="mt-2.5 text-[11px] leading-snug text-orange-300">
                  Идёт демонстрация — камера включится в окне после её остановки
                </p>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mx-auto flex max-w-md items-center justify-center gap-3 sm:gap-4">
          <CallBtn active={micOn} onClick={onMic} label={micOn ? "Микрофон включён" : "Микрофон выключен"}>
            {micOn ? <Mic size={20} /> : <MicOff size={20} />}
          </CallBtn>

          <CallBtn
            active={camOn}
            loading={busyBtn === "cam"}
            onClick={onCam}
            label={camOn ? "Выключить камеру" : "Включить камеру"}
          >
            {camOn ? <Video size={20} /> : <VideoOff size={20} />}
          </CallBtn>

          <CallBtn
            active={sharing}
            highlight={sharing}
            loading={busyBtn === "share"}
            onClick={onShare}
            label={sharing ? "Остановить демонстрацию" : "Демонстрация экрана"}
          >
            {sharing ? <MonitorOff size={20} /> : <Monitor size={20} />}
          </CallBtn>

          <CallBtn active={showDevices} onClick={() => setShowDevices((v) => !v)} label="Выбрать устройства">
            <Settings2 size={20} />
          </CallBtn>

          <button
            onClick={onHangup}
            title="Завершить звонок"
            className="btn-press flex h-[58px] w-[58px] shrink-0 items-center justify-center rounded-full bg-red-500 text-white shadow-[0_8px_26px_rgba(239,68,68,0.5)] transition-colors hover:bg-red-600"
          >
            <PhoneOff size={23} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function CallBtn({
  children,
  onClick,
  active,
  highlight,
  loading,
  label,
}: {
  children: ReactNode;
  onClick: () => void;
  active: boolean;
  highlight?: boolean;
  loading?: boolean;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={loading}
      title={label}
      className={cx(
        "btn-press flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-full border transition-colors disabled:opacity-60",
        highlight
          ? "border-orange-400 bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeGlow"
          : active
            ? "border-white/20 bg-white/15 text-white hover:bg-white/25"
            : "border-white/10 bg-white/90 text-cocoa hover:bg-white"
      )}
    >
      {loading ? (
        <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent opacity-70" />
      ) : (
        children
      )}
    </button>
  );
}
