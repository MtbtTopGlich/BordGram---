import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Pause, Play, SendHorizontal, Trash2, X } from "lucide-react";
import { cx } from "../lib/utils";
import { getSavedDeviceId } from "../lib/devices";
import { sfx } from "../lib/sounds";
import { Logo } from "./bits";

export const MIC_MAX = 60;

export function formatDur(totalSeconds: number): string {
  const s = Math.max(0, Math.round(totalSeconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2, "0")}`;
}

/* ================= диктофон ================= */

const BAR_HEIGHTS = [10, 16, 22, 14, 20, 26, 12, 18, 24, 15, 21, 27, 11, 17, 23, 13, 19, 25, 12, 18, 22, 15];

export function RecorderBar({
  onSend,
  onCancel,
  onError,
}: {
  onSend: (dataUrl: string, secs: number) => void;
  onCancel: () => void;
  onError: () => void;
}) {
  const [secs, setSecs] = useState(0);
  const [sending, setSending] = useState(false);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const keepRef = useRef(false);
  const stoppedRef = useRef(false);
  const secsRef = useRef(0);

  useEffect(() => {
    let alive = true;
    let stream: MediaStream | null = null;
    let timer: number | null = null;

    const stopRecorder = (keep: boolean) => {
      if (stoppedRef.current) return;
      stoppedRef.current = true;
      keepRef.current = keep;
      if (timer) window.clearInterval(timer);
      try {
        if (recRef.current && recRef.current.state !== "inactive") recRef.current.stop();
      } catch {
        /* noop */
      }
    };

    async function start() {
      try {
        const savedMic = getSavedDeviceId("mic");
        const base: MediaTrackConstraints = { echoCancellation: true, noiseSuppression: true };
        stream = await navigator.mediaDevices
          .getUserMedia({ audio: savedMic ? { ...base, deviceId: { exact: savedMic } } : base })
          .catch(() => navigator.mediaDevices.getUserMedia({ audio: base }));
        if (!alive) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "";
        const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
        recRef.current = rec;
        chunks.current = [];
        rec.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.current.push(e.data);
        };
        rec.onstop = () => {
          stream?.getTracks().forEach((t) => t.stop());
          if (!keepRef.current || chunks.current.length === 0) return;
          const blob = new Blob(chunks.current, { type: mime || "audio/webm" });
          const reader = new FileReader();
          reader.onloadend = () => onSend(String(reader.result), Math.max(1, secsRef.current));
          reader.readAsDataURL(blob);
        };
        rec.start(250);
        sfx.tick();
        timer = window.setInterval(() => {
          secsRef.current += 1;
          setSecs(secsRef.current);
          if (secsRef.current >= MIC_MAX) {
            setSending(true);
            stopRecorder(true);
          }
        }, 1000);

        // подвязка кнопок через ref-объект
        controls.current = {
          send: () => {
            setSending(true);
            sfx.send();
            stopRecorder(true);
          },
          cancel: () => {
            sfx.close();
            stopRecorder(false);
            onCancel();
          },
        };
      } catch {
        if (alive) onError();
      }
    }
    void start();

    return () => {
      alive = false;
      stopRecorder(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const controls = useRef<{ send: () => void; cancel: () => void }>({ send: () => undefined, cancel: () => undefined });

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-1 items-center gap-3 rounded-[22px] border-2 border-red-300/70 bg-red-50/70 px-4 py-2"
    >
      <span className="relative flex h-3 w-3 shrink-0">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-500 opacity-60" />
        <span className="relative inline-flex h-3 w-3 rounded-full bg-red-500" />
      </span>
      <span className="w-11 shrink-0 font-display text-sm font-bold tabular-nums text-red-600">{formatDur(secs)}</span>
      <div className="flex h-7 min-w-0 flex-1 items-center gap-[3px] overflow-hidden">
        {BAR_HEIGHTS.map((h, i) => (
          <span
            key={i}
            className="eq-bar w-[3px] shrink-0 rounded-full bg-gradient-to-t from-red-400 to-orange-400"
            style={{ height: h, animationDelay: `${(i % 7) * 0.12}s`, animationDuration: `${0.7 + (i % 5) * 0.13}s` }}
          />
        ))}
      </div>
      <button
        type="button"
        onClick={() => controls.current.cancel()}
        disabled={sending}
        className="btn-press flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-red-500 shadow-warm transition-colors hover:bg-red-100 disabled:opacity-50"
        title="Отменить запись"
      >
        <Trash2 size={16} />
      </button>
      <button
        type="button"
        onClick={() => controls.current.send()}
        disabled={sending}
        className="btn-press flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeGlow disabled:opacity-60"
        title="Отправить голосовое"
      >
        {sending ? (
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
        ) : (
          <SendHorizontal size={16} className="-translate-x-[1px]" />
        )}
      </button>
    </motion.div>
  );
}

/* ================= голосовое сообщение ================= */

function seedBars(seed: string, n: number): number[] {
  let h = 2166136261;
  const out: number[] = [];
  for (let i = 0; i < n; i++) {
    h ^= seed.charCodeAt(i % seed.length) + i * 7;
    h = Math.imul(h, 16777619);
    out.push(6 + (Math.abs(h) % 18));
  }
  return out;
}

export function VoiceBubble({ src, duration, mine, seed }: { src: string; duration: number; mine: boolean; seed: string }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [cur, setCur] = useState(0);
  const [realDur, setRealDur] = useState(0);
  const bars = useMemo(() => seedBars(seed, 22), [seed]);

  const total = realDur > 0 ? realDur : duration > 0 ? duration : 1;
  const ratio = Math.min(1, cur / total);
  const filled = Math.round(ratio * bars.length);

  const toggle = () => {
    const a = audioRef.current;
    if (!a) return;
    if (playing) {
      a.pause();
      setPlaying(false);
      sfx.tick();
    } else {
      void a.play();
      setPlaying(true);
      sfx.click();
    }
  };

  return (
    <div className="flex min-w-[190px] items-center gap-2.5 sm:min-w-[210px]">
      <audio
        ref={audioRef}
        src={src}
        preload="metadata"
        onLoadedMetadata={(e) => {
          const d = e.currentTarget.duration;
          if (Number.isFinite(d)) setRealDur(d);
        }}
        onTimeUpdate={(e) => setCur(e.currentTarget.currentTime)}
        onEnded={() => {
          setPlaying(false);
          setCur(0);
          sfx.tick();
        }}
      />
      <button
        type="button"
        onClick={toggle}
        className={cx(
          "btn-press flex h-9 w-9 shrink-0 items-center justify-center rounded-full shadow-sm",
          mine ? "bg-white text-orange-600" : "bg-gradient-to-br from-orange-600 to-amber-500 text-white"
        )}
      >
        {playing ? <Pause size={14} /> : <Play size={14} className="translate-x-[1px]" />}
      </button>
      <div className="flex h-7 flex-1 items-center gap-[2.5px]">
        {bars.map((h, i) => (
          <span
            key={i}
            className={cx(
              "w-[3px] rounded-full transition-colors duration-150",
              i < filled ? (mine ? "bg-white" : "bg-orange-500") : mine ? "bg-white/40" : "bg-orange-300/50"
            )}
            style={{ height: Math.min(h, 26) }}
          />
        ))}
      </div>
      <span className={cx("shrink-0 text-[10.5px] font-bold tabular-nums", mine ? "text-white/80" : "text-cocoa-soft")}>
        {formatDur(playing || cur > 0 ? cur : total)}
      </span>
    </div>
  );
}

/* ================= галочки доставки / прочтения ================= */

export function Ticks({ read, light }: { read: boolean; light: boolean }) {
  return (
    <span
      className={cx(
        "relative inline-flex h-3 w-[15px] shrink-0 items-center transition-colors duration-300",
        read ? (light ? "text-white" : "text-sky-500") : light ? "text-white/60" : "text-cocoa-soft/50"
      )}
      title={read ? "Прочитано" : "Доставлено"}
    >
      <Check size={11} strokeWidth={3.4} className="absolute left-0" />
      <AnimatePresence>
        {read && (
          <motion.span
            initial={{ opacity: 0, x: -3, scale: 0.6 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ type: "spring", stiffness: 520, damping: 26 }}
            className="absolute left-[4.5px]"
          >
            <Check size={11} strokeWidth={3.4} />
          </motion.span>
        )}
      </AnimatePresence>
    </span>
  );
}

/* ================= изображение ================= */

export function ImageBubble({ src }: { src: string }) {
  const [zoom, setZoom] = useState(false);
  return (
    <>
      <motion.img
        src={src}
        alt="Фотография"
        whileHover={{ scale: 1.015 }}
        whileTap={{ scale: 0.985 }}
        onClick={() => {
          sfx.click();
          setZoom(true);
        }}
        className="max-h-[280px] w-auto max-w-full cursor-zoom-in select-none rounded-2xl object-cover"
        draggable={false}
        loading="lazy"
      />
      <AnimatePresence>
        {zoom && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              sfx.close();
              setZoom(false);
            }}
            className="fixed inset-0 z-[120] flex cursor-zoom-out items-center justify-center bg-cocoa/70 p-5 backdrop-blur-md"
          >
            <motion.img
              src={src}
              alt="Фотография"
              initial={{ scale: 0.72, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", stiffness: 260, damping: 26 }}
              className="max-h-[86vh] max-w-[94vw] rounded-3xl shadow-2xl"
              draggable={false}
            />
            <button
              onClick={(e) => {
                e.stopPropagation();
                sfx.close();
                setZoom(false);
              }}
              className="btn-press absolute right-5 top-5 flex h-11 w-11 items-center justify-center rounded-full bg-white/15 text-white backdrop-blur transition-colors hover:bg-white/25"
              aria-label="Закрыть"
            >
              <X size={19} />
            </button>
            <div className="pointer-events-none absolute bottom-5 opacity-60">
              <Logo size={26} withWord={false} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
