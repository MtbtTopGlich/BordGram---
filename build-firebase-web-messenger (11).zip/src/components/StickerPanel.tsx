import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ImagePlus, Loader2, Package, Plus, Smile, Sticker as StickerIcon, Trash2, X } from "lucide-react";
import { useAuth, useToast } from "../state";
import {
  addSticker,
  createPack,
  deletePack,
  deleteSticker,
  EMOJI_CHOICES,
  fileToSticker,
  getPackStickers,
  listenLibrary,
  listenMyPacks,
  removePackFromLibrary,
  type Sticker,
  type StickerPack,
} from "../lib/stickers";
import { getPack } from "../lib/stickers";
import { cx } from "../lib/utils";
import { sfx } from "../lib/sounds";

/* ================= панель стикеров ================= */

export default function StickerPanel({
  open,
  onClose,
  onPick,
  onOpenPack,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (s: Sticker) => void;
  onOpenPack: (packId: string) => void;
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [myPacks, setMyPacks] = useState<StickerPack[]>([]);
  const [libIds, setLibIds] = useState<string[]>([]);
  const [libPacks, setLibPacks] = useState<StickerPack[]>([]);
  const [stickersBy, setStickersBy] = useState<Record<string, Sticker[]>>({});
  const [activePack, setActivePack] = useState<string>("");
  const [creating, setCreating] = useState(false);
  const [adding, setAdding] = useState<StickerPack | null>(null);
  const [manage, setManage] = useState(false);
  const [confirmDel, setConfirmDel] = useState<StickerPack | null>(null);

  useEffect(() => {
    if (!user) return;
    const u1 = listenMyPacks(user.uid, setMyPacks);
    const u2 = listenLibrary(user.uid, setLibIds);
    return () => {
      u1();
      u2();
    };
  }, [user]);

  // подтягиваем добавленные чужие паки
  useEffect(() => {
    if (!user) return;
    const foreign = libIds.filter((id) => !myPacks.some((p) => p.id === id));
    let alive = true;
    void Promise.all(foreign.map((id) => getPack(id))).then((res) => {
      if (alive) setLibPacks(res.filter(Boolean) as StickerPack[]);
    });
    return () => {
      alive = false;
    };
  }, [libIds, myPacks, user]);

  const allPacks = useMemo(() => {
    const seen = new Set<string>();
    return [...myPacks, ...libPacks].filter((p) => {
      if (seen.has(p.id)) return false;
      seen.add(p.id);
      return true;
    });
  }, [myPacks, libPacks]);

  // загружаем стикеры видимых паков
  useEffect(() => {
    if (!open) return;
    allPacks.forEach((p) => {
      if (stickersBy[p.id]) return;
      void getPackStickers(p.id).then((items) =>
        setStickersBy((prev) => ({ ...prev, [p.id]: items }))
      );
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, allPacks]);

  const refreshPack = async (packId: string) => {
    const items = await getPackStickers(packId);
    setStickersBy((prev) => ({ ...prev, [packId]: items }));
  };

  /** Удаление одного стикера (только автор пака) */
  const removeSticker = async (s: Sticker) => {
    if (!user) return;
    setStickersBy((prev) => ({
      ...prev,
      [s.packId]: (prev[s.packId] ?? []).filter((x) => x.id !== s.id),
    }));
    sfx.close();
    try {
      await deleteSticker(s.packId, s.id);
      toast("Стикер удалён", "info");
    } catch {
      toast("Не удалось удалить стикер", "err");
      void refreshPack(s.packId);
    }
  };

  /** Удаление пака целиком */
  const removePack = async (pack: StickerPack) => {
    setConfirmDel(null);
    try {
      await deletePack(pack.id);
      if (user) await removePackFromLibrary(user.uid, pack.id);
      setStickersBy((prev) => {
        const next = { ...prev };
        delete next[pack.id];
        return next;
      });
      setActivePack("");
      setManage(false);
      sfx.close();
      toast(`Пак «${pack.title}» удалён`, "info");
    } catch {
      toast("Не удалось удалить пак", "err");
    }
  };

  useEffect(() => {
    if (open && !activePack && allPacks.length > 0) setActivePack(allPacks[0].id);
  }, [open, activePack, allPacks]);

  const current = allPacks.find((p) => p.id === activePack) ?? allPacks[0] ?? null;
  const currentStickers = current ? (stickersBy[current.id] ?? []) : [];
  const isMine = !!current && current.ownerUid === user?.uid;

  return (
    <>
      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-[70]" onMouseDown={onClose} />
            <motion.div
              initial={{ opacity: 0, y: 14, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.98 }}
              transition={{ type: "spring", stiffness: 420, damping: 32 }}
              className="absolute bottom-[calc(100%+10px)] right-0 z-[71] flex h-[340px] w-[min(94vw,392px)] flex-col overflow-hidden rounded-[24px] border border-orange-100 bg-white shadow-2xl"
            >
              {/* заголовок */}
              <div className="flex items-center gap-1.5 border-b border-orange-100 px-3.5 py-2.5">
                <StickerIcon size={15} className="shrink-0 text-orange-500" />
                <span className="min-w-0 flex-1 truncate text-[13px] font-bold text-cocoa">
                  {current ? current.title : "Стикеры"}
                </span>

                {current && isMine && (
                  <>
                    <button
                      onClick={() => {
                        setManage((v) => !v);
                        sfx.tick();
                      }}
                      title={manage ? "Готово" : "Управлять стикерами"}
                      className={cx(
                        "btn-press rounded-full px-2.5 py-1 text-[10.5px] font-bold transition-colors",
                        manage ? "bg-orange-500 text-white" : "bg-orange-50 text-orange-600 hover:bg-orange-100"
                      )}
                    >
                      {manage ? "готово" : "изменить"}
                    </button>
                    <button
                      onClick={() => {
                        sfx.tick();
                        setConfirmDel(current);
                      }}
                      title="Удалить пак"
                      className="btn-press rounded-full p-1.5 text-cocoa-soft transition-colors hover:bg-red-50 hover:text-red-500"
                    >
                      <Trash2 size={13} />
                    </button>
                  </>
                )}

                {current && !isMine && (
                  <button
                    onClick={() => onOpenPack(current.id)}
                    className="btn-press rounded-full bg-orange-50 px-2.5 py-1 text-[10.5px] font-bold text-orange-600 hover:bg-orange-100"
                  >
                    о паке
                  </button>
                )}
                <button onClick={onClose} className="btn-press rounded-full p-1 text-cocoa-soft hover:text-orange-600">
                  <X size={15} />
                </button>
              </div>

              {/* сетка стикеров */}
              <div className="warm-scroll min-h-0 flex-1 overflow-y-auto p-3">
                {allPacks.length === 0 ? (
                  <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
                    <Package size={30} className="text-orange-300" />
                    <p className="max-w-[230px] text-[12.5px] leading-relaxed text-cocoa-soft">
                      У тебя пока нет стикер-паков. Создай свой — и отправляй друзьям!
                    </p>
                    <button
                      onClick={() => {
                        sfx.click();
                        setCreating(true);
                      }}
                      className="btn-press flex items-center gap-1.5 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-4 py-2 text-xs font-bold text-white shadow-orangeSoft"
                    >
                      <Plus size={13} /> Создать пак
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-4 gap-2">
                    {currentStickers.map((s) => (
                      <div key={s.id} className="group relative aspect-square">
                        <motion.button
                          animate={manage && isMine ? { rotate: [-1.2, 1.2, -1.2] } : { rotate: 0 }}
                          transition={manage && isMine ? { duration: 0.35, repeat: Infinity } : { duration: 0.2 }}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => {
                            if (manage && isMine) return;
                            sfx.send();
                            onPick(s);
                            onClose();
                          }}
                          className="h-full w-full rounded-xl p-1 transition-colors hover:bg-orange-50"
                          title={manage ? "Удалить крестиком" : s.emoji}
                        >
                          <img src={s.image} alt={s.emoji} className="h-full w-full object-contain" draggable={false} />
                        </motion.button>
                        <span className="pointer-events-none absolute bottom-0 left-0.5 text-[10px] opacity-0 transition-opacity group-hover:opacity-100">
                          {s.emoji}
                        </span>
                        {isMine && manage && (
                          <motion.button
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            onClick={() => void removeSticker(s)}
                            title="Удалить стикер"
                            className="btn-press absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-white shadow-md"
                          >
                            <X size={11} />
                          </motion.button>
                        )}
                      </div>
                    ))}

                    {/* кнопка плюса в своём паке */}
                    {isMine && current && (
                      <button
                        onClick={() => {
                          sfx.click();
                          setAdding(current);
                        }}
                        className="btn-press flex aspect-square flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-orange-300 text-orange-500 transition-colors hover:border-orange-500 hover:bg-orange-50"
                        title="Добавить стикер"
                      >
                        <Plus size={20} />
                        <span className="text-[9px] font-bold">стикер</span>
                      </button>
                    )}

                    {currentStickers.length === 0 && !isMine && (
                      <div className="col-span-4 py-10 text-center text-[12.5px] text-cocoa-soft">
                        В этом паке пока нет стикеров
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* нижний ряд паков */}
              <div className="flex items-center gap-1.5 border-t border-orange-100 bg-orange-50/50 px-2.5 py-2">
                <div className="warm-scroll flex min-w-0 flex-1 gap-1.5 overflow-x-auto">
                  {allPacks.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setActivePack(p.id);
                        sfx.tick();
                      }}
                      title={p.title}
                      className={cx(
                        "btn-press flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-xl border-2 bg-white transition-colors",
                        current?.id === p.id ? "border-orange-500" : "border-transparent hover:border-orange-200"
                      )}
                    >
                      {p.cover ? (
                        <img src={p.cover} alt={p.title} className="h-full w-full object-contain p-0.5" />
                      ) : (
                        <Smile size={16} className="text-orange-400" />
                      )}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => {
                    sfx.click();
                    setCreating(true);
                  }}
                  title="Создать стикер-пак"
                  className="btn-press flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeSoft"
                >
                  <Plus size={17} />
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <CreatePackDialog
        open={creating}
        onClose={() => setCreating(false)}
        onCreated={(id) => {
          setActivePack(id);
          toast("Стикер-пак создан! Теперь добавь стикеры", "ok");
        }}
      />

      <AddStickerDialog
        pack={adding}
        onClose={() => setAdding(null)}
        onAdded={(packId) => void refreshPack(packId)}
      />

      {/* подтверждение удаления пака */}
      <Dialog
        open={!!confirmDel}
        onClose={() => setConfirmDel(null)}
        title="Удалить стикер-пак?"
        icon={<Trash2 size={17} />}
      >
        <p className="text-[13px] leading-relaxed text-cocoa-soft">
          Пак <b className="text-cocoa">«{confirmDel?.title}»</b> и все стикеры внутри будут удалены навсегда.
          Он пропадёт и у тех, кто его добавил себе.
        </p>
        <div className="mt-4 flex gap-2">
          <button
            onClick={() => setConfirmDel(null)}
            className="btn-press flex-1 rounded-full bg-orange-100/80 py-3 text-sm font-bold text-cocoa-soft transition hover:text-orange-600"
          >
            Отмена
          </button>
          <button
            onClick={() => confirmDel && void removePack(confirmDel)}
            className="btn-press flex flex-1 items-center justify-center gap-2 rounded-full bg-red-500 py-3 text-sm font-bold text-white shadow-lg transition hover:bg-red-600"
          >
            <Trash2 size={15} /> Удалить
          </button>
        </div>
      </Dialog>
    </>
  );
}

/* ================= создание пака ================= */

function CreatePackDialog({
  open,
  onClose,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: (id: string) => void;
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) setTitle("");
  }, [open]);

  const submit = async () => {
    if (!user) return;
    const t = title.trim();
    if (t.length < 2) {
      toast("Название — минимум 2 символа", "err");
      return;
    }
    setBusy(true);
    try {
      const id = await createPack({
        title: t,
        ownerUid: user.uid,
        ownerName: user.nickname,
        ownerUsername: user.usernameDisplay,
      });
      sfx.success();
      onCreated(id);
      onClose();
    } catch {
      toast("Не удалось создать пак", "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} title="Новый стикер-пак" icon={<Package size={18} />}>
      <p className="mb-3 text-[12.5px] leading-relaxed text-cocoa-soft">
        Придумай название — его увидят все, кому ты отправишь стикер из этого пака
      </p>
      <input
        className="field"
        placeholder="Например: Мои котики"
        value={title}
        maxLength={40}
        autoFocus
        onChange={(e) => setTitle(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && void submit()}
      />
      <button
        onClick={() => void submit()}
        disabled={busy}
        className="btn-press mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 py-3 text-sm font-bold text-white shadow-orangeGlow disabled:opacity-60"
      >
        {busy ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />} Создать пак
      </button>
    </Dialog>
  );
}

/* ================= добавление стикера ================= */

function AddStickerDialog({
  pack,
  onClose,
  onAdded,
}: {
  pack: StickerPack | null;
  onClose: () => void;
  onAdded: (packId: string) => void;
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [emoji, setEmoji] = useState("😀");
  const [image, setImage] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (pack) {
      setEmoji("😀");
      setImage("");
    }
  }, [pack]);

  const submit = async () => {
    if (!user || !pack) return;
    if (!image) {
      toast("Выбери картинку для стикера", "err");
      return;
    }
    setBusy(true);
    try {
      await addSticker({ packId: pack.id, packTitle: pack.title, emoji, image, ownerUid: user.uid });
      sfx.success();
      toast("Стикер добавлен!", "ok");
      onAdded(pack.id);
      onClose();
    } catch {
      toast("Не удалось добавить стикер", "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={!!pack} onClose={onClose} title="Новый стикер" icon={<StickerIcon size={18} />}>
      <div className="flex items-start gap-4">
        <button
          onClick={() => fileRef.current?.click()}
          className={cx(
            "btn-press flex h-28 w-28 shrink-0 items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed transition-colors",
            image ? "border-orange-400 bg-orange-50" : "border-orange-300 hover:border-orange-500 hover:bg-orange-50"
          )}
        >
          {image ? (
            <img src={image} alt="" className="h-full w-full object-contain p-1" />
          ) : (
            <span className="flex flex-col items-center gap-1 text-orange-500">
              <ImagePlus size={22} />
              <span className="text-[10px] font-bold">512 × 512</span>
            </span>
          )}
        </button>
        <div className="min-w-0 flex-1">
          <p className="text-[12px] leading-relaxed text-cocoa-soft">
            Картинка приводится к <b className="text-cocoa">512×512</b> автоматически. Лучше всего — PNG с
            прозрачным фоном.
          </p>
          {image && (
            <button
              onClick={() => setImage("")}
              className="btn-press mt-2 flex items-center gap-1.5 rounded-full bg-red-50 px-3 py-1.5 text-[11px] font-bold text-red-500"
            >
              <Trash2 size={11} /> Убрать
            </button>
          )}
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            try {
              setImage(await fileToSticker(f));
              sfx.tick();
            } catch {
              toast("Картинка слишком большая или повреждена", "err");
            }
            e.target.value = "";
          }}
        />
      </div>

      <div className="mt-4">
        <span className="mb-2 block text-[12.5px] font-semibold text-cocoa-soft">
          Эмодзи для стикера <span className="text-orange-600">{emoji}</span>
        </span>
        <div className="warm-scroll grid max-h-[112px] grid-cols-8 gap-1 overflow-y-auto rounded-2xl bg-orange-50/70 p-2">
          {EMOJI_CHOICES.map((e) => (
            <button
              key={e}
              onClick={() => {
                setEmoji(e);
                sfx.tick();
              }}
              className={cx(
                "flex h-8 items-center justify-center rounded-lg text-[18px] transition-colors",
                emoji === e ? "bg-orange-500/90" : "hover:bg-white"
              )}
            >
              {e}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={() => void submit()}
        disabled={busy}
        className="btn-press mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 py-3 text-sm font-bold text-white shadow-orangeGlow disabled:opacity-60"
      >
        {busy ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />} Выложить стикер
      </button>
    </Dialog>
  );
}

/* ================= просмотр пака ================= */

export function PackViewer({
  packId,
  onClose,
  onPick,
}: {
  packId: string;
  onClose: () => void;
  onPick?: (s: Sticker) => void;
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [pack, setPack] = useState<StickerPack | null>(null);
  const [items, setItems] = useState<Sticker[]>([]);
  const [libIds, setLibIds] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [askDel, setAskDel] = useState(false);

  useEffect(() => {
    if (!packId) return;
    void getPack(packId).then(setPack);
    void getPackStickers(packId).then(setItems);
  }, [packId]);

  useEffect(() => {
    if (!user) return;
    return listenLibrary(user.uid, setLibIds);
  }, [user]);

  const added = libIds.includes(packId);
  const isMine = pack?.ownerUid === user?.uid;

  const toggle = async () => {
    if (!user || !pack) return;
    setBusy(true);
    try {
      const { addPackToLibrary, removePackFromLibrary } = await import("../lib/stickers");
      if (added) {
        await removePackFromLibrary(user.uid, pack.id);
        toast("Пак удалён из твоих стикеров", "info");
      } else {
        await addPackToLibrary(user.uid, pack.id);
        sfx.success();
        toast(`Пак «${pack.title}» добавлен!`, "ok");
      }
    } catch {
      toast("Не получилось", "err");
    } finally {
      setBusy(false);
    }
  };

  const removeOne = async (s: Sticker) => {
    if (!isMine) return;
    await deleteSticker(packId, s.id).catch(() => undefined);
    setItems((prev) => prev.filter((x) => x.id !== s.id));
    sfx.close();
  };

  return (
    <Dialog open={!!packId} onClose={onClose} title={pack?.title ?? "Стикер-пак"} icon={<Package size={18} />}>
      {pack && (
        <div className="mb-3 flex items-center gap-2 text-[12px] font-semibold text-cocoa-soft">
          автор <span className="text-orange-600">@{pack.ownerUsername}</span>
          <span className="ml-auto rounded-full bg-orange-100 px-2.5 py-0.5 text-[11px] font-bold text-orange-700">
            {items.length} шт.
          </span>
        </div>
      )}

      <div className="warm-scroll grid max-h-[280px] grid-cols-4 gap-2 overflow-y-auto rounded-2xl bg-orange-50/50 p-2.5">
        {items.map((s) => (
          <div key={s.id} className="group relative aspect-square">
            <motion.button
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.92 }}
              onClick={() => {
                if (onPick) {
                  sfx.send();
                  onPick(s);
                  onClose();
                }
              }}
              className="h-full w-full rounded-xl p-1 transition-colors hover:bg-white"
            >
              <img src={s.image} alt={s.emoji} className="h-full w-full object-contain" draggable={false} />
            </motion.button>
            <span className="pointer-events-none absolute bottom-0 left-0.5 text-[10px]">{s.emoji}</span>
            {isMine && (
              <button
                onClick={() => void removeOne(s)}
                className="btn-press absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-white opacity-0 shadow transition-opacity group-hover:opacity-100"
                title="Удалить стикер"
              >
                <X size={10} />
              </button>
            )}
          </div>
        ))}
        {items.length === 0 && (
          <div className="col-span-4 py-10 text-center text-[12.5px] text-cocoa-soft">Пак пока пуст</div>
        )}
      </div>

      <div className="mt-4 flex gap-2">
        <button
          onClick={onClose}
          className="btn-press flex-1 rounded-full bg-orange-100/80 py-3 text-sm font-bold text-cocoa-soft transition hover:text-orange-600"
        >
          Закрыть
        </button>
        {!isMine && (
          <button
            onClick={() => void toggle()}
            disabled={busy}
            className={cx(
              "btn-press flex flex-[1.4] items-center justify-center gap-2 rounded-full py-3 text-sm font-bold transition disabled:opacity-60",
              added
                ? "bg-red-50 text-red-500 hover:bg-red-100"
                : "bg-gradient-to-r from-orange-600 to-amber-500 text-white shadow-orangeGlow hover:brightness-105"
            )}
          >
            {busy ? <Loader2 size={15} className="animate-spin" /> : added ? <X size={15} /> : <Plus size={15} />}
            {added ? "Удалить пак" : "Добавить себе"}
          </button>
        )}
        {isMine && (
          <button
            onClick={() => {
              sfx.tick();
              setAskDel(true);
            }}
            className="btn-press flex flex-1 items-center justify-center gap-2 rounded-full bg-red-50 py-3 text-sm font-bold text-red-500 transition hover:bg-red-100"
          >
            <Trash2 size={15} /> Удалить пак
          </button>
        )}
      </div>

      <AnimatePresence>
        {askDel && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-3 rounded-2xl border border-red-200 bg-red-50/80 p-3.5">
              <p className="text-[12.5px] font-semibold leading-relaxed text-red-700">
                Удалить пак «{pack?.title}» со всеми стикерами? Отменить будет нельзя.
              </p>
              <div className="mt-2.5 flex gap-2">
                <button
                  onClick={() => setAskDel(false)}
                  className="btn-press flex-1 rounded-full bg-white py-2 text-[12px] font-bold text-cocoa-soft"
                >
                  Отмена
                </button>
                <button
                  onClick={async () => {
                    if (!pack) return;
                    setAskDel(false);
                    await deletePack(pack.id);
                    if (user) await removePackFromLibrary(user.uid, pack.id).catch(() => undefined);
                    sfx.close();
                    toast("Пак удалён", "info");
                    onClose();
                  }}
                  className="btn-press flex-1 rounded-full bg-red-500 py-2 text-[12px] font-bold text-white"
                >
                  Да, удалить
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Dialog>
  );
}

/* ================= простая обёртка-диалог ================= */

function Dialog({
  open,
  onClose,
  title,
  icon,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[130] flex items-center justify-center bg-cocoa/30 p-4 backdrop-blur-sm"
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 14, scale: 0.97 }}
            transition={{ type: "spring", stiffness: 400, damping: 32 }}
            className="w-full max-w-sm rounded-[26px] border border-orange-100 bg-cream p-5 shadow-2xl"
          >
            <div className="mb-4 flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-amber-400 text-white shadow-orangeSoft">
                {icon}
              </span>
              <h3 className="flex-1 truncate font-display text-[16px] font-bold">{title}</h3>
              <button onClick={onClose} className="btn-press rounded-full p-1.5 text-cocoa-soft hover:text-orange-600">
                <X size={16} />
              </button>
            </div>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
