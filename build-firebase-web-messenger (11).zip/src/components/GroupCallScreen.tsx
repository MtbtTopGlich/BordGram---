import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Mic, MicOff, Minimize2, Monitor, MonitorOff, PhoneOff, Users, Video, VideoOff } from "lucide-react";
import { Avatar } from "./bits";
import {
  getDisplayStream,
  getLocalStream,
  ICE_CONFIG,
  fmtCallTime,
  stopStream,
  tuneSenderForScreen,
} from "../lib/calls";
import { clearPair, isPolite, listenPair, pairId, sendDesc, sendIce } from "../lib/groupRtc";
import { joinGroupCall, leaveGroupCall, listenGroupCall, listenMembers, type Group, type GroupMember } from "../lib/groups";
import { getSavedDeviceId } from "../lib/devices";
import type { Profile } from "../db";
import { cx } from "../lib/utils";
import { sfx } from "../lib/sounds";

type PeerBox = {
  uid: string;
  stream: MediaStream;
  hasVideo: boolean;
};

export default function GroupCallScreen({
  group,
  me,
  kind,
  minimized,
  onMinimize,
  onLeave,
}: {
  group: Group;
  me: Profile;
  kind: "audio" | "video";
  minimized: boolean;
  onMinimize: () => void;
  onLeave: () => void;
}) {
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [participants, setParticipants] = useState<string[]>([]);
  const [peers, setPeers] = useState<PeerBox[]>([]);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(kind === "video");
  const [sharing, setSharing] = useState(false);
  const [seconds, setSeconds] = useState(0);

  const pcs = useRef<Map<string, RTCPeerConnection>>(new Map());
  const subs = useRef<Map<string, Unsub>>(new Map());
  const senders = useRef<Map<string, { audio: RTCRtpSender; video: RTCRtpSender }>>(new Map());
  const localStream = useRef<MediaStream | null>(null);
  const screenStream = useRef<MediaStream | null>(null);
  const makingOffer = useRef<Map<string, boolean>>(new Map());
  const pendingIce = useRef<Map<string, RTCIceCandidateInit[]>>(new Map());
  const localVideo = useRef<HTMLVideoElement>(null);

  type Unsub = () => void;

  /* ---------- локальное медиа ---------- */
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const s = await getLocalStream({
          video: kind === "video",
          micId: getSavedDeviceId("mic"),
          camId: getSavedDeviceId("cam"),
        });
        if (cancelled) {
          stopStream(s);
          return;
        }
        localStream.current = s;
        setCamOn(s.getVideoTracks().length > 0);
        if (localVideo.current) localVideo.current.srcObject = s;
        await joinGroupCall(group.id, me.uid);
      } catch {
        onLeave();
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => listenMembers(group.id, setMembers), [group.id]);

  useEffect(() => {
    return listenGroupCall(group.id, (c) => {
      setParticipants(c.participants ?? []);
      if (!c.active) onLeave();
    });
  }, [group.id, onLeave]);

  useEffect(() => {
    const t = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(t);
  }, []);

  /* ---------- mesh ---------- */
  const connectTo = useCallback(
    (other: string) => {
      if (pcs.current.has(other) || other === me.uid || !localStream.current) return;
      const pid = pairId(me.uid, other);
      const polite = isPolite(me.uid, other);
      const pc = new RTCPeerConnection(ICE_CONFIG);
      pcs.current.set(other, pc);
      pendingIce.current.set(other, []);

      const aT = pc.addTransceiver("audio", { direction: "sendrecv" });
      const vT = pc.addTransceiver("video", { direction: "sendrecv" });
      senders.current.set(other, { audio: aT.sender, video: vT.sender });

      const a = localStream.current.getAudioTracks()[0];
      const v = sharing
        ? screenStream.current?.getVideoTracks()[0]
        : localStream.current.getVideoTracks()[0];
      if (a) void aT.sender.replaceTrack(a);
      if (v) void vT.sender.replaceTrack(v);

      const remote = new MediaStream();
      pc.ontrack = (e) => {
        if (!remote.getTracks().some((t) => t.id === e.track.id)) remote.addTrack(e.track);
        const refresh = () =>
          setPeers((prev) => {
            const has = remote.getVideoTracks().some((t) => t.readyState === "live" && !t.muted);
            const next = prev.filter((p) => p.uid !== other);
            return [...next, { uid: other, stream: remote, hasVideo: has }];
          });
        e.track.onunmute = refresh;
        e.track.onmute = refresh;
        refresh();
      };

      pc.onicecandidate = (e) => {
        if (e.candidate) void sendIce(group.id, pid, me.uid, e.candidate.toJSON());
      };

      pc.onnegotiationneeded = async () => {
        try {
          makingOffer.current.set(other, true);
          await pc.setLocalDescription();
          await sendDesc(group.id, pid, me.uid, pc.localDescription);
        } catch {
          /* noop */
        } finally {
          makingOffer.current.set(other, false);
        }
      };

      const un = listenPair(
        group.id,
        pid,
        me.uid,
        async (d) => {
          try {
            const offerCollision =
              d.type === "offer" && (makingOffer.current.get(other) || pc.signalingState !== "stable");
            if (offerCollision && !polite) return;
            await pc.setRemoteDescription({ type: d.type, sdp: d.sdp });
            const queued = pendingIce.current.get(other) ?? [];
            pendingIce.current.set(other, []);
            for (const c of queued) await pc.addIceCandidate(new RTCIceCandidate(c)).catch(() => undefined);
            if (d.type === "offer") {
              await pc.setLocalDescription();
              await sendDesc(group.id, pid, me.uid, pc.localDescription);
            }
          } catch {
            /* noop */
          }
        },
        (c) => {
          if (!pc.remoteDescription) {
            pendingIce.current.get(other)?.push(c);
            return;
          }
          void pc.addIceCandidate(new RTCIceCandidate(c)).catch(() => undefined);
        }
      );
      subs.current.set(other, un);
    },
    [group.id, me.uid, sharing]
  );

  const disconnectFrom = useCallback(
    (other: string) => {
      subs.current.get(other)?.();
      subs.current.delete(other);
      pcs.current.get(other)?.close();
      pcs.current.delete(other);
      senders.current.delete(other);
      setPeers((p) => p.filter((x) => x.uid !== other));
      void clearPair(group.id, pairId(me.uid, other));
    },
    [group.id, me.uid]
  );

  // синхронизируем соединения со списком участников
  useEffect(() => {
    if (!localStream.current) return;
    const others = participants.filter((p) => p !== me.uid);
    others.forEach(connectTo);
    Array.from(pcs.current.keys()).forEach((uid) => {
      if (!others.includes(uid)) disconnectFrom(uid);
    });
  }, [participants, connectTo, disconnectFrom, me.uid]);

  /* ---------- выход ---------- */
  const hangUp = useCallback(() => {
    Array.from(pcs.current.keys()).forEach(disconnectFrom);
    stopStream(localStream.current);
    stopStream(screenStream.current);
    localStream.current = null;
    screenStream.current = null;
    void leaveGroupCall(group.id, me.uid);
    sfx.close();
    onLeave();
  }, [disconnectFrom, group.id, me.uid, onLeave]);

  useEffect(() => {
    return () => {
      Array.from(pcs.current.values()).forEach((pc) => pc.close());
      stopStream(localStream.current);
      stopStream(screenStream.current);
    };
  }, []);

  /* ---------- управление ---------- */
  const toggleMic = () => {
    const t = localStream.current?.getAudioTracks()[0];
    if (!t) return;
    t.enabled = !t.enabled;
    setMicOn(t.enabled);
    sfx.tick();
  };

  const toggleCam = async () => {
    const existing = localStream.current?.getVideoTracks()[0];
    if (camOn && existing) {
      existing.stop();
      localStream.current?.removeTrack(existing);
      senders.current.forEach((s) => void s.video.replaceTrack(sharing ? s.video.track : null));
      setCamOn(false);
      sfx.tick();
      return;
    }
    try {
      const s = await getLocalStream({ video: true, camId: getSavedDeviceId("cam") });
      const v = s.getVideoTracks()[0];
      s.getAudioTracks().forEach((t) => t.stop());
      if (!v || !localStream.current) return;
      localStream.current.addTrack(v);
      if (!sharing) senders.current.forEach((x) => void x.video.replaceTrack(v));
      if (localVideo.current) localVideo.current.srcObject = localStream.current;
      setCamOn(true);
      sfx.success();
    } catch {
      /* noop */
    }
  };

  const toggleShare = async () => {
    if (sharing) {
      stopStream(screenStream.current);
      screenStream.current = null;
      const cam = camOn ? localStream.current?.getVideoTracks()[0] ?? null : null;
      senders.current.forEach((s) => {
        void s.video.replaceTrack(cam);
        void tuneSenderForScreen(s.video, false);
      });
      if (localVideo.current && localStream.current) localVideo.current.srcObject = localStream.current;
      setSharing(false);
      return;
    }
    try {
      const screen = await getDisplayStream();
      screenStream.current = screen;
      const track = screen.getVideoTracks()[0];
      senders.current.forEach((s) => {
        void s.video.replaceTrack(track);
        void tuneSenderForScreen(s.video, true);
      });
      track.onended = () => void toggleShare();
      if (localVideo.current) localVideo.current.srcObject = screen;
      setSharing(true);
      sfx.success();
    } catch {
      /* отменено */
    }
  };

  const nameOf = (uid: string) => members.find((m) => m.uid === uid)?.nickname ?? "Участник";
  const avatarOf = (uid: string) => members.find((m) => m.uid === uid)?.avatar ?? "";
  const tiles = participants.filter((p) => p !== me.uid);
  const cols = tiles.length <= 1 ? 1 : tiles.length <= 4 ? 2 : 3;

  if (minimized) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex flex-col bg-[#1b0f08]"
    >
      {/* шапка */}
      <div className="flex items-center gap-3 bg-black/40 px-5 py-3.5 backdrop-blur">
        <Avatar src={group.avatar} name={group.title} seed={group.invite} size={38} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="truncate text-[15px] font-bold text-white">{group.title}</span>
            <span className="flex shrink-0 items-center gap-1 rounded-full bg-orange-500/90 px-2 py-0.5 text-[10px] font-bold text-white">
              <Users size={9} /> группа
            </span>
          </div>
          <div className="text-[12px] font-semibold text-white/65">
            {fmtCallTime(seconds)} · {participants.length} в звонке
          </div>
        </div>
        <button
          onClick={onMinimize}
          title="Свернуть"
          className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-white/15 text-white hover:bg-white/25"
        >
          <Minimize2 size={17} />
        </button>
      </div>

      {/* сетка участников */}
      <div className="min-h-0 flex-1 overflow-auto p-3">
        <div
          className="grid h-full gap-3"
          style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
        >
          {tiles.length === 0 && (
            <div className="col-span-full flex flex-col items-center justify-center gap-3 text-center">
              <Users size={34} className="text-white/30" />
              <p className="text-sm font-semibold text-white/70">Ждём участников…</p>
              <p className="text-xs text-white/40">Остальные увидят приглашение в группе</p>
            </div>
          )}
          {tiles.map((uid) => {
            const box = peers.find((p) => p.uid === uid);
            return (
              <div
                key={uid}
                className="relative flex min-h-[150px] items-center justify-center overflow-hidden rounded-2xl bg-[#241408]"
              >
                {box && box.hasVideo ? (
                  <video
                    autoPlay
                    playsInline
                    className="h-full w-full object-cover"
                    ref={(el) => {
                      if (el && el.srcObject !== box.stream) el.srcObject = box.stream;
                    }}
                  />
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <Avatar src={avatarOf(uid)} name={nameOf(uid)} seed={uid} size={62} />
                    <span className="text-[12px] font-bold text-white/80">{nameOf(uid)}</span>
                  </div>
                )}
                {box && (
                  <audio
                    autoPlay
                    ref={(el) => {
                      if (el && el.srcObject !== box.stream) el.srcObject = box.stream;
                    }}
                  />
                )}
                <span className="absolute bottom-2 left-2 rounded-full bg-black/55 px-2.5 py-1 text-[10.5px] font-bold text-white">
                  {nameOf(uid)}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* своё окно */}
      <div className="pointer-events-none absolute bottom-28 right-5 h-[120px] w-[90px] overflow-hidden rounded-2xl border-2 border-white/25 bg-black shadow-2xl sm:h-[150px] sm:w-[112px]">
        <video ref={localVideo} autoPlay muted playsInline className={cx("h-full w-full object-cover", !sharing && "-scale-x-100")} />
        {!camOn && !sharing && (
          <div className="absolute inset-0 flex items-center justify-center bg-[#241408]">
            <VideoOff size={18} className="text-white/50" />
          </div>
        )}
        <span className="absolute bottom-1 left-1.5 text-[9.5px] font-bold text-white/80">
          {sharing ? "экран" : "ты"}
        </span>
      </div>

      {/* кнопки */}
      <div className="shrink-0 bg-black/50 px-4 pb-6 pt-4 backdrop-blur-xl">
        <div className="mx-auto flex max-w-md items-center justify-center gap-3 sm:gap-4">
          <Btn active={micOn} onClick={toggleMic}>
            {micOn ? <Mic size={20} /> : <MicOff size={20} />}
          </Btn>
          <Btn active={camOn} onClick={() => void toggleCam()}>
            {camOn ? <Video size={20} /> : <VideoOff size={20} />}
          </Btn>
          <Btn active={sharing} highlight={sharing} onClick={() => void toggleShare()}>
            {sharing ? <MonitorOff size={20} /> : <Monitor size={20} />}
          </Btn>
          <button
            onClick={hangUp}
            title="Выйти из звонка"
            className="btn-press flex h-[58px] w-[58px] shrink-0 items-center justify-center rounded-full bg-red-500 text-white shadow-[0_8px_26px_rgba(239,68,68,0.5)] hover:bg-red-600"
          >
            <PhoneOff size={23} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function Btn({
  children,
  onClick,
  active,
  highlight,
}: {
  children: React.ReactNode;
  onClick: () => void;
  active: boolean;
  highlight?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cx(
        "btn-press flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-full border transition-colors",
        highlight
          ? "border-orange-400 bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeGlow"
          : active
            ? "border-white/20 bg-white/15 text-white hover:bg-white/25"
            : "border-white/10 bg-white/90 text-cocoa hover:bg-white"
      )}
    >
      {children}
    </button>
  );
}
