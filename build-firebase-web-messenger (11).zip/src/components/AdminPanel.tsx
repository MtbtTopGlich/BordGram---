import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AtSign, Ban, BadgeCheck, Crown, FlaskConical, ShieldCheck, ShieldOff, Search, Undo2, UserRound, XCircle } from "lucide-react";
import { Avatar, BadgeMark, Spinner } from "./bits";
import { useAuth, useToast } from "../state";
import {
  getUserByUsername,
  isAdmin,
  isOwner,
  setUserAdmin,
  setUserBadge,
  setUserBanned,
  type Profile,
} from "../db";
import { cx, normalizeUsername } from "../lib/utils";
import { sfx } from "../lib/sounds";

type Found = { kind: "idle" } | { kind: "loading" } | { kind: "none"; q: string } | { kind: "ok"; p: Profile };

export default function AdminPanel() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [q, setQ] = useState("");
  const [found, setFound] = useState<Found>({ kind: "idle" });
  const [busy, setBusy] = useState("");
  const [reason, setReason] = useState("");

  if (!user || !isAdmin(user)) {
    return (
      <div className="rounded-2xl border border-red-200 bg-red-50/70 p-5 text-center">
        <ShieldOff size={22} className="mx-auto mb-2 text-red-400" />
        <p className="text-sm font-bold text-red-600">Доступ только для администраторов</p>
      </div>
    );
  }

  const search = async () => {
    const u = normalizeUsername(q);
    if (u.length < 3) {
      toast("Введи полный username (минимум 3 символа)", "err");
      return;
    }
    setFound({ kind: "loading" });
    try {
      const p = await getUserByUsername(u);
      setFound(p ? { kind: "ok", p } : { kind: "none", q: u });
      if (p) sfx.success();
      else sfx.error();
    } catch {
      setFound({ kind: "none", q: u });
      toast("Ошибка поиска", "err");
    }
  };

  const refresh = async (username: string) => {
    const p = await getUserByUsername(username).catch(() => null);
    if (p) setFound({ kind: "ok", p });
  };

  const target = found.kind === "ok" ? found.p : null;
  const targetIsOwner = isOwner(target);
  const targetIsAdmin = isAdmin(target);
  const isSelf = target?.uid === user.uid;

  const act = async (
    key: string,
    fn: () => Promise<void>,
    okMsg: string
  ) => {
    if (!target) return;
    if (targetIsOwner && key !== "none") {
      toast("Владельца сервиса изменить нельзя", "err");
      sfx.error();
      return;
    }
    setBusy(key);
    try {
      await fn();
      await refresh(target.username);
      toast(okMsg, "ok");
    } catch {
      toast("Не удалось выполнить действие", "err");
    } finally {
      setBusy("");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2.5 rounded-2xl border border-orange-200 bg-gradient-to-r from-orange-50 to-amber-50 p-3.5">
        <Crown size={17} className="shrink-0 text-orange-500" />
        <p className="text-[12.5px] font-semibold leading-snug text-cocoa">
          Ты вошёл как {isOwner(user) ? "владелец" : "администратор"} — доступны действия над аккаунтами
        </p>
      </div>

      {/* поиск */}
      <div>
        <span className="mb-1.5 block text-[13px] font-semibold text-cocoa-soft">Найти пользователя по username</span>
        <div className="flex gap-2">
          <div className="relative flex-1">
            <AtSign size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
            <input
              className="field !py-3 pl-11 text-sm"
              placeholder="bordgram"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && void search()}
            />
          </div>
          <button
            onClick={() => void search()}
            className="btn-press flex h-[46px] w-[46px] shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeSoft"
            title="Найти"
          >
            {found.kind === "loading" ? <Spinner size={16} className="border-white/40 border-t-white" /> : <Search size={17} />}
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {found.kind === "none" && (
          <motion.div
            key="none"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="rounded-2xl border border-dashed border-orange-200 bg-white/60 p-5 text-center text-sm font-medium text-cocoa-soft"
          >
            Пользователь <span className="font-bold text-cocoa">@{found.q}</span> не найден
          </motion.div>
        )}

        {target && (
          <motion.div
            key={target.uid}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="overflow-hidden rounded-2xl border border-orange-100 bg-white shadow-warm"
          >
            {/* карточка */}
            <div className="flex items-center gap-3 p-4">
              <Avatar src={target.avatar} name={target.nickname} seed={target.username} size={54} />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="truncate text-[15px] font-bold">{target.nickname}</span>
                  {targetIsOwner && (
                    <span className="flex items-center gap-1 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-2 py-0.5 text-[10px] font-bold text-white">
                      <Crown size={9} /> владелец
                    </span>
                  )}
                  {!targetIsOwner && targetIsAdmin && (
                    <span className="flex items-center gap-1 rounded-full bg-orange-100 px-2 py-0.5 text-[10px] font-bold text-orange-700">
                      <ShieldCheck size={9} /> админ
                    </span>
                  )}
                  {target.banned && (
                    <span className="flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-bold text-red-600">
                      <Ban size={9} /> забанен
                    </span>
                  )}
                  <BadgeMark badge={target.badge} withText />
                </div>
                <div className="truncate text-[12.5px] font-semibold text-orange-600">@{target.usernameDisplay}</div>
                <div className="truncate text-[11.5px] text-cocoa-soft">{target.email}</div>
              </div>
            </div>

            {target.bio && (
              <p className="border-t border-orange-50 px-4 py-2.5 text-[12.5px] leading-relaxed text-cocoa-soft">{target.bio}</p>
            )}

            {/* причина бана */}
            {!target.banned && !targetIsOwner && (
              <div className="border-t border-orange-50 px-4 pt-3">
                <input
                  className="field !py-2.5 text-[13px]"
                  placeholder="Причина бана (необязательно)"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
              </div>
            )}
            {target.banned && target.banReason && (
              <p className="border-t border-orange-50 px-4 py-2.5 text-[12px] font-semibold text-red-500">
                Причина: {target.banReason}
              </p>
            )}

            {/* кнопки */}
            <div className="grid grid-cols-2 gap-2 p-4">
              <AdminBtn
                label="Забанить"
                icon={<Ban size={14} />}
                tone="danger"
                disabled={!!target.banned || targetIsOwner || isSelf || !!busy}
                loading={busy === "ban"}
                onClick={() => void act("ban", () => setUserBanned(target.uid, true, reason.trim()), `@${target.usernameDisplay} забанен`)}
              />
              <AdminBtn
                label="Разблокировать"
                icon={<Undo2 size={14} />}
                tone="ok"
                disabled={!target.banned || !!busy}
                loading={busy === "unban"}
                onClick={() => void act("unban", () => setUserBanned(target.uid, false), `@${target.usernameDisplay} разблокирован`)}
              />
              <AdminBtn
                label="Выдать админку"
                icon={<ShieldCheck size={14} />}
                tone="brand"
                disabled={targetIsAdmin || !!busy}
                loading={busy === "grant"}
                onClick={() => void act("grant", () => setUserAdmin(target.uid, true), `@${target.usernameDisplay} теперь админ`)}
              />
              <AdminBtn
                label="Забрать админку"
                icon={<ShieldOff size={14} />}
                tone="neutral"
                disabled={!targetIsAdmin || targetIsOwner || !!busy}
                loading={busy === "revoke"}
                onClick={() => void act("revoke", () => setUserAdmin(target.uid, false), `Админка снята с @${target.usernameDisplay}`)}
              />
            </div>
            {/* значки */}
            <div className="border-t border-orange-50 px-4 pb-4">
              <div className="mb-2 mt-3 text-[10.5px] font-bold uppercase tracking-wider text-cocoa-soft/70">
                Значок у имени
              </div>
              <div className="grid grid-cols-3 gap-2">
                <BadgeBtn
                  label="Проверен"
                  icon={<BadgeCheck size={14} />}
                  tone="verified"
                  activeNow={target.badge === "verified"}
                  disabled={!!busy}
                  loading={busy === "b-verified"}
                  onClick={() =>
                    void act("b-verified", () => setUserBadge(target.uid, "verified"), `@${target.usernameDisplay} верифицирован`)
                  }
                />
                <BadgeBtn
                  label="Тестировщик"
                  icon={<FlaskConical size={14} />}
                  tone="tester"
                  activeNow={target.badge === "tester"}
                  disabled={!!busy}
                  loading={busy === "b-tester"}
                  onClick={() =>
                    void act("b-tester", () => setUserBadge(target.uid, "tester"), `@${target.usernameDisplay} — тестировщик`)
                  }
                />
                <BadgeBtn
                  label="Убрать"
                  icon={<XCircle size={14} />}
                  tone="none"
                  activeNow={!target.badge || target.badge === "none"}
                  disabled={!!busy || !target.badge || target.badge === "none"}
                  loading={busy === "b-none"}
                  onClick={() =>
                    void act("b-none", () => setUserBadge(target.uid, "none"), `Значок снят с @${target.usernameDisplay}`)
                  }
                />
              </div>
            </div>

            {isSelf && (
              <p className="px-4 pb-4 text-[11.5px] font-semibold text-cocoa-soft">Себя забанить нельзя — это твой аккаунт</p>
            )}
          </motion.div>
        )}

        {found.kind === "idle" && (
          <motion.div
            key="idle"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="rounded-2xl border border-dashed border-orange-200 bg-white/50 p-6 text-center"
          >
            <UserRound size={22} className="mx-auto mb-2 text-orange-300" />
            <p className="text-[12.5px] leading-relaxed text-cocoa-soft">
              Впиши точный @username — появится карточка с действиями
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function BadgeBtn({
  label,
  icon,
  tone,
  activeNow,
  disabled,
  loading,
  onClick,
}: {
  label: string;
  icon: React.ReactNode;
  tone: "verified" | "tester" | "none";
  activeNow: boolean;
  disabled?: boolean;
  loading?: boolean;
  onClick: () => void;
}) {
  const tones = {
    verified: activeNow ? "bg-sky-500 text-white shadow" : "bg-sky-50 text-sky-600 hover:bg-sky-100",
    tester: activeNow ? "bg-violet-500 text-white shadow" : "bg-violet-50 text-violet-600 hover:bg-violet-100",
    none: "bg-orange-100/80 text-cocoa-soft hover:bg-orange-200/80",
  } as const;
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={cx(
        "btn-press flex flex-col items-center justify-center gap-1 rounded-xl px-2 py-2.5 text-[11px] font-bold transition-colors disabled:cursor-not-allowed disabled:opacity-40",
        tones[tone]
      )}
    >
      {loading ? <Spinner size={13} /> : icon}
      {label}
    </button>
  );
}

function AdminBtn({
  label,
  icon,
  tone,
  disabled,
  loading,
  onClick,
}: {
  label: string;
  icon: React.ReactNode;
  tone: "danger" | "ok" | "brand" | "neutral";
  disabled?: boolean;
  loading?: boolean;
  onClick: () => void;
}) {
  const tones = {
    danger: "bg-red-50 text-red-600 hover:bg-red-100",
    ok: "bg-emerald-50 text-emerald-600 hover:bg-emerald-100",
    brand: "bg-gradient-to-r from-orange-600 to-amber-500 text-white shadow-orangeSoft hover:brightness-105",
    neutral: "bg-orange-100/80 text-cocoa-soft hover:bg-orange-200/80 hover:text-cocoa",
  } as const;
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={cx(
        "btn-press flex items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-[12.5px] font-bold transition-colors disabled:cursor-not-allowed disabled:opacity-40",
        tones[tone]
      )}
    >
      {loading ? <Spinner size={13} /> : icon}
      {label}
    </button>
  );
}
