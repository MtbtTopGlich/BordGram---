import { AtSign, Ban, Calendar, Crown, MessageCircle, Phone, ShieldCheck, Star, UserCheck, Video } from "lucide-react";
import { ModalShell, Avatar, BadgeMark } from "./bits";
import { useCalls } from "./CallUI";
import { isAdmin, isOwner, type Profile } from "../db";
import { usePeerOnline } from "../lib/live";
import { cx } from "../lib/utils";
import { sfx } from "../lib/sounds";

function joinedText(v: unknown): string {
  const d = v && typeof v === "object" && "seconds" in v ? new Date((v as { seconds: number }).seconds * 1000) : null;
  if (!d) return "—";
  return d.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" });
}

export default function UserInfoModal({
  open,
  onClose,
  profile,
  isContact,
  isFav,
  blocked,
  onToggleFav,
  onBlock,
  onMessage,
}: {
  open: boolean;
  onClose: () => void;
  profile: Profile | null;
  isContact: boolean;
  isFav?: boolean;
  blocked?: boolean;
  onToggleFav?: () => void;
  onBlock?: () => void;
  onMessage?: () => void;
}) {
  const { startCall, busy } = useCalls();
  const { online, lastSeen } = usePeerOnline(profile?.uid);

  if (!profile) return null;

  const call = (type: "audio" | "video") => {
    sfx.click();
    onClose();
    startCall(profile, type);
  };

  return (
    <ModalShell open={open} onClose={onClose} maxW="max-w-sm">
      <div className="flex flex-col items-center pt-1 text-center">
        <div className="relative">
          <Avatar src={profile.avatar} name={profile.nickname} seed={profile.username} size={96} />
          {online && (
            <span className="absolute bottom-1 right-1 h-5 w-5 rounded-full border-[3px] border-cream bg-emerald-400" />
          )}
        </div>

        <h3 className="mt-3.5 flex items-center justify-center gap-1.5 font-display text-xl font-bold leading-tight">
          {profile.nickname}
          <BadgeMark badge={profile.badge} size={17} />
        </h3>

        <div className="mt-1 flex items-center gap-1.5 text-[13px] font-bold text-orange-600">
          <AtSign size={13} />
          {profile.usernameDisplay}
        </div>

        <div className="mt-2 flex flex-wrap items-center justify-center gap-1.5">
          <span
            className={cx(
              "flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold",
              online ? "bg-emerald-50 text-emerald-600" : "bg-orange-100/70 text-cocoa-soft"
            )}
          >
            <span className={cx("h-1.5 w-1.5 rounded-full", online ? "bg-emerald-500" : "bg-cocoa-soft/40")} />
            {online ? "в сети" : lastSeen > 0 ? "недавно" : "не в сети"}
          </span>
          {isOwner(profile) ? (
            <span className="flex items-center gap-1 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-2.5 py-1 text-[11px] font-bold text-white">
              <Crown size={10} /> владелец
            </span>
          ) : isAdmin(profile) ? (
            <span className="flex items-center gap-1 rounded-full bg-orange-100 px-2.5 py-1 text-[11px] font-bold text-orange-700">
              <ShieldCheck size={10} /> админ
            </span>
          ) : null}
          {isContact && (
            <span className="flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-bold text-emerald-600">
              <UserCheck size={10} /> в контактах
            </span>
          )}
          <BadgeMark badge={profile.badge} withText />
          {profile.banned && (
            <span className="flex items-center gap-1 rounded-full bg-red-100 px-2.5 py-1 text-[11px] font-bold text-red-600">
              <Ban size={10} /> заблокирован
            </span>
          )}
        </div>

        {profile.bio && (
          <p className="mt-4 w-full rounded-2xl bg-white/70 px-4 py-3 text-[13px] leading-relaxed text-cocoa-soft">
            {profile.bio}
          </p>
        )}

        <div className="mt-3 flex w-full items-center gap-2 rounded-2xl bg-white/70 px-4 py-2.5 text-left">
          <Calendar size={14} className="shrink-0 text-orange-500" />
          <span className="text-[12px] font-semibold text-cocoa-soft">
            В BordGram с {joinedText(profile.createdAt)}
          </span>
        </div>

        {/* звонки */}
        <div className="mt-4 grid w-full grid-cols-2 gap-2">
          <button
            disabled={busy || blocked}
            onClick={() => call("audio")}
            className="btn-press flex items-center justify-center gap-2 rounded-2xl bg-orange-100/80 py-3 text-[13px] font-bold text-cocoa transition hover:bg-orange-200/80 disabled:opacity-40"
          >
            <Phone size={15} /> Аудио
          </button>
          <button
            disabled={busy || blocked}
            onClick={() => call("video")}
            className="btn-press flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-orange-600 to-amber-500 py-3 text-[13px] font-bold text-white shadow-orangeSoft transition hover:brightness-105 disabled:opacity-40"
          >
            <Video size={15} /> Видео
          </button>
        </div>

        {/* действия */}
        <div className="mt-2 grid w-full grid-cols-2 gap-2">
          {onMessage && (
            <button
              onClick={() => {
                sfx.click();
                onClose();
                onMessage();
              }}
              className="btn-press flex items-center justify-center gap-2 rounded-2xl bg-white py-3 text-[13px] font-bold text-cocoa shadow-warm transition hover:bg-orange-50"
            >
              <MessageCircle size={15} /> Написать
            </button>
          )}
          {isContact && onToggleFav && (
            <button
              onClick={onToggleFav}
              className={cx(
                "btn-press flex items-center justify-center gap-2 rounded-2xl py-3 text-[13px] font-bold shadow-warm transition",
                isFav ? "bg-orange-500 text-white hover:brightness-105" : "bg-white text-cocoa hover:bg-orange-50"
              )}
            >
              <Star size={15} className={isFav ? "fill-white" : ""} /> {isFav ? "В избранном" : "В избранные"}
            </button>
          )}
          {onBlock && (
            <button
              onClick={onBlock}
              className={cx(
                "btn-press flex items-center justify-center gap-2 rounded-2xl py-3 text-[13px] font-bold transition",
                "bg-red-50 text-red-500 hover:bg-red-100",
                !isContact && !onMessage ? "col-span-2" : ""
              )}
            >
              <Ban size={15} /> {blocked ? "Разблокировать" : "Заблокировать"}
            </button>
          )}
        </div>
      </div>
    </ModalShell>
  );
}
