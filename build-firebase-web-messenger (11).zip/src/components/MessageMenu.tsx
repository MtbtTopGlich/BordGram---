import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Copy, Pencil, Pin, Reply, Trash2, Users, UserRound } from "lucide-react";
import { cx } from "../lib/utils";
import { sfx } from "../lib/sounds";

export const REACTIONS = ["❤️", "😂", "👍", "🔥", "😮", "😢", "🙏"];

export type MenuTarget = {
  id: string;
  mine: boolean;
  canEdit: boolean;
  x: number;
  y: number;
  myReaction?: string;
};

export type MenuAction = "edit" | "delete" | "reply" | "copy" | "pin-me" | "pin-both";

const MENU_W = 228;

export default function MessageMenu({
  target,
  onClose,
  onAction,
  onReact,
}: {
  target: MenuTarget | null;
  onClose: () => void;
  onAction: (a: MenuAction, id: string) => void;
  onReact: (id: string, emoji: string) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [askPin, setAskPin] = useState(false);

  useEffect(() => {
    if (target) setAskPin(false);
  }, [target]);

  // держим меню внутри экрана
  useLayoutEffect(() => {
    if (!target) return;
    const el = ref.current;
    const h = el?.offsetHeight ?? 330;
    const pad = 10;
    let x = target.x;
    let y = target.y;
    if (x + MENU_W + pad > window.innerWidth) x = window.innerWidth - MENU_W - pad;
    if (x < pad) x = pad;
    if (y + h + pad > window.innerHeight) y = Math.max(pad, window.innerHeight - h - pad);
    setPos({ x, y });
  }, [target, askPin]);

  useEffect(() => {
    if (!target) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    const onScroll = () => onClose();
    window.addEventListener("keydown", onKey);
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", onScroll);
    };
  }, [target, onClose]);

  const fire = (a: MenuAction) => {
    if (!target) return;
    sfx.click();
    onAction(a, target.id);
    onClose();
  };

  return (
    <AnimatePresence>
      {target && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110]"
            onMouseDown={onClose}
            onContextMenu={(e) => {
              e.preventDefault();
              onClose();
            }}
          />
          <motion.div
            ref={ref}
            initial={{ opacity: 0, scale: 0.92, y: -6 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -4 }}
            transition={{ type: "spring", stiffness: 480, damping: 32 }}
            style={{ left: pos.x, top: pos.y, width: MENU_W }}
            className="fixed z-[111] origin-top overflow-hidden rounded-2xl border border-orange-100 bg-white/95 p-1.5 shadow-2xl backdrop-blur-xl"
          >
            {/* реакции */}
            <div className="mb-1 flex items-center justify-between gap-0.5 rounded-xl bg-orange-50/80 px-1.5 py-1.5">
              {REACTIONS.map((r) => (
                <motion.button
                  key={r}
                  whileHover={{ scale: 1.28, y: -2 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    sfx.tick();
                    onReact(target.id, r);
                    onClose();
                  }}
                  className={cx(
                    "flex h-7 w-7 items-center justify-center rounded-full text-[17px] leading-none transition-colors",
                    target.myReaction === r && "bg-orange-200/90"
                  )}
                >
                  {r}
                </motion.button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              {!askPin ? (
                <motion.div key="main" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                  <Item icon={<Reply size={15} />} label="Ответить" onClick={() => fire("reply")} />
                  <Item icon={<Copy size={15} />} label="Скопировать" onClick={() => fire("copy")} />
                  <Item
                    icon={<Pin size={15} />}
                    label="Закрепить"
                    onClick={() => {
                      sfx.tick();
                      setAskPin(true);
                    }}
                    arrow
                  />
                  {target.mine && target.canEdit && (
                    <Item icon={<Pencil size={15} />} label="Редактировать" onClick={() => fire("edit")} />
                  )}
                  {target.mine && (
                    <Item icon={<Trash2 size={15} />} label="Удалить" danger onClick={() => fire("delete")} />
                  )}
                </motion.div>
              ) : (
                <motion.div key="pin" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}>
                  <div className="px-3 pb-1.5 pt-1 text-[10.5px] font-bold uppercase tracking-wider text-cocoa-soft/70">
                    Закрепить для кого?
                  </div>
                  <Item icon={<UserRound size={15} />} label="Только у меня" onClick={() => fire("pin-me")} />
                  <Item icon={<Users size={15} />} label="У обоих" onClick={() => fire("pin-both")} />
                  <button
                    onClick={() => setAskPin(false)}
                    className="mt-0.5 w-full rounded-xl px-3 py-2 text-left text-[12px] font-semibold text-cocoa-soft transition-colors hover:bg-orange-50"
                  >
                    ← Назад
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function Item({
  icon,
  label,
  onClick,
  danger,
  arrow,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  danger?: boolean;
  arrow?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cx(
        "flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-[13px] font-semibold transition-colors",
        danger ? "text-red-500 hover:bg-red-50" : "text-cocoa hover:bg-orange-50"
      )}
    >
      <span className={danger ? "text-red-400" : "text-orange-500"}>{icon}</span>
      <span className="flex-1">{label}</span>
      {arrow && <span className="text-cocoa-soft/50">›</span>}
    </button>
  );
}
