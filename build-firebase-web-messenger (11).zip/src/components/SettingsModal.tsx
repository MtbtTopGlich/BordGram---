import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AtSign,
  BellRing,
  Camera,
  Check,
  ChevronDown,
  Clapperboard,
  Copy,
  Crown,
  ImagePlus,
  Info,
  Keyboard,
  KeyRound,
  Lock,
  LogOut,
  MessageSquare,
  Mic,
  Moon,
  MousePointerClick,
  Palette,
  Play,
  RotateCcw,
  Send,
  ShieldCheck,
  Sparkles,
  Trash2,
  Type,
  UserRound,
  Video,
  VideoOff,
  Volume2,
  Wand2,
} from "lucide-react";
import { Avatar, ModalShell, Spinner } from "./bits";
import AdminPanel from "./AdminPanel";
import { useAuth, useToast } from "../state";
import { changeUserPassword, isAdmin, isOwner, propagateProfile, updateProfileFields } from "../db";
import { ACCENTS, THEMES, usePrefs, WALLPAPERS, type ThemeId, type WallpaperId } from "../lib/theme";
import { cx, fileToAvatar } from "../lib/utils";
import { getSavedDeviceId, listInputDevices, mediaDevicesSupported, saveDeviceId } from "../lib/devices";
import { sfx } from "../lib/sounds";

export type SettingsTab = "profile" | "personalization" | "chat" | "security" | "devices" | "sound" | "admin" | "about";

const ALL_TABS: Array<{ id: SettingsTab; label: string; icon: typeof UserRound; desc: string }> = [
  { id: "profile", label: "Профиль", icon: UserRound, desc: "Имя, аватарка и био" },
  { id: "personalization", label: "Персонализация", icon: Palette, desc: "Цвет, обои и внешний вид" },
  { id: "chat", label: "Чат", icon: MessageSquare, desc: "Поведение переписки" },
  { id: "security", label: "Безопасность", icon: ShieldCheck, desc: "Пароль и сессия" },
  { id: "devices", label: "Устройства", icon: Mic, desc: "Микрофон и веб-камера" },
  { id: "sound", label: "Звук", icon: Volume2, desc: "ASMR-эффекты интерфейса" },
  { id: "admin", label: "Админка", icon: Crown, desc: "Управление пользователями" },
  { id: "about", label: "О сервисе", icon: Info, desc: "Версия и горячие клавиши" },
];

export default function SettingsModal({
  open,
  onClose,
  onLogout,
  initialTab = "profile",
}: {
  open: boolean;
  onClose: () => void;
  onLogout: () => void;
  initialTab?: SettingsTab;
}) {
  const { user } = useAuth();
  const [tab, setTab] = useState<SettingsTab>(initialTab);
  const tabs = ALL_TABS.filter((t) => (t.id === "admin" ? isAdmin(user) : true));

  useEffect(() => {
    if (open) setTab(initialTab);
  }, [open, initialTab]);

  return (
    <ModalShell open={open} onClose={onClose} maxW="max-w-3xl">
      <div className="mb-4 flex items-center gap-3 pr-8">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-amber-400 text-white shadow-orangeSoft">
          <Clapperboard size={19} />
        </span>
        <div>
          <h3 className="font-display text-lg font-bold leading-tight">Настройки</h3>
          <p className="text-xs font-medium text-cocoa-soft">{tabs.find((t) => t.id === tab)?.desc}</p>
        </div>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:gap-5">
        {/* категории */}
        <nav className="warm-scroll flex shrink-0 gap-1.5 overflow-x-auto pb-1 sm:max-h-[58vh] sm:w-44 sm:flex-col sm:overflow-x-visible sm:overflow-y-auto">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => {
                setTab(id);
                sfx.tick();
              }}
              className={cx(
                "btn-press relative flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-left text-[13px] font-bold transition-colors",
                tab === id ? "text-white" : "text-cocoa-soft hover:bg-orange-50 hover:text-orange-600"
              )}
            >
              {tab === id && (
                <motion.span
                  layoutId="settings-tab"
                  className="absolute inset-0 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 shadow-orangeSoft"
                  transition={{ type: "spring", stiffness: 420, damping: 32 }}
                />
              )}
              <Icon size={15} className="relative z-10" />
              <span className="relative z-10 whitespace-nowrap">{label}</span>
            </button>
          ))}
        </nav>

        {/* контент категории */}
        <div className="warm-scroll min-h-[300px] min-w-0 flex-1 overflow-y-auto pr-1 sm:max-h-[58vh] max-sm:max-h-[52vh]">
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.18 }}
            >
              {tab === "profile" && <ProfileTab />}
              {tab === "personalization" && <PersonalizationTab />}
              {tab === "chat" && <ChatTab />}
              {tab === "security" && <SecurityTab onLogout={onLogout} onClose={onClose} />}
              {tab === "devices" && <DevicesTab />}
              {tab === "sound" && <SoundTab />}
              {tab === "admin" && <AdminPanel />}
              {tab === "about" && <AboutTab />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </ModalShell>
  );
}

/* ================================================= PROFILE ================================================= */

function ProfileTab() {
  const { user, refresh } = useAuth();
  const { toast } = useToast();
  const [nickname, setNickname] = useState(user?.nickname ?? "");
  const [bio, setBio] = useState(user?.bio ?? "");
  const [avatar, setAvatar] = useState(user?.avatar ?? "");
  const [busy, setBusy] = useState(false);
  const [camOpen, setCamOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user) {
      setNickname(user.nickname);
      setBio(user.bio);
      setAvatar(user.avatar);
    }
  }, [user]);

  if (!user) return null;

  const save = async () => {
    if (nickname.trim().length < 2) {
      toast("Никнейм — минимум 2 символа", "err");
      return;
    }
    setBusy(true);
    try {
      const fields = { nickname: nickname.trim(), bio: bio.trim(), avatar };
      await updateProfileFields(user.uid, fields);
      await propagateProfile(user.uid, { nickname: fields.nickname, avatar: fields.avatar });
      await refresh();
      sfx.success();
      toast("Профиль обновлён", "ok");
    } catch {
      toast("Не удалось сохранить", "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="relative">
          <Avatar src={avatar} name={nickname || "?"} seed={user.username} size={72} />
          {avatar && (
            <button
              onClick={() => {
                setAvatar("");
                sfx.tick();
              }}
              className="btn-press absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-white shadow-warm"
              title="Убрать фото"
            >
              <Trash2 size={11} />
            </button>
          )}
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-2">
          <button
            onClick={() => fileRef.current?.click()}
            className="btn-press flex w-fit items-center gap-2 rounded-full border-2 border-dashed border-orange-300 bg-white/70 px-4 py-2 text-[13px] font-semibold text-orange-600 transition-colors hover:border-orange-500 hover:bg-orange-50"
          >
            <ImagePlus size={15} /> Загрузить фото
          </button>
          <button
            onClick={() => {
              sfx.click();
              setCamOpen((v) => !v);
            }}
            className={cx(
              "btn-press flex w-fit items-center gap-2 rounded-full border-2 px-4 py-2 text-[13px] font-semibold transition-colors",
              camOpen
                ? "border-orange-500 bg-orange-50 text-orange-600"
                : "border-dashed border-orange-300 bg-white/70 text-orange-600 hover:border-orange-500 hover:bg-orange-50"
            )}
          >
            <Camera size={15} /> {camOpen ? "Скрыть камеру" : "Фото с веб-камеры"}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                setAvatar(await fileToAvatar(f));
                sfx.success();
              } catch {
                toast("Не удалось прочитать картинку", "err");
              }
              e.target.value = "";
            }}
          />
        </div>
      </div>

      <AnimatePresence>
        {camOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <AvatarFromCamera
              onCapture={(d) => {
                setAvatar(d);
                setCamOpen(false);
                sfx.success();
                toast("Получилось отлично!", "ok");
              }}
              onCancel={() => setCamOpen(false)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-wrap gap-2">
        <span className="flex items-center gap-1.5 rounded-full bg-orange-100/80 px-3.5 py-2 text-xs font-bold text-orange-700">
          <AtSign size={12} /> {user.usernameDisplay}
          <button
            onClick={() => {
              void navigator.clipboard?.writeText(`@${user.usernameDisplay}`);
              sfx.tick();
              toast("Username скопирован", "ok");
            }}
            className="btn-press ml-0.5 text-orange-500 transition-colors hover:text-orange-700"
            title="Скопировать @username"
          >
            <Copy size={12} />
          </button>
        </span>
        <span className="rounded-full bg-white/80 px-3.5 py-2 text-xs font-semibold text-cocoa-soft shadow-warm">{user.email}</span>
      </div>

      <label className="block">
        <span className="mb-1.5 block text-[13px] font-semibold text-cocoa-soft">NickName</span>
        <input className="field" value={nickname} maxLength={40} onChange={(e) => setNickname(e.target.value)} />
      </label>
      <label className="block">
        <span className="mb-1.5 flex justify-between text-[13px] font-semibold text-cocoa-soft">
          Био <span className="text-cocoa-soft/60">{bio.length}/140</span>
        </span>
        <textarea className="field min-h-[84px] resize-none" value={bio} maxLength={140} onChange={(e) => setBio(e.target.value)} />
      </label>

      <button
        onClick={() => void save()}
        disabled={busy}
        className="btn-press flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-5 py-3.5 text-sm font-bold text-white shadow-orangeGlow transition hover:brightness-105 disabled:opacity-60"
      >
        {busy ? <Spinner size={16} className="border-white/40 border-t-white" /> : <Check size={16} />} Сохранить профиль
      </button>
    </div>
  );
}

/* ---- фото с веб-камеры ---- */

function AvatarFromCamera({ onCapture, onCancel }: { onCapture: (dataUrl: string) => void; onCancel: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [err, setErr] = useState(false);

  useEffect(() => {
    let stream: MediaStream | null = null;
    let cancelled = false;
    const camId = getSavedDeviceId("cam");
    (async () => {
      try {
        stream = await navigator.mediaDevices
          .getUserMedia({ video: camId ? { deviceId: { exact: camId } } : true })
          .catch(() => navigator.mediaDevices.getUserMedia({ video: true }));
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch {
        if (!cancelled) setErr(true);
      }
    })();
    return () => {
      cancelled = true;
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const snap = () => {
    const v = videoRef.current;
    if (!v || !v.videoWidth) return;
    const min = Math.min(v.videoWidth, v.videoHeight);
    const sx = (v.videoWidth - min) / 2;
    const sy = (v.videoHeight - min) / 2;
    const canvas = document.createElement("canvas");
    canvas.width = 320;
    canvas.height = 320;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(v, sx, sy, min, min, 0, 0, 320, 320);
    onCapture(canvas.toDataURL("image/jpeg", 0.85));
  };

  if (err) {
    return (
      <div className="flex items-center gap-3 rounded-2xl border border-red-200 bg-red-50/80 p-4 text-[13px] font-semibold text-red-600">
        <VideoOff size={17} /> Нет доступа к камере — проверь разрешения браузера
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-orange-200 bg-white/70 p-3">
      <div className="relative mx-auto aspect-square max-h-56 overflow-hidden rounded-xl bg-cocoa">
        <video ref={videoRef} autoPlay muted playsInline className="h-full w-full -scale-x-100 object-cover" />
      </div>
      <div className="mt-3 flex items-center justify-center gap-2">
        <button
          onClick={() => {
            sfx.close();
            onCancel();
          }}
          className="btn-press rounded-full bg-orange-100/80 px-5 py-2.5 text-xs font-bold text-cocoa-soft transition-colors hover:text-orange-600"
        >
          Отмена
        </button>
        <button
          onClick={() => {
            sfx.click();
            snap();
          }}
          className="btn-press flex items-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-5 py-2.5 text-xs font-bold text-white shadow-orangeSoft"
        >
          <Camera size={13} /> Сделать снимок
        </button>
      </div>
    </div>
  );
}

/* ============================================ PERSONALIZATION ============================================ */

function PersonalizationTab() {
  const { prefs, setPref, reset } = usePrefs();
  const { toast } = useToast();

  return (
    <div className="space-y-4">
      {/* тема фона */}
      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-1 flex items-center gap-2">
          <Moon size={15} className="text-orange-500" />
          <span className="text-sm font-bold">Тема оформления</span>
        </div>
        <p className="mb-3 text-[11.5px] leading-relaxed text-cocoa-soft">
          Меняет фон всего мессенджера. Тёмные темы приглушённые — не слепят глаза в темноте.
        </p>
        <div className="grid grid-cols-5 gap-2">
          {THEMES.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                setPref("theme", t.id as ThemeId);
                sfx.tick();
              }}
              title={t.hint}
              className={cx(
                "btn-press flex flex-col items-center gap-1.5 rounded-xl border-2 p-1.5 transition-colors",
                prefs.theme === t.id ? "border-orange-500" : "border-transparent hover:border-orange-200"
              )}
            >
              <span
                className="relative flex h-10 w-full items-center justify-center rounded-lg border"
                style={{ background: t.swatch, borderColor: "rgba(140,110,80,0.25)" }}
              >
                {prefs.theme === t.id && (
                  <Check size={14} style={{ color: t.dark ? "#fff" : "#3a2113" }} />
                )}
                <span
                  className="absolute bottom-1 right-1 h-2 w-2 rounded-full"
                  style={{ background: prefs.accent }}
                />
              </span>
              <span className="text-[9.5px] font-bold leading-tight text-cocoa-soft">{t.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* акцентный цвет */}
      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-3 flex items-center gap-2">
          <Palette size={15} className="text-orange-500" />
          <span className="text-sm font-bold">Основной цвет</span>
        </div>
        <div className="grid grid-cols-4 gap-2 sm:grid-cols-8">
          {ACCENTS.map((a) => (
            <button
              key={a.id}
              title={a.name}
              onClick={() => {
                setPref("accent", a.hex);
                sfx.tick();
              }}
              className="btn-press group flex flex-col items-center gap-1.5"
            >
              <span
                className={cx(
                  "flex h-9 w-9 items-center justify-center rounded-full transition-all duration-200",
                  prefs.accent.toLowerCase() === a.hex.toLowerCase()
                    ? "ring-2 ring-offset-2 ring-offset-cream"
                    : "hover:scale-110"
                )}
                style={{ background: a.hex, boxShadow: `0 4px 12px ${a.hex}55`, ...( { "--tw-ring-color": a.hex } as React.CSSProperties) }}
              >
                {prefs.accent.toLowerCase() === a.hex.toLowerCase() && <Check size={15} className="text-white" />}
              </span>
              <span className="text-[9.5px] font-bold text-cocoa-soft">{a.name}</span>
            </button>
          ))}
        </div>
        <label className="mt-4 flex items-center gap-3 rounded-xl bg-orange-50/70 p-3">
          <input
            type="color"
            value={prefs.accent}
            onChange={(e) => setPref("accent", e.target.value)}
            className="h-9 w-12 cursor-pointer rounded-lg border-0 bg-transparent p-0"
          />
          <div className="flex-1">
            <div className="text-[12.5px] font-bold text-cocoa">Свой цвет</div>
            <div className="text-[11px] font-semibold uppercase text-cocoa-soft">{prefs.accent}</div>
          </div>
          <Wand2 size={15} className="text-orange-400" />
        </label>
      </div>

      {/* обои чата */}
      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-3 flex items-center gap-2">
          <ImagePlus size={15} className="text-orange-500" />
          <span className="text-sm font-bold">Фон чата</span>
        </div>
        <div className="grid grid-cols-5 gap-2">
          {WALLPAPERS.map((w) => (
            <button
              key={w.id}
              onClick={() => {
                setPref("wallpaper", w.id as WallpaperId);
                sfx.tick();
              }}
              className={cx(
                "btn-press flex flex-col items-center gap-1.5 rounded-xl border-2 p-2 transition-colors",
                prefs.wallpaper === w.id ? "border-orange-500 bg-orange-50" : "border-orange-100 hover:border-orange-300"
              )}
            >
              <WallPreview id={w.id} accent={prefs.accent} />
              <span className="text-[9.5px] font-bold text-cocoa-soft">{w.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* форма пузырей */}
      <SliderRow
        icon={<MessageSquare size={15} className="text-orange-500" />}
        label="Скругление сообщений"
        value={prefs.radius}
        min={6}
        max={30}
        step={2}
        display={`${prefs.radius}px`}
        onChange={(v) => setPref("radius", v)}
      />

      {/* размер шрифта */}
      <SliderRow
        icon={<Type size={15} className="text-orange-500" />}
        label="Размер текста"
        value={prefs.fontScale}
        min={0.85}
        max={1.25}
        step={0.05}
        display={`${Math.round(prefs.fontScale * 100)}%`}
        onChange={(v) => setPref("fontScale", v)}
      />

      {/* плотность + анимации */}
      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-3 text-[12.5px] font-bold text-cocoa">Внешний вид</div>
        <div className="mb-3 grid grid-cols-2 gap-2">
          {(["cozy", "compact"] as const).map((d) => (
            <button
              key={d}
              onClick={() => {
                setPref("density", d);
                sfx.tick();
              }}
              className={cx(
                "btn-press rounded-xl border-2 px-3 py-2.5 text-[12.5px] font-bold transition-colors",
                prefs.density === d
                  ? "border-orange-500 bg-orange-50 text-orange-600"
                  : "border-orange-100 text-cocoa-soft hover:border-orange-300"
              )}
            >
              {d === "cozy" ? "Уютно" : "Компактно"}
            </button>
          ))}
        </div>
        <ToggleRow
          label="Плавные анимации"
          hint="Выключи, если нужен максимально быстрый интерфейс"
          value={prefs.motion}
          onChange={(v) => setPref("motion", v)}
        />
      </div>

      <button
        onClick={() => {
          reset();
          sfx.success();
          toast("Вернули стандартный вид", "ok");
        }}
        className="btn-press flex w-full items-center justify-center gap-2 rounded-full bg-orange-100/80 py-3 text-[13px] font-bold text-cocoa-soft transition-colors hover:text-orange-600"
      >
        <RotateCcw size={14} /> Сбросить оформление
      </button>
    </div>
  );
}

function WallPreview({ id, accent }: { id: string; accent: string }) {
  const styles: Record<string, React.CSSProperties> = {
    none: { background: "#fff" },
    dots: {
      backgroundColor: "#fff",
      backgroundImage: `radial-gradient(${accent}66 1.4px, transparent 1.5px)`,
      backgroundSize: "7px 7px",
    },
    grid: {
      backgroundColor: "#fff",
      backgroundImage: `linear-gradient(${accent}44 1px, transparent 1px), linear-gradient(90deg, ${accent}44 1px, transparent 1px)`,
      backgroundSize: "8px 8px",
    },
    waves: {
      backgroundColor: "#fff",
      backgroundImage: `repeating-radial-gradient(circle at 50% 120%, ${accent}40 0 1.5px, transparent 1.5px 8px)`,
    },
    sunset: { background: `linear-gradient(180deg, ${accent}44, #fff 60%, ${accent}33)` },
  };
  return <span className="h-8 w-full rounded-lg border border-orange-100" style={styles[id]} />;
}

function SliderRow({
  icon,
  label,
  value,
  min,
  max,
  step,
  display,
  onChange,
}: {
  icon: ReactNode;
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  display: string;
  onChange: (v: number) => void;
}) {
  return (
    <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
      <div className="mb-2.5 flex items-center gap-2">
        {icon}
        <span className="flex-1 text-[12.5px] font-bold text-cocoa">{label}</span>
        <span className="rounded-full bg-orange-100 px-2.5 py-0.5 text-[11px] font-bold text-orange-700">{display}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        onMouseUp={() => sfx.tick()}
        className="h-2 w-full cursor-pointer appearance-none rounded-full bg-orange-100 accent-orange-500"
        style={{ accentColor: "var(--accent, #FF6A00)" }}
      />
    </div>
  );
}

function ToggleRow({
  label,
  hint,
  value,
  onChange,
}: {
  label: string;
  hint?: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0">
        <div className="text-[12.5px] font-bold text-cocoa">{label}</div>
        {hint && <p className="mt-0.5 text-[11px] leading-snug text-cocoa-soft">{hint}</p>}
      </div>
      <button
        onClick={() => {
          onChange(!value);
          sfx.tick();
        }}
        className={cx(
          "relative h-7 w-12 shrink-0 rounded-full transition-colors duration-300",
          value ? "bg-gradient-to-r from-orange-600 to-amber-500" : "bg-orange-200/70"
        )}
      >
        <motion.span
          layout
          transition={{ type: "spring", stiffness: 500, damping: 32 }}
          className={cx("absolute top-1 h-5 w-5 rounded-full bg-white shadow", value ? "left-6" : "left-1")}
        />
      </button>
    </div>
  );
}

/* ================================================= CHAT ================================================= */

function ChatTab() {
  const { prefs, setPref } = usePrefs();
  return (
    <div className="space-y-4">
      <div className="space-y-3.5 rounded-2xl border border-orange-100 bg-white/70 p-4">
        <ToggleRow
          label="Enter отправляет сообщение"
          hint="Если выключить — Enter перенесёт строку, а отправка по кнопке"
          value={prefs.enterToSend}
          onChange={(v) => setPref("enterToSend", v)}
        />
      </div>
      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-2 flex items-center gap-2">
          <Keyboard size={15} className="text-orange-500" />
          <span className="text-sm font-bold">Горячие клавиши</span>
        </div>
        <ul className="space-y-1.5 text-[12.5px] text-cocoa-soft">
          <li className="flex justify-between gap-3">
            <span>Отправить</span> <Kbd>{prefs.enterToSend ? "Enter" : "Клик по кнопке"}</Kbd>
          </li>
          <li className="flex justify-between gap-3">
            <span>Новая строка</span> <Kbd>Shift + Enter</Kbd>
          </li>
          <li className="flex justify-between gap-3">
            <span>Закрыть окно</span> <Kbd>Esc</Kbd>
          </li>
        </ul>
      </div>
      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4 text-[12.5px] leading-relaxed text-cocoa-soft">
        <span className="font-bold text-cocoa">Совет: </span>
        наводи на контакт и жми звёздочку — он закрепится в «Избранных» наверху списка.
      </div>
    </div>
  );
}

function Kbd({ children }: { children: ReactNode }) {
  return (
    <span className="rounded-md border border-orange-200 bg-orange-50 px-2 py-0.5 text-[11px] font-bold text-orange-700">
      {children}
    </span>
  );
}

/* ================================================= ABOUT ================================================= */

function AboutTab() {
  const { user } = useAuth();
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-orange-100 bg-gradient-to-br from-orange-50 to-amber-50 p-5 text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeGlow">
          <Sparkles size={22} />
        </div>
        <div className="font-display text-xl font-bold">
          Bord<span className="text-orange-600">Gram</span>
        </div>
        <p className="mt-1 text-xs font-semibold uppercase tracking-[0.2em] text-cocoa-soft">версия 1.2 · warm</p>
        <p className="mx-auto mt-3 max-w-xs text-[12.5px] leading-relaxed text-cocoa-soft">
          Тёплый мессенджер с голосовыми, фото, заявками в контакты и живыми обновлениями
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {[
          { k: "Твой статус", v: isOwner(user) ? "Владелец" : isAdmin(user) ? "Администратор" : "Пользователь" },
          { k: "Username", v: `@${user?.usernameDisplay ?? ""}` },
          { k: "Голосовые", v: "до 60 сек" },
          { k: "Фото", v: "сжатие авто" },
        ].map((x) => (
          <div key={x.k} className="rounded-xl border border-orange-100 bg-white/70 p-3">
            <div className="text-[10.5px] font-bold uppercase tracking-wider text-cocoa-soft/70">{x.k}</div>
            <div className="mt-0.5 truncate text-[13px] font-bold text-cocoa">{x.v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================= SECURITY ================================================= */

function SecurityTab({ onLogout, onClose }: { onLogout: () => void; onClose: () => void }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [oldPw, setOldPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [busy, setBusy] = useState(false);

  if (!user) return null;

  const strength = ((): number => {
    let s = 0;
    if (newPw.length >= 6) s++;
    if (newPw.length >= 10) s++;
    if (/\d/.test(newPw)) s++;
    if (/[A-ZА-Я]/.test(newPw)) s++;
    return s;
  })();

  const submit = async () => {
    if (!oldPw.trim()) return toast("Введи текущий пароль", "err");
    if (newPw.trim().length < 6) return toast("Новый пароль — минимум 6 символов", "err");
    if (newPw.trim() !== confirmPw.trim()) return toast("Новые пароли не совпадают", "err");
    setBusy(true);
    try {
      const res = await changeUserPassword(user.uid, oldPw, newPw);
      if (res === "mismatch") {
        toast("Текущий пароль не подходит", "err");
        return;
      }
      if (res === "nouser") {
        toast("Аккаунт не найден", "err");
        return;
      }
      setOldPw("");
      setNewPw("");
      setConfirmPw("");
      sfx.success();
      toast("Пароль обновлён", "ok");
    } catch {
      toast("Не удалось сменить пароль", "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-3 flex items-center gap-2">
          <KeyRound size={15} className="text-orange-500" />
          <span className="text-sm font-bold">Смена пароля</span>
        </div>
        <div className="space-y-3">
          <PwField placeholder="Текущий пароль" value={oldPw} onChange={setOldPw} />
          <PwField placeholder="Новый пароль" value={newPw} onChange={setNewPw} />
          <div className="flex items-center gap-1.5 px-1">
            {Array.from({ length: 4 }).map((_, i) => (
              <motion.span
                key={i}
                initial={false}
                animate={{ scaleY: i < strength ? 1 : 0.55, opacity: i < strength ? 1 : 0.35 }}
                className={cx(
                  "h-1.5 flex-1 origin-left rounded-full",
                  i < strength ? (strength <= 2 ? "bg-amber-400" : "bg-emerald-500") : "bg-orange-200"
                )}
              />
            ))}
          </div>
          <PwField
            placeholder="Повтори новый пароль"
            value={confirmPw}
            onChange={setConfirmPw}
            error={!!confirmPw && confirmPw.trim() !== newPw.trim()}
            onEnter={() => void submit()}
          />
          <button
            onClick={() => void submit()}
            disabled={busy}
            className="btn-press flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-5 py-3 text-sm font-bold text-white shadow-orangeGlow transition hover:brightness-105 disabled:opacity-60"
          >
            {busy ? <Spinner size={15} className="border-white/40 border-t-white" /> : <Lock size={14} />} Обновить пароль
          </button>
        </div>
      </div>

      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-1.5 text-sm font-bold">Сессия</div>
        <p className="mb-3 text-xs leading-relaxed text-cocoa-soft">
          Ты вошёл как <span className="font-semibold text-cocoa">@{user.usernameDisplay}</span> · {user.email}
        </p>
        <button
          onClick={() => {
            onClose();
            onLogout();
          }}
          className="btn-press flex items-center gap-2 rounded-full bg-red-50 px-5 py-2.5 text-xs font-bold text-red-500 transition hover:bg-red-100"
        >
          <LogOut size={14} /> Выйти из аккаунта
        </button>
      </div>
    </div>
  );
}

function PwField({
  placeholder,
  value,
  onChange,
  onEnter,
  error,
}: {
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  onEnter?: () => void;
  error?: boolean;
}) {
  return (
    <div className="relative">
      <Lock size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
      <input
        type="password"
        className={cx("field !py-3 pl-11 text-sm", error && "field-error")}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && onEnter?.()}
      />
    </div>
  );
}

/* ================================================= DEVICES ================================================= */

function DevicesTab() {
  const { toast } = useToast();
  const supported = mediaDevicesSupported();
  const [perm, setPerm] = useState<"idle" | "pending" | "ok" | "err">("idle");
  const [mics, setMics] = useState<MediaDeviceInfo[]>([]);
  const [cams, setCams] = useState<MediaDeviceInfo[]>([]);
  const [micId, setMicId] = useState(getSavedDeviceId("mic"));
  const [camId, setCamId] = useState(getSavedDeviceId("cam"));

  const refreshLists = useCallback(async () => {
    const { mics, cams } = await listInputDevices();
    setMics(mics);
    setCams(cams);
  }, []);

  useEffect(() => {
    if (supported) void refreshLists();
  }, [supported, refreshLists]);

  const requestAccess = async () => {
    setPerm("pending");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      stream.getTracks().forEach((t) => t.stop());
      await refreshLists();
      setPerm("ok");
      sfx.success();
    } catch {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());
        await refreshLists();
        setPerm("ok");
        toast("Камера недоступна, но микрофон работает", "info");
      } catch {
        setPerm("err");
      }
    }
  };

  const pickMic = (v: string) => {
    setMicId(v);
    saveDeviceId("mic", v);
    sfx.tick();
  };
  const pickCam = (v: string) => {
    setCamId(v);
    saveDeviceId("cam", v);
    sfx.tick();
    toast("Камера сохранена — будет использоваться для снимков на аватарку", "ok");
  };

  if (!supported) {
    return (
      <div className="rounded-2xl border border-red-200 bg-red-50/70 p-4 text-sm font-semibold text-red-600">
        Браузер не поддерживает доступ к устройствам (нужен HTTPS и современный браузер)
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {perm !== "ok" && (
        <div className="rounded-2xl border border-orange-200 bg-white/70 p-4">
          <p className="mb-3 text-[13px] font-medium leading-relaxed text-cocoa-soft">
            Разреши доступ, чтобы увидеть названия микрофонов и камер и сразу их проверить
          </p>
          <button
            onClick={() => void requestAccess()}
            disabled={perm === "pending"}
            className="btn-press flex items-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-5 py-2.5 text-xs font-bold text-white shadow-orangeSoft disabled:opacity-60"
          >
            {perm === "pending" ? <Spinner size={13} className="border-white/40 border-t-white" /> : <Video size={14} />}
            {perm === "pending" ? "Запрашиваю доступ…" : "Разрешить доступ к устройствам"}
          </button>
          {perm === "err" && (
            <p className="mt-2.5 text-xs font-semibold text-red-500">
              Доступ запрещён. Открой настройки сайта в браузере и разреши микрофон/камеру
            </p>
          )}
        </div>
      )}

      <DeviceSelect
        label="Микрофон"
        icon={<Mic size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />}
        value={micId}
        onChange={pickMic}
        items={mics}
        fallback="Микрофон"
      />

      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[12.5px] font-bold text-cocoa">Проверка микрофона</span>
          <span className="text-[11px] font-semibold text-cocoa-soft/70">скажи что-нибудь</span>
        </div>
        <MicLevelMeter deviceId={micId} />
      </div>

      <DeviceSelect
        label="Веб-камера"
        icon={<Video size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />}
        value={camId}
        onChange={pickCam}
        items={cams}
        fallback="Камера"
      />

      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[12.5px] font-bold text-cocoa">Предпросмотр камеры</span>
        </div>
        <CamPreview deviceId={camId} />
        <p className="mt-2.5 text-[11.5px] leading-relaxed text-cocoa-soft">
          Эта камера будет использоваться, когда делаешь фото на аватарку в профиле
        </p>
      </div>
    </div>
  );
}

function DeviceSelect({
  label,
  icon,
  value,
  onChange,
  items,
  fallback,
}: {
  label: string;
  icon: ReactNode;
  value: string;
  onChange: (v: string) => void;
  items: MediaDeviceInfo[];
  fallback: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[13px] font-semibold text-cocoa-soft">{label}</span>
      <div className="relative">
        {icon}
        <select
          className="field appearance-none pl-11 pr-11 text-sm"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        >
          <option value="">По умолчанию (системный)</option>
          {items.map((d, i) => (
            <option key={d.deviceId || i} value={d.deviceId}>
              {d.label || `${fallback} ${i + 1}`}
            </option>
          ))}
        </select>
        <ChevronDown size={16} className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
      </div>
    </label>
  );
}

function MicLevelMeter({ deviceId }: { deviceId: string }) {
  const [level, setLevel] = useState(0);
  const [err, setErr] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let raf = 0;
    let stream: MediaStream | null = null;
    let ctx: AudioContext | null = null;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: deviceId ? { deviceId: { exact: deviceId } } : true,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        const AC: typeof AudioContext | undefined =
          window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AC) return;
        ctx = new AC();
        const src = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;
        src.connect(analyser);
        const buf = new Uint8Array(analyser.fftSize);
        const loop = () => {
          analyser.getByteTimeDomainData(buf);
          let max = 0;
          for (const v of buf) max = Math.max(max, Math.abs(v - 128) / 128);
          setLevel((prev) => prev * 0.72 + max * 0.5);
          raf = requestAnimationFrame(loop);
        };
        loop();
      } catch {
        if (!cancelled) setErr(true);
      }
    })();
    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      stream?.getTracks().forEach((t) => t.stop());
      void ctx?.close().catch(() => undefined);
    };
  }, [deviceId]);

  if (err) {
    return <div className="text-xs font-semibold text-red-500">Нет доступа к микрофону</div>;
  }

  const pct = Math.min(100, Math.round(level * 160));
  return (
    <div className="flex items-center gap-3">
      <div className="h-4 flex-1 overflow-hidden rounded-full bg-orange-100">
        <div
          className={cx("h-full rounded-full bg-gradient-to-r transition-[width] duration-75", pct > 70 ? "from-red-400 to-orange-400" : "from-amber-400 to-orange-500")}
          style={{ width: `${Math.max(3, pct)}%` }}
        />
      </div>
      <span className="w-9 text-right text-[11px] font-bold tabular-nums text-cocoa-soft">{pct}%</span>
    </div>
  );
}

function CamPreview({ deviceId }: { deviceId: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [err, setErr] = useState(false);

  useEffect(() => {
    let stream: MediaStream | null = null;
    let cancelled = false;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: deviceId ? { deviceId: { exact: deviceId } } : true,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        if (ref.current) ref.current.srcObject = stream;
        setErr(false);
      } catch {
        if (!cancelled) setErr(true);
      }
    })();
    return () => {
      cancelled = true;
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [deviceId]);

  if (err) {
    return (
      <div className="flex aspect-video w-full max-w-xs items-center justify-center gap-2 rounded-xl bg-orange-50 text-xs font-semibold text-cocoa-soft">
        <VideoOff size={15} /> Камера недоступна
      </div>
    );
  }
  return (
    <video
      ref={ref}
      autoPlay
      muted
      playsInline
      className="aspect-video w-full max-w-xs -scale-x-100 rounded-xl border-2 border-orange-100 object-cover shadow-warm"
    />
  );
}

/* ================================================= SOUND ================================================= */

function SoundTab() {
  const [on, setOn] = useState(sfx.enabled);
  const { prefs, setPref } = usePrefs();
  const preview: Array<{ label: string; run: () => void; icon: typeof Volume2 }> = [
    { label: "Клик", run: () => sfx.click(), icon: MousePointerClick },
    { label: "Отправка", run: () => sfx.send(), icon: Send },
    { label: "Входящее", run: () => sfx.receive(), icon: BellRing },
    { label: "Заявка", run: () => sfx.notify(), icon: Sparkles },
    { label: "Успех", run: () => sfx.success(), icon: Check },
    { label: "Открытие", run: () => sfx.open(), icon: Play },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div>
          <div className="text-sm font-bold">Звуки интерфейса</div>
          <p className="mt-0.5 text-xs text-cocoa-soft">Тёплые ASMR-нажатия, отправка и входящие сообщения</p>
        </div>
        <button
          onClick={() => {
            const v = !on;
            sfx.setEnabled(v);
            setOn(v);
            sfx.tick();
          }}
          className={cx(
            "relative h-8 w-14 shrink-0 rounded-full transition-colors duration-300",
            on ? "bg-gradient-to-r from-orange-600 to-amber-500" : "bg-orange-200/70"
          )}
          aria-label="Переключить звуки"
        >
          <motion.span
            layout
            transition={{ type: "spring", stiffness: 500, damping: 32 }}
            className={cx("absolute top-1 h-6 w-6 rounded-full bg-white shadow", on ? "left-7" : "left-1")}
          />
        </button>
      </div>

      <SliderRow
        icon={<Volume2 size={15} className="text-orange-500" />}
        label="Громкость эффектов"
        value={prefs.volume}
        min={0.2}
        max={1.6}
        step={0.1}
        display={`${Math.round(prefs.volume * 100)}%`}
        onChange={(v) => {
          setPref("volume", v);
          sfx.setVolume(v);
        }}
      />

      <div className="rounded-2xl border border-orange-100 bg-white/70 p-4">
        <div className="mb-3 text-[12.5px] font-bold text-cocoa">Послушай звуки</div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {preview.map(({ label, run, icon: Icon }) => (
            <button
              key={label}
              onClick={() => {
                if (!on) {
                  sfx.setEnabled(true);
                  setOn(true);
                }
                run();
              }}
              className="btn-press flex flex-col items-center gap-2 rounded-xl border border-orange-100 bg-orange-50/60 px-3 py-3.5 text-xs font-bold text-cocoa-soft transition-colors hover:border-orange-300 hover:bg-orange-50 hover:text-orange-600"
            >
              <Icon size={16} />
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
