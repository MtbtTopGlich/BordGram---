import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Camera,
  Check,
  Copy,
  Crown,
  Link2,
  Loader2,
  LogOut,
  Pencil,
  Search,
  Shield,
  ShieldCheck,
  Trash2,
  UserMinus,
  UserPlus,
  Users,
} from "lucide-react";
import { Avatar, ModalShell, Spinner } from "./bits";
import { useAuth, useToast } from "../state";
import {
  addMembers,
  canManage,
  createGroup,
  deleteGroup,
  inviteTaken,
  isValidInvite,
  listenMembers,
  normalizeInvite,
  removeMember,
  setMemberRole,
  updateGroup,
  type Group,
  type GroupMember,
  type GroupRole,
} from "../lib/groups";
import type { ContactDoc } from "../db";
import { cx, fileToAvatar, uid as randomId } from "../lib/utils";
import { sfx } from "../lib/sounds";

/* ================= создание группы ================= */

const STEPS = ["Название", "Ссылка", "Участники"];

export function CreateGroupModal({
  open,
  onClose,
  contacts,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  contacts: ContactDoc[];
  onCreated: (gid: string) => void;
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [step, setStep] = useState(0);
  const [title, setTitle] = useState("");
  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState("");
  const [invite, setInvite] = useState("");
  const [inviteErr, setInviteErr] = useState("");
  const [checking, setChecking] = useState(false);
  const [picked, setPicked] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setStep(0);
      setTitle("");
      setBio("");
      setAvatar("");
      setInvite(randomId().slice(0, 8));
      setInviteErr("");
      setPicked([]);
      setSearch("");
    }
  }, [open]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return contacts;
    return contacts.filter(
      (c) => c.nickname.toLowerCase().includes(q) || c.usernameDisplay.toLowerCase().includes(q)
    );
  }, [contacts, search]);

  const nextFromTitle = () => {
    if (title.trim().length < 2) {
      toast("Название — минимум 2 символа", "err");
      sfx.error();
      return;
    }
    sfx.open();
    setStep(1);
  };

  const nextFromInvite = async () => {
    const code = normalizeInvite(invite);
    if (!isValidInvite(code)) {
      setInviteErr("4–32 символа: a-z, 0-9, _ и -");
      sfx.error();
      return;
    }
    setChecking(true);
    try {
      if (await inviteTaken(code)) {
        setInviteErr("Эта ссылка уже занята");
        sfx.error();
        return;
      }
      setInvite(code);
      setInviteErr("");
      sfx.open();
      setStep(2);
    } finally {
      setChecking(false);
    }
  };

  const submit = async () => {
    if (!user) return;
    setBusy(true);
    try {
      const chosen = contacts
        .filter((c) => picked.includes(c.uid))
        .map((c) => ({
          uid: c.uid,
          nickname: c.nickname,
          usernameDisplay: c.usernameDisplay,
          avatar: c.avatar,
        }));
      const gid = await createGroup({
        title: title.trim(),
        bio: bio.trim(),
        avatar,
        invite: normalizeInvite(invite),
        owner: user,
        memberProfiles: chosen,
      });
      sfx.success();
      toast(`Группа «${title.trim()}» создана`, "ok");
      onCreated(gid);
      onClose();
    } catch {
      toast("Не удалось создать группу", "err");
    } finally {
      setBusy(false);
    }
  };

  const link = `${window.location.origin}/join/${normalizeInvite(invite) || "…"}`;

  return (
    <ModalShell open={open} onClose={onClose} maxW="max-w-md">
      <div className="mb-4 flex items-center gap-3 pr-8">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-amber-400 text-white shadow-orangeSoft">
          <Users size={19} />
        </span>
        <div>
          <h3 className="font-display text-lg font-bold leading-tight">Новая группа</h3>
          <p className="text-xs font-medium text-cocoa-soft">{STEPS[step]}</p>
        </div>
      </div>

      <div className="mb-5 flex gap-1.5">
        {STEPS.map((s, i) => (
          <div key={s} className="h-1.5 flex-1 overflow-hidden rounded-full bg-orange-100">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-orange-500 to-amber-400"
              initial={false}
              animate={{ width: i < step ? "100%" : i === step ? "55%" : "0%" }}
              transition={{ duration: 0.35 }}
            />
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="s0" initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -18 }} className="space-y-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => fileRef.current?.click()}
                className="btn-press relative shrink-0"
                title="Аватарка группы"
              >
                <Avatar src={avatar} name={title || "Г"} seed={invite} size={68} />
                <span className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full bg-orange-500 text-white shadow-orangeSoft">
                  <Camera size={13} />
                </span>
              </button>
              <div className="min-w-0 flex-1">
                <label className="block">
                  <span className="mb-1.5 block text-[13px] font-semibold text-cocoa-soft">
                    Название <span className="text-orange-600">*</span>
                  </span>
                  <input
                    className="field !py-2.5"
                    placeholder="Например: Друзья"
                    value={title}
                    maxLength={50}
                    autoFocus
                    onChange={(e) => setTitle(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && nextFromTitle()}
                  />
                </label>
              </div>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  try {
                    setAvatar(await fileToAvatar(f));
                    sfx.tick();
                  } catch {
                    toast("Не удалось прочитать картинку", "err");
                  }
                  e.target.value = "";
                }}
              />
            </div>

            <label className="block">
              <span className="mb-1.5 flex justify-between text-[13px] font-semibold text-cocoa-soft">
                Био <span className="text-cocoa-soft/60">необязательно</span>
              </span>
              <textarea
                className="field min-h-[80px] resize-none"
                placeholder="О чём эта группа…"
                value={bio}
                maxLength={140}
                onChange={(e) => setBio(e.target.value)}
              />
            </label>

            <button
              onClick={nextFromTitle}
              className="btn-press flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 py-3.5 text-sm font-bold text-white shadow-orangeGlow"
            >
              Дальше <ArrowRight size={16} />
            </button>
          </motion.div>
        )}

        {step === 1 && (
          <motion.div key="s1" initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -18 }} className="space-y-4">
            <p className="text-[12.5px] leading-relaxed text-cocoa-soft">
              Приватная ссылка-приглашение. Кто перейдёт по ней — попадёт в группу. Если он не вошёл в
              аккаунт, сначала откроется вход, а потом группа.
            </p>
            <label className="block">
              <span className="mb-1.5 flex items-center justify-between text-[13px] font-semibold text-cocoa-soft">
                Код ссылки
                {inviteErr && <span className="text-[12px] text-red-500">{inviteErr}</span>}
              </span>
              <div className="relative">
                <Link2 size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                <input
                  className={cx("field pl-11", inviteErr && "field-error")}
                  value={invite}
                  maxLength={32}
                  onChange={(e) => {
                    setInvite(e.target.value);
                    setInviteErr("");
                  }}
                  onKeyDown={(e) => e.key === "Enter" && void nextFromInvite()}
                />
              </div>
            </label>
            <div className="flex items-center gap-2 rounded-2xl bg-orange-50 px-3.5 py-2.5">
              <span className="min-w-0 flex-1 truncate text-[12px] font-semibold text-cocoa">{link}</span>
              <button
                onClick={() => {
                  void navigator.clipboard?.writeText(link);
                  sfx.tick();
                  toast("Ссылка скопирована", "ok");
                }}
                className="btn-press shrink-0 rounded-full bg-white p-1.5 text-orange-600 shadow-warm"
              >
                <Copy size={13} />
              </button>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setStep(0)}
                className="btn-press rounded-full bg-orange-100/80 px-5 py-3.5 text-sm font-bold text-cocoa-soft"
              >
                <ArrowLeft size={15} />
              </button>
              <button
                onClick={() => void nextFromInvite()}
                disabled={checking}
                className="btn-press flex flex-1 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 py-3.5 text-sm font-bold text-white shadow-orangeGlow disabled:opacity-60"
              >
                {checking ? <Loader2 size={16} className="animate-spin" /> : <ArrowRight size={16} />} Дальше
              </button>
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div key="s2" initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -18 }} className="space-y-3">
            <div className="relative">
              <Search size={15} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
              <input
                className="field !py-2.5 pl-11 text-sm"
                placeholder="Поиск по контактам"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <div className="warm-scroll max-h-[240px] space-y-1.5 overflow-y-auto pr-1">
              {filtered.length === 0 && (
                <p className="py-8 text-center text-[12.5px] text-cocoa-soft">
                  Контактов нет — можно пригласить позже по ссылке
                </p>
              )}
              {filtered.map((c) => {
                const on = picked.includes(c.uid);
                return (
                  <button
                    key={c.uid}
                    onClick={() => {
                      sfx.tick();
                      setPicked((p) => (on ? p.filter((x) => x !== c.uid) : [...p, c.uid]));
                    }}
                    className={cx(
                      "flex w-full items-center gap-3 rounded-2xl border p-2.5 text-left transition-colors",
                      on ? "border-orange-400 bg-orange-50" : "border-orange-100 bg-white hover:bg-orange-50/60"
                    )}
                  >
                    <Avatar src={c.avatar} name={c.nickname} seed={c.usernameDisplay} size={38} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[13.5px] font-bold">{c.nickname}</div>
                      <div className="truncate text-[11.5px] font-semibold text-orange-600">@{c.usernameDisplay}</div>
                    </div>
                    <span
                      className={cx(
                        "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 transition-colors",
                        on ? "border-orange-500 bg-orange-500 text-white" : "border-orange-200"
                      )}
                    >
                      {on && <Check size={11} />}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setStep(1)}
                className="btn-press rounded-full bg-orange-100/80 px-5 py-3.5 text-sm font-bold text-cocoa-soft"
              >
                <ArrowLeft size={15} />
              </button>
              <button
                onClick={() => void submit()}
                disabled={busy}
                className="btn-press flex flex-1 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 py-3.5 text-sm font-bold text-white shadow-orangeGlow disabled:opacity-60"
              >
                {busy ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
                Создать{picked.length > 0 ? ` (${picked.length + 1})` : ""}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </ModalShell>
  );
}

/* ================= информация и управление ================= */

export function GroupInfoModal({
  open,
  onClose,
  group,
  contacts,
  onLeave,
}: {
  open: boolean;
  onClose: () => void;
  group: Group | null;
  contacts: ContactDoc[];
  onLeave: () => void;
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [tab, setTab] = useState<"info" | "members" | "add">("info");
  const [title, setTitle] = useState("");
  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState("");
  const [busy, setBusy] = useState(false);
  const [picked, setPicked] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!group) return;
    setTitle(group.title);
    setBio(group.bio);
    setAvatar(group.avatar);
    return listenMembers(group.id, setMembers);
  }, [group]);

  useEffect(() => {
    if (open) {
      setTab("info");
      setPicked([]);
    }
  }, [open]);

  if (!group || !user) return null;

  const myRole = members.find((m) => m.uid === user.uid)?.role ?? "member";
  const manage = canManage(myRole);
  const isOwner = myRole === "owner";
  const link = `${window.location.origin}/join/${group.invite}`;
  const candidates = contacts.filter((c) => !group.members.includes(c.uid));

  const save = async () => {
    setBusy(true);
    try {
      await updateGroup(group.id, { title: title.trim(), bio: bio.trim(), avatar });
      sfx.success();
      toast("Группа обновлена", "ok");
    } catch {
      toast("Не удалось сохранить", "err");
    } finally {
      setBusy(false);
    }
  };

  const invite = async () => {
    if (picked.length === 0) return;
    setBusy(true);
    try {
      await addMembers(
        group.id,
        contacts
          .filter((c) => picked.includes(c.uid))
          .map((c) => ({ uid: c.uid, nickname: c.nickname, usernameDisplay: c.usernameDisplay, avatar: c.avatar }))
      );
      sfx.success();
      toast(`Добавлено: ${picked.length}`, "ok");
      setPicked([]);
      setTab("members");
    } catch {
      toast("Не удалось пригласить", "err");
    } finally {
      setBusy(false);
    }
  };

  const changeRole = async (m: GroupMember, role: GroupRole) => {
    try {
      await setMemberRole(group.id, m.uid, role);
      sfx.tick();
      toast(role === "admin" ? `@${m.usernameDisplay} — совладелец` : `С @${m.usernameDisplay} снята роль`, "ok");
    } catch {
      toast("Ошибка", "err");
    }
  };

  const kick = async (m: GroupMember) => {
    try {
      await removeMember(group.id, m.uid);
      sfx.close();
      toast(`@${m.usernameDisplay} исключён`, "info");
    } catch {
      toast("Ошибка", "err");
    }
  };

  return (
    <ModalShell open={open} onClose={onClose} maxW="max-w-md">
      <div className="mb-4 flex items-center gap-3 pr-8">
        <div className="relative shrink-0">
          <Avatar src={avatar} name={title} seed={group.invite} size={56} />
          {manage && (
            <button
              onClick={() => fileRef.current?.click()}
              className="btn-press absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-orange-500 text-white shadow"
            >
              <Camera size={11} />
            </button>
          )}
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                setAvatar(await fileToAvatar(f));
              } catch {
                toast("Не удалось прочитать картинку", "err");
              }
              e.target.value = "";
            }}
          />
        </div>
        <div className="min-w-0">
          <h3 className="truncate font-display text-lg font-bold leading-tight">{group.title}</h3>
          <p className="text-xs font-medium text-cocoa-soft">{members.length} участников</p>
        </div>
      </div>

      <div className="mb-4 grid grid-cols-3 gap-1 rounded-full bg-orange-100/70 p-1">
        {([["info", "О группе"], ["members", "Участники"], ["add", "Пригласить"]] as const).map(([id, label]) => (
          <button
            key={id}
            onClick={() => {
              setTab(id);
              sfx.tick();
            }}
            className={cx(
              "rounded-full py-2 text-[12px] font-bold transition-colors",
              tab === id ? "bg-white text-orange-600 shadow-warm" : "text-cocoa-soft"
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "info" && (
        <div className="space-y-3.5">
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-semibold text-cocoa-soft">Название</span>
            <input className="field" value={title} disabled={!manage} maxLength={50} onChange={(e) => setTitle(e.target.value)} />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-semibold text-cocoa-soft">Био</span>
            <textarea
              className="field min-h-[72px] resize-none"
              value={bio}
              disabled={!manage}
              maxLength={140}
              onChange={(e) => setBio(e.target.value)}
            />
          </label>
          <div>
            <span className="mb-1.5 block text-[13px] font-semibold text-cocoa-soft">Приватная ссылка</span>
            <div className="flex items-center gap-2 rounded-2xl bg-orange-50 px-3.5 py-2.5">
              <Link2 size={14} className="shrink-0 text-orange-500" />
              <span className="min-w-0 flex-1 truncate text-[12px] font-semibold text-cocoa">{link}</span>
              <button
                onClick={() => {
                  void navigator.clipboard?.writeText(link);
                  sfx.tick();
                  toast("Ссылка скопирована", "ok");
                }}
                className="btn-press shrink-0 rounded-full bg-white p-1.5 text-orange-600 shadow-warm"
              >
                <Copy size={13} />
              </button>
            </div>
          </div>

          {manage && (
            <button
              onClick={() => void save()}
              disabled={busy}
              className="btn-press flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 py-3 text-sm font-bold text-white shadow-orangeGlow disabled:opacity-60"
            >
              {busy ? <Spinner size={15} className="border-white/40 border-t-white" /> : <Pencil size={14} />} Сохранить
            </button>
          )}

          <button
            onClick={async () => {
              if (isOwner) {
                await deleteGroup(group.id, group.invite);
                toast("Группа удалена", "info");
              } else {
                await removeMember(group.id, user.uid);
                toast("Ты покинул группу", "info");
              }
              onClose();
              onLeave();
            }}
            className="btn-press flex w-full items-center justify-center gap-2 rounded-full bg-red-50 py-3 text-sm font-bold text-red-500 transition hover:bg-red-100"
          >
            {isOwner ? <Trash2 size={14} /> : <LogOut size={14} />}
            {isOwner ? "Удалить группу" : "Покинуть группу"}
          </button>
        </div>
      )}

      {tab === "members" && (
        <div className="warm-scroll max-h-[320px] space-y-1.5 overflow-y-auto pr-1">
          {members.map((m) => (
            <div key={m.uid} className="rounded-2xl border border-orange-100 bg-white p-2.5">
              <div className="flex items-center gap-3">
                <Avatar src={m.avatar} name={m.nickname} seed={m.usernameDisplay} size={38} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate text-[13.5px] font-bold">{m.nickname}</span>
                    {m.role === "owner" && (
                      <span className="flex items-center gap-1 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-1.5 py-0.5 text-[9.5px] font-bold text-white">
                        <Crown size={8} /> владелец
                      </span>
                    )}
                    {m.role === "admin" && (
                      <span className="flex items-center gap-1 rounded-full bg-orange-100 px-1.5 py-0.5 text-[9.5px] font-bold text-orange-700">
                        <ShieldCheck size={8} /> совладелец
                      </span>
                    )}
                  </div>
                  <div className="truncate text-[11.5px] font-semibold text-orange-600">@{m.usernameDisplay}</div>
                </div>
              </div>
              {isOwner && m.uid !== user.uid && (
                <div className="mt-2 flex gap-1.5 pl-[50px]">
                  <button
                    onClick={() => void changeRole(m, m.role === "admin" ? "member" : "admin")}
                    className="btn-press flex items-center gap-1.5 rounded-full bg-orange-100/80 px-3 py-1.5 text-[11px] font-bold text-cocoa transition hover:bg-orange-200/80"
                  >
                    <Shield size={11} /> {m.role === "admin" ? "Снять права" : "Сделать совладельцем"}
                  </button>
                  <button
                    onClick={() => void kick(m)}
                    className="btn-press flex items-center gap-1.5 rounded-full bg-red-50 px-3 py-1.5 text-[11px] font-bold text-red-500 transition hover:bg-red-100"
                  >
                    <UserMinus size={11} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === "add" && (
        <div className="space-y-3">
          {!manage ? (
            <p className="rounded-2xl bg-orange-50 p-4 text-center text-[12.5px] text-cocoa-soft">
              Приглашать могут только владелец и совладельцы. Но ты можешь поделиться ссылкой выше.
            </p>
          ) : (
            <>
              <div className="warm-scroll max-h-[260px] space-y-1.5 overflow-y-auto pr-1">
                {candidates.length === 0 && (
                  <p className="py-8 text-center text-[12.5px] text-cocoa-soft">
                    Все твои контакты уже в группе
                  </p>
                )}
                {candidates.map((c) => {
                  const on = picked.includes(c.uid);
                  return (
                    <button
                      key={c.uid}
                      onClick={() => {
                        sfx.tick();
                        setPicked((p) => (on ? p.filter((x) => x !== c.uid) : [...p, c.uid]));
                      }}
                      className={cx(
                        "flex w-full items-center gap-3 rounded-2xl border p-2.5 text-left transition-colors",
                        on ? "border-orange-400 bg-orange-50" : "border-orange-100 bg-white hover:bg-orange-50/60"
                      )}
                    >
                      <Avatar src={c.avatar} name={c.nickname} seed={c.usernameDisplay} size={36} />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[13px] font-bold">{c.nickname}</div>
                        <div className="truncate text-[11px] font-semibold text-orange-600">@{c.usernameDisplay}</div>
                      </div>
                      <span
                        className={cx(
                          "flex h-5 w-5 items-center justify-center rounded-full border-2",
                          on ? "border-orange-500 bg-orange-500 text-white" : "border-orange-200"
                        )}
                      >
                        {on && <Check size={11} />}
                      </span>
                    </button>
                  );
                })}
              </div>
              <button
                onClick={() => void invite()}
                disabled={busy || picked.length === 0}
                className="btn-press flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 py-3 text-sm font-bold text-white shadow-orangeGlow disabled:opacity-40"
              >
                {busy ? <Spinner size={15} className="border-white/40 border-t-white" /> : <UserPlus size={14} />}
                Пригласить{picked.length > 0 ? ` (${picked.length})` : ""}
              </button>
            </>
          )}
        </div>
      )}
    </ModalShell>
  );
}

/* ================= экран приглашения ================= */

export function JoinBanner({
  group,
  onJoin,
  onCancel,
  busy,
}: {
  group: Group;
  onJoin: () => void;
  onCancel: () => void;
  busy: boolean;
}) {
  return (
    <div className="flex h-full items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className="w-full max-w-sm rounded-[28px] border border-orange-100 bg-white/85 p-7 text-center shadow-2xl backdrop-blur-xl"
      >
        <div className="mx-auto mb-4">
          <Avatar src={group.avatar} name={group.title} seed={group.invite} size={88} />
        </div>
        <h2 className="font-display text-xl font-bold">{group.title}</h2>
        <p className="mt-1 text-[12.5px] font-semibold text-orange-600">
          {group.members.length} участников
        </p>
        {group.bio && <p className="mt-3 text-[13px] leading-relaxed text-cocoa-soft">{group.bio}</p>}
        <p className="mt-4 rounded-2xl bg-orange-50 px-4 py-2.5 text-[12.5px] font-semibold text-cocoa">
          Тебя пригласили в эту группу
        </p>
        <div className="mt-5 flex gap-2">
          <button
            onClick={onCancel}
            className="btn-press flex-1 rounded-full bg-orange-100/80 py-3 text-sm font-bold text-cocoa-soft"
          >
            Не сейчас
          </button>
          <button
            onClick={onJoin}
            disabled={busy}
            className="btn-press flex flex-[1.5] items-center justify-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 py-3 text-sm font-bold text-white shadow-orangeGlow disabled:opacity-60"
          >
            {busy ? <Spinner size={15} className="border-white/40 border-t-white" /> : <UserPlus size={15} />}
            Вступить
          </button>
        </div>
      </motion.div>
    </div>
  );
}


