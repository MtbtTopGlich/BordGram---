import { BrowserRouter, Navigate, Outlet, Route, Routes } from "react-router-dom";
import { motion } from "framer-motion";
import { Ban, LogOut } from "lucide-react";
import { AuthProvider, ToastProvider, useAuth } from "./state";
import { PrefsProvider } from "./lib/theme";
import AuthScreen from "./screens/AuthScreen";
import AppShell from "./screens/AppShell";
import ChatView from "./screens/ChatView";
import EmptyChat from "./screens/EmptyChat";
import GroupChat from "./screens/GroupChat";
import JoinGroup from "./screens/JoinGroup";
import { Logo, WarmBackdrop } from "./components/bits";
import type { ReactNode } from "react";

/* ---------- экран загрузки ---------- */

function Boot() {
  return (
    <div className="relative flex min-h-full flex-col items-center justify-center gap-6">
      <WarmBackdrop />
      <motion.div
        initial={{ opacity: 0, scale: 0.86 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 160, damping: 16 }}
      >
        <motion.div animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}>
          <Logo size={64} withWord={false} />
        </motion.div>
      </motion.div>
      <div className="text-center">
        <div className="font-display text-lg font-bold">
          Bord<span className="text-orange-600">Gram</span>
        </div>
        <div className="mt-1 text-xs font-semibold uppercase tracking-[0.24em] text-cocoa-soft">разогреваем…</div>
      </div>
    </div>
  );
}

/* ---------- охрана роутов ---------- */

function BannedScreen() {
  const { user, signOut } = useAuth();
  return (
    <div className="relative flex min-h-full items-center justify-center p-6">
      <WarmBackdrop />
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className="w-full max-w-md rounded-[28px] border border-red-200 bg-white/85 p-8 text-center shadow-2xl backdrop-blur-xl"
      >
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl bg-red-100 text-red-500">
          <Ban size={28} />
        </div>
        <h2 className="font-display text-2xl font-bold text-cocoa">Аккаунт заблокирован</h2>
        <p className="mt-2.5 text-sm leading-relaxed text-cocoa-soft">
          Доступ к BordGram для <span className="font-semibold text-cocoa">@{user?.usernameDisplay}</span> ограничен
          администратором.
        </p>
        {user?.banReason && (
          <p className="mt-3 rounded-2xl bg-red-50 px-4 py-3 text-[13px] font-semibold text-red-600">
            Причина: {user.banReason}
          </p>
        )}
        <button
          onClick={signOut}
          className="btn-press mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-6 py-3 text-sm font-bold text-white shadow-orangeGlow"
        >
          <LogOut size={15} /> Выйти
        </button>
      </motion.div>
    </div>
  );
}

function RequireAuth({ children }: { children: ReactNode }) {
  const { user, ready } = useAuth();
  if (!ready) return <Boot />;
  if (!user) return <Navigate to="/login" replace />;
  if (user.banned) return <BannedScreen />;
  return <>{children}</>;
}

function GuestOnly({ children }: { children: ReactNode }) {
  const { user, ready } = useAuth();
  if (!ready) return <Boot />;
  if (user) return <Navigate to="/" replace />;
  return <>{children}</>;
}

/* ---------- приложение ---------- */

export default function App() {
  return (
    <PrefsProvider>
      <AuthProvider>
        <ToastProvider>
          <BrowserRouter>
          <Routes>
            <Route
              path="/login"
              element={
                <GuestOnly>
                  <AuthScreen />
                </GuestOnly>
              }
            />
            <Route
              element={
                <RequireAuth>
                  <AppShell>
                    <Outlet />
                  </AppShell>
                </RequireAuth>
              }
            >
              <Route path="/" element={<EmptyChat />} />
              <Route path="/g/:gid" element={<GroupChat />} />
              <Route path="/join/:code" element={<JoinGroup />} />
              <Route path="/:userPath" element={<ChatView />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          </BrowserRouter>
        </ToastProvider>
      </AuthProvider>
    </PrefsProvider>
  );
}
