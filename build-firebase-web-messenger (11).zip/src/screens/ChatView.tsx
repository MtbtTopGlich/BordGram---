import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { doc, onSnapshot } from "firebase/firestore";
import {
  ArrowLeft,
  Ban,
  CheckCircle2,
  Clock3,
  Crown,
  ImagePlus,
  Info,
  Lock,
  Mic,
  Pencil,
  Phone,
  PhoneCall,
  PhoneMissed,
  Pin,
  Reply,
  SearchX,
  SendHorizontal,
  ShieldAlert,
  Smile,
  UserPlus,
  Video,
  VideoOff,
  X,
} from "lucide-react";
import { Avatar, BadgeMark, Spinner } from "../components/bits";
import { ImageBubble, RecorderBar, Ticks, VoiceBubble } from "../components/media";
import MessageMenu, { type MenuAction, type MenuTarget } from "../components/MessageMenu";
import UserInfoModal from "../components/UserInfoModal";
import { useCalls } from "../components/CallUI";
import StickerPanel, { PackViewer } from "../components/StickerPanel";
import { extractSoloEmoji, findStickersByEmoji, type Sticker } from "../lib/stickers";
import { useAuth, useToast } from "../state";
import { useData } from "./AppShell";
import {
  blockUser,
  callLabel,
  deliverMessage,
  ensureOutgoingMirror,
  getUserByUsername,
  isAdmin,
  isOwner,
  listenBlock,
  listenChatMeta,
  listenMessages,
  listenOutgoingRequest,
  listenTyping,
  markChatRead,
  sendContactRequest,
  setTyping,
  unblockUser,
  deleteMessage,
  editMessage,
  listenChatDoc,
  listenMyPin,
  pinForEveryone,
  pinForMe,
  previewOf,
  setContactFavorite,
  toggleReaction,
  type Message,
  type PinnedInfo,
  type Profile,
  type ReplyInfo,
} from "../db";
import { db } from "../lib/firebase";
import { chatIdOf, cx, dayKey, fileToImage, fmtDay, fmtTime, normalizeUsername } from "../lib/utils";
import { usePrefs } from "../lib/theme";
import { usePeerOnline } from "../lib/live";
import { sfx } from "../lib/sounds";

type PeerState = { kind: "loading" } | { kind: "none" } | { kind: "ok"; profile: Profile };

export default function ChatView() {
  const { userPath } = useParams();
  const raw = userPath ?? "";

  if (!raw.startsWith("@")) return <Navigate to="/" replace />;
  return <ChatInner username={normalizeUsername(raw)} key={normalizeUsername(raw)} />;
}

function ChatInner({ username }: { username: string }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const { contactOf } = useData();
  const { prefs } = usePrefs();
  const navigate = useNavigate();

  const [peer, setPeer] = useState<PeerState>({ kind: "loading" });
  const [peerUid, setPeerUid] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [msgLoaded, setMsgLoaded] = useState(false);
  const [text, setText] = useState("");
  const [iBlocked, setIBlocked] = useState(false);
  const [blockedMe, setBlockedMe] = useState(false);
  const [sentReq, setSentReq] = useState(false);
  const [busy, setBusy] = useState(false);
  const [recording, setRecording] = useState(false);
  const [peerReadAt, setPeerReadAt] = useState(0);
  const [peerTyping, setPeerTyping] = useState(false);
  const [menu, setMenu] = useState<MenuTarget | null>(null);
  const [editing, setEditing] = useState<Message | null>(null);
  const [replyTo, setReplyTo] = useState<ReplyInfo | null>(null);
  const [pinBoth, setPinBoth] = useState<PinnedInfo | null>(null);
  const [pinMine, setPinMine] = useState<PinnedInfo | null>(null);
  const [infoOpen, setInfoOpen] = useState(false);
  const [stickersOpen, setStickersOpen] = useState(false);
  const [viewPack, setViewPack] = useState("");
  const [suggest, setSuggest] = useState<Sticker[]>([]);
  const { startCall, busy: callBusy } = useCalls();
  const { online: peerOnline } = usePeerOnline(peerUid);
  const typingTimer = useRef<number | null>(null);
  const typingOn = useRef(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const imageRef = useRef<HTMLInputElement>(null);
  const prevCount = useRef(0);
  const initialized = useRef(false);

  const isSelf = !!user && !!peerUid && peerUid === user.uid;
  const isContact = !!peerUid && !!contactOf(peerUid);
  const canWrite = !iBlocked && !blockedMe && !isSelf && peer.kind === "ok";

  // резолвим username → uid
  useEffect(() => {
    let alive = true;
    setPeer({ kind: "loading" });
    setPeerUid(null);
    getUserByUsername(username)
      .then((p) => {
        if (!alive) return;
        if (!p) setPeer({ kind: "none" });
        else setPeerUid(p.uid);
      })
      .catch(() => alive && setPeer({ kind: "none" }));
    return () => {
      alive = false;
    };
  }, [username]);

  // живой профиль собеседника
  useEffect(() => {
    if (!peerUid) return;
    return onSnapshot(doc(db, "users", peerUid), (snap) => {
      if (snap.exists()) setPeer({ kind: "ok", profile: { ...(snap.data() as object), uid: snap.id } as Profile });
      else setPeer({ kind: "none" });
    });
  }, [peerUid]);

  // сообщения
  useEffect(() => {
    if (!user || !peerUid) return;
    initialized.current = false;
    prevCount.current = 0;
    setMsgLoaded(false);
    const un = listenMessages(chatIdOf(user.uid, peerUid), (items) => {
      const last = items[items.length - 1];
      if (initialized.current && items.length > prevCount.current && last && last.from !== user.uid) {
        sfx.receive();
      }
      initialized.current = true;
      prevCount.current = items.length;
      setMessages(items);
      setMsgLoaded(true);
    });
    return un;
  }, [user, peerUid]);

  // блокировки и исходящая заявка
  useEffect(() => {
    if (!user || !peerUid || peerUid === user.uid) return;
    const u1 = listenBlock(user.uid, peerUid, setIBlocked);
    const u2 = listenBlock(peerUid, user.uid, setBlockedMe);
    const u3 = listenOutgoingRequest(peerUid, user.uid, setSentReq);
    return () => {
      u1();
      u2();
      u3();
    };
  }, [user, peerUid]);

  // чинит «Ваши заявки»: если заявка у собеседника есть, а зеркала у меня нет — создаём
  useEffect(() => {
    if (!user || peer.kind !== "ok" || !sentReq || isSelf) return;
    void ensureOutgoingMirror(user, peer.profile).catch(() => undefined);
  }, [user, peer, sentReq, isSelf]);

  // «печатает…» собеседника + уборка своего статуса при выходе
  useEffect(() => {
    if (!user || !peerUid || peerUid === user.uid) return;
    const chatId = chatIdOf(user.uid, peerUid);
    const un = listenTyping(chatId, peerUid, setPeerTyping);
    return () => {
      un();
      if (typingOn.current) {
        typingOn.current = false;
        void setTyping(chatId, user.uid, false).catch(() => undefined);
      }
    };
  }, [user, peerUid]);

  // подсказка стикеров, когда в поле только эмодзи
  useEffect(() => {
    const emoji = extractSoloEmoji(text);
    if (!emoji) {
      setSuggest([]);
      return;
    }
    let alive = true;
    const t = window.setTimeout(() => {
      void findStickersByEmoji(emoji, 5).then((items) => {
        if (alive) setSuggest(items);
      });
    }, 220);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
  }, [text]);

  // перепроверка «печатает» по таймауту (чтобы индикатор сам гас)
  useEffect(() => {
    if (!peerTyping) return;
    const id = window.setTimeout(() => setPeerTyping(false), 6500);
    return () => window.clearTimeout(id);
  }, [peerTyping]);

  // закреплённые сообщения: общее и личное
  useEffect(() => {
    if (!user || !peerUid) return;
    const chatId = chatIdOf(user.uid, peerUid);
    const u1 = listenChatDoc(chatId, (d) => setPinBoth(d.pinned ?? null));
    const u2 = listenMyPin(user.uid, chatId, setPinMine);
    return () => {
      u1();
      u2();
    };
  }, [user, peerUid]);

  // статус прочтения: когда собеседник последний раз открывал чат
  useEffect(() => {
    if (!user || !peerUid || peerUid === user.uid) return;
    return listenChatMeta(chatIdOf(user.uid, peerUid), (m) => {
      const t = m.reads?.[peerUid];
      setPeerReadAt(t?.seconds ? t.seconds * 1000 : 0);
    });
  }, [user, peerUid]);

  // отмечаем прочитанным: при открытии чата и на каждое новое входящее
  useEffect(() => {
    if (!user || !peerUid || peerUid === user.uid || !msgLoaded) return;
    if (document.visibilityState === "hidden") return;
    const last = messages[messages.length - 1];
    if (!last) return;
    void markChatRead(chatIdOf(user.uid, peerUid), user.uid).catch(() => undefined);
  }, [user, peerUid, messages, msgLoaded]);

  // автоскролл
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 240;
    const last = messages[messages.length - 1];
    if (nearBottom || (last && last.from === user?.uid)) {
      el.scrollTo({ top: el.scrollHeight, behavior: initialized.current ? "smooth" : "auto" });
    }
  }, [messages, user]);

  const groups = useMemo(() => {
    const out: Array<{ day: string; label: string; items: Message[] }> = [];
    for (const m of messages) {
      const d = dayKey(m.createdAt);
      const g = out[out.length - 1];
      if (g && g.day === d) g.items.push(m);
      else out.push({ day: d, label: fmtDay(m.createdAt), items: [m] });
    }
    return out;
  }, [messages]);

  if (!user) return null;

  /* ---------- действия контекстного меню ---------- */

  const openMenu = (e: React.MouseEvent, m: Message) => {
    if (m.deleted) return;
    e.preventDefault();
    sfx.tick();
    const mine = m.from === user?.uid;
    setMenu({
      id: m.id,
      mine,
      canEdit: mine && (m.type ?? "text") === "text",
      x: e.clientX,
      y: e.clientY,
      myReaction: user ? m.reactions?.[user.uid] : undefined,
    });
  };

  const handleAction = async (a: MenuAction, id: string) => {
    if (!user || !peerUid) return;
    const chatId = chatIdOf(user.uid, peerUid);
    const m = messages.find((x) => x.id === id);
    if (!m) return;

    if (a === "copy") {
      const val = m.type === "image" ? "[Фотография]" : m.type === "voice" ? "[Голосовое сообщение]" : (m.text ?? "");
      try {
        await navigator.clipboard.writeText(val);
        toast("Скопировано", "ok");
      } catch {
        toast("Буфер обмена недоступен", "err");
      }
      return;
    }
    if (a === "reply") {
      setReplyTo({ id: m.id, from: m.from, preview: previewOf(m), kind: (m.type ?? "text") as ReplyInfo["kind"] });
      taRef.current?.focus();
      return;
    }
    if (a === "edit") {
      setEditing(m);
      setText(m.text ?? "");
      setTimeout(() => taRef.current?.focus(), 30);
      return;
    }
    if (a === "delete") {
      try {
        await deleteMessage(chatId, id);
        sfx.close();
        toast("Сообщение удалено", "info");
      } catch {
        toast("Не удалось удалить", "err");
      }
      return;
    }
    const info: PinnedInfo = { id: m.id, preview: previewOf(m), from: m.from };
    try {
      if (a === "pin-both") {
        await pinForEveryone(chatId, info);
        toast("Закреплено у обоих", "ok");
      } else {
        await pinForMe(user.uid, chatId, info);
        toast("Закреплено только у тебя", "ok");
      }
    } catch {
      toast("Не удалось закрепить", "err");
    }
  };

  const handleReact = async (id: string, emoji: string) => {
    if (!user || !peerUid) return;
    try {
      await toggleReaction(chatIdOf(user.uid, peerUid), id, user.uid, emoji);
    } catch {
      toast("Не удалось поставить реакцию", "err");
    }
  };

  const unpin = async (scope: "me" | "both") => {
    if (!user || !peerUid) return;
    const chatId = chatIdOf(user.uid, peerUid);
    sfx.close();
    try {
      if (scope === "both") await pinForEveryone(chatId, null);
      else await pinForMe(user.uid, chatId, null);
    } catch {
      toast("Не удалось открепить", "err");
    }
  };

  const saveEdit = async () => {
    if (!user || !peerUid || !editing) return;
    const t = text.trim();
    if (!t) return;
    const target = editing;
    setEditing(null);
    setText("");
    if (taRef.current) taRef.current.style.height = "auto";
    try {
      await editMessage(chatIdOf(user.uid, peerUid), target.id, t);
      sfx.success();
    } catch {
      toast("Не удалось изменить сообщение", "err");
    }
  };

  const send = async () => {
    if (editing) return void saveEdit();
    const t = text.trim();
    if (!t || !peerUid || !canWrite || busy) return;
    setText("");
    if (taRef.current) taRef.current.style.height = "auto";
    sfx.send();
    // мгновенно снимаем «печатает…»
    if (typingTimer.current) window.clearTimeout(typingTimer.current);
    if (typingOn.current) {
      typingOn.current = false;
      void setTyping(chatIdOf(user.uid, peerUid), user.uid, false).catch(() => undefined);
    }
    try {
      await deliverMessage(user.uid, peerUid, { type: "text", text: t, replyTo });
      setReplyTo(null);
    } catch {
      setText(t);
      toast("Сообщение не улетело — проверь сеть", "err");
    }
  };

  const sendImage = async (f: File) => {
    if (!peerUid || !canWrite) return;
    try {
      const dataUrl = await fileToImage(f);
      sfx.send();
      await deliverMessage(user.uid, peerUid, { type: "image", image: dataUrl });
    } catch {
      toast("Не удалось отправить изображение", "err");
    }
  };

  const sendSticker = async (s: Sticker) => {
    if (!peerUid || !canWrite) return;
    setSuggest([]);
    setText("");
    if (taRef.current) taRef.current.style.height = "auto";
    try {
      await deliverMessage(user.uid, peerUid, {
        type: "sticker",
        image: s.image,
        emoji: s.emoji,
        packId: s.packId,
        replyTo,
      });
      setReplyTo(null);
    } catch {
      toast("Стикер не отправился", "err");
    }
  };

  const sendVoice = async (dataUrl: string, secsVoice: number) => {
    setRecording(false);
    if (!peerUid || !canWrite) return;
    try {
      await deliverMessage(user.uid, peerUid, { type: "voice", audio: dataUrl, duration: secsVoice });
    } catch {
      toast("Голосовое не улетело — проверь сеть", "err");
    }
  };

  const doBlock = async () => {
    if (!peerUid || busy) return;
    setBusy(true);
    try {
      await blockUser(user.uid, peerUid);
      toast("Пользователь заблокирован", "info");
    } catch {
      toast("Ошибка блокировки", "err");
    } finally {
      setBusy(false);
    }
  };

  const doUnblock = async () => {
    if (!peerUid || busy) return;
    setBusy(true);
    try {
      await unblockUser(user.uid, peerUid);
      toast("Пользователь разблокирован", "ok");
    } catch {
      toast("Ошибка", "err");
    } finally {
      setBusy(false);
    }
  };

  const doSendRequest = async () => {
    if (peer.kind !== "ok" || busy) return;
    setBusy(true);
    try {
      await sendContactRequest(user, peer.profile);
      toast(`Заявка улетела к @${peer.profile.usernameDisplay}`, "ok");
    } catch {
      toast("Не удалось отправить заявку", "err");
    } finally {
      setBusy(false);
    }
  };

  const p = peer.kind === "ok" ? peer.profile : null;

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* ---------- header ---------- */}
      <div className="flex items-center gap-3 border-b border-orange-100/80 bg-white/60 px-4 py-3.5 sm:px-6">
        <button
          onClick={() => navigate("/")}
          className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-orange-100/70 text-cocoa-soft transition-colors hover:text-orange-600 md:hidden"
        >
          <ArrowLeft size={17} />
        </button>
        {peer.kind === "loading" ? (
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 animate-pulse rounded-full bg-orange-100" />
            <div className="space-y-1.5">
              <div className="h-3 w-28 animate-pulse rounded-full bg-orange-100" />
              <div className="h-2.5 w-20 animate-pulse rounded-full bg-orange-100/70" />
            </div>
          </div>
        ) : peer.kind === "none" ? (
          <div className="flex items-center gap-2 text-cocoa-soft">
            <SearchX size={18} /> <span className="text-sm font-semibold">@{username}</span>
          </div>
        ) : (
          <>
            <button
              onClick={() => {
                sfx.click();
                setInfoOpen(true);
              }}
              className="btn-press shrink-0"
              title="Информация о пользователе"
            >
              <Avatar src={p!.avatar} name={p!.nickname} seed={p!.username} size={44} active={isContact} />
            </button>
            <button onClick={() => { sfx.click(); setInfoOpen(true); }} className="min-w-0 flex-1 text-left">
              <div className="flex items-center gap-2">
                <span className="truncate text-[15.5px] font-bold">{p!.nickname}</span>
                <BadgeMark badge={p!.badge} size={15} />
                {isContact && (
                  <span className="flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-600">
                    <CheckCircle2 size={10} /> в контактах
                  </span>
                )}
                {isSelf && (
                  <span className="rounded-full bg-orange-100 px-2 py-0.5 text-[10px] font-bold text-orange-600">это ты</span>
                )}
                {isAdmin(p!) && (
                  <span className="flex items-center gap-1 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-2 py-0.5 text-[10px] font-bold text-white">
                    <Crown size={9} /> {isOwner(p!) ? "владелец" : "админ"}
                  </span>
                )}
              </div>
              <div className="flex h-4 items-center gap-2">
                <AnimatePresence mode="wait">
                  {peerTyping && !isSelf ? (
                    <motion.span
                      key="typing"
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -4 }}
                      className="flex items-center gap-1.5 text-[12.5px] font-bold text-orange-600"
                    >
                      печатает
                      <span className="flex gap-0.5">
                        {[0, 1, 2].map((i) => (
                          <motion.span
                            key={i}
                            animate={{ opacity: [0.25, 1, 0.25] }}
                            transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.18 }}
                            className="h-1 w-1 rounded-full bg-orange-500"
                          />
                        ))}
                      </span>
                    </motion.span>
                  ) : (
                    <motion.span
                      key="uname"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex min-w-0 items-center gap-2"
                    >
                      <span className="truncate text-[12.5px] font-semibold text-orange-600/90">@{p!.usernameDisplay}</span>
                      {!isSelf && (
                        <span
                          className={cx(
                            "hidden shrink-0 items-center gap-1 text-[11px] font-semibold sm:flex",
                            peerOnline ? "text-emerald-600" : "text-cocoa-soft/70"
                          )}
                        >
                          <span className={cx("h-1.5 w-1.5 rounded-full", peerOnline ? "bg-emerald-500" : "bg-cocoa-soft/40")} />
                          {peerOnline ? "в сети" : peerReadAt > 0 ? `заходил(а) ${fmtTime({ seconds: Math.floor(peerReadAt / 1000) })}` : "не в сети"}
                        </span>
                      )}
                    </motion.span>
                  )}
                </AnimatePresence>
              </div>
            </button>

            {/* звонки */}
            {!isSelf && (
              <div className="flex shrink-0 items-center gap-1.5">
                <button
                  onClick={() => p && startCall(p, "audio")}
                  disabled={callBusy || iBlocked || blockedMe}
                  title="Аудиозвонок"
                  className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-orange-100/80 text-orange-600 transition-colors hover:bg-orange-200/80 disabled:opacity-40"
                >
                  <Phone size={17} />
                </button>
                <button
                  onClick={() => p && startCall(p, "video")}
                  disabled={callBusy || iBlocked || blockedMe}
                  title="Видеозвонок"
                  className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeSoft transition hover:brightness-105 disabled:opacity-40"
                >
                  <Video size={17} />
                </button>
                <button
                  onClick={() => {
                    sfx.click();
                    setInfoOpen(true);
                  }}
                  title="Информация о пользователе"
                  className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-orange-100/80 text-cocoa-soft transition-colors hover:bg-orange-200/80 hover:text-orange-600"
                >
                  <Info size={17} />
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* ---------- тело ---------- */}
      {peer.kind === "none" ? (
        <div className="flex flex-1 items-center justify-center p-8">
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="max-w-sm text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[24px] bg-orange-100 text-orange-500">
              <SearchX size={26} />
            </div>
            <h3 className="font-display text-xl font-bold">Такого @{username} нет</h3>
            <p className="mt-2 text-sm leading-relaxed text-cocoa-soft">
              Проверь написание — поиск работает только по точному username
            </p>
            <button
              onClick={() => navigate("/")}
              className="btn-press mt-5 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-6 py-3 text-sm font-bold text-white shadow-orangeGlow"
            >
              На главную
            </button>
          </motion.div>
        </div>
      ) : isSelf ? (
        <div className="flex flex-1 items-center justify-center p-8">
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="max-w-sm text-center">
            <div className="mx-auto mb-4">
              <Avatar src={p!.avatar} name={p!.nickname} seed={p!.username} size={88} />
            </div>
            <h3 className="font-display text-xl font-bold">{p!.nickname}</h3>
            <p className="mt-1 text-sm font-semibold text-orange-600">@{p!.usernameDisplay}</p>
            {p!.bio && <p className="mt-3 text-sm leading-relaxed text-cocoa-soft">{p!.bio}</p>}
            <p className="mt-4 text-xs font-medium uppercase tracking-widest text-cocoa-soft/60">это твоя публичная карточка</p>
          </motion.div>
        </div>
      ) : (
        <>
          {/* баннеры */}
          <AnimatePresence>
            {peer.kind === "ok" && !isContact && !iBlocked && !blockedMe && (
              <motion.div
                initial={{ opacity: 0, y: -14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -14 }}
                className="mx-4 mt-4 rounded-2xl border border-amber-300/60 bg-gradient-to-r from-amber-50 to-orange-50 p-4 shadow-warm sm:mx-6"
              >
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-400/90 text-white shadow-warm">
                    <ShieldAlert size={17} />
                  </span>
                  <div className="flex-1">
                    <p className="text-[13px] leading-relaxed text-amber-950">
                      <b>Данный контакт не добавлен у вас в контактах.</b> Будьте уверены, что это не{" "}
                      <b className="text-red-600">СПАМ-БОТ</b> или же <b className="text-red-600">СКАМЕР</b>!
                    </p>
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      {sentReq ? (
                        <span className="flex items-center gap-1.5 rounded-full bg-orange-100 px-4 py-2 text-xs font-bold text-orange-600">
                          <Clock3 size={13} /> Заявка отправлена — ждём ответа
                        </span>
                      ) : (
                        <button
                          disabled={busy}
                          onClick={() => void doSendRequest()}
                          className="btn-press flex items-center gap-1.5 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-4 py-2 text-xs font-bold text-white shadow-orangeSoft transition hover:brightness-105 disabled:opacity-50"
                        >
                          {busy ? <Spinner size={13} className="border-white/40 border-t-white" /> : <UserPlus size={13} />} Отправить заявку в контакты
                        </button>
                      )}
                      <button
                        disabled={busy}
                        onClick={() => void doBlock()}
                        className="btn-press flex items-center gap-1.5 rounded-full bg-white/80 px-4 py-2 text-xs font-bold text-red-500 shadow-warm transition hover:bg-red-50 disabled:opacity-50"
                      >
                        <Ban size={13} /> Заблокировать
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
            {iBlocked && (
              <motion.div
                initial={{ opacity: 0, y: -14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -14 }}
                className="mx-4 mt-4 flex items-center gap-3 rounded-2xl border border-red-200 bg-red-50/80 p-4 shadow-warm sm:mx-6"
              >
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-400/90 text-white">
                  <Ban size={16} />
                </span>
                <p className="flex-1 text-[13px] font-semibold text-red-700">Вы заблокировали этого пользователя</p>
                <button
                  disabled={busy}
                  onClick={() => void doUnblock()}
                  className="btn-press rounded-full bg-white px-4 py-2 text-xs font-bold text-red-500 shadow-warm transition hover:bg-red-100 disabled:opacity-50"
                >
                  Разблокировать
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* закреплённые */}
          <AnimatePresence>
            {[
              pinBoth ? { info: pinBoth, scope: "both" as const } : null,
              pinMine ? { info: pinMine, scope: "me" as const } : null,
            ]
              .filter(Boolean)
              .map((x) => {
                const { info, scope } = x as { info: PinnedInfo; scope: "both" | "me" };
                return (
                  <motion.div
                    key={scope}
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden px-4 pt-3 sm:px-6"
                  >
                    <div className="flex items-center gap-2.5 rounded-2xl border border-orange-200 bg-white/85 px-3.5 py-2.5 shadow-warm">
                      <Pin size={14} className="shrink-0 text-orange-500" />
                      <div className="min-w-0 flex-1">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-orange-600">
                          {scope === "both" ? "Закреплено у обоих" : "Закреплено только у тебя"}
                        </div>
                        <button
                          onClick={() => {
                            const el = document.getElementById(`msg-${info.id}`);
                            el?.scrollIntoView({ behavior: "smooth", block: "center" });
                            el?.animate(
                              [{ transform: "scale(1)" }, { transform: "scale(1.04)" }, { transform: "scale(1)" }],
                              { duration: 520 }
                            );
                            sfx.click();
                          }}
                          className="block w-full truncate text-left text-[12.5px] font-semibold text-cocoa hover:text-orange-600"
                        >
                          {info.preview || "Сообщение"}
                        </button>
                      </div>
                      <button
                        onClick={() => void unpin(scope)}
                        className="btn-press shrink-0 rounded-full p-1.5 text-cocoa-soft transition-colors hover:bg-orange-50 hover:text-orange-600"
                        title="Открепить"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  </motion.div>
                );
              })}
          </AnimatePresence>

          {/* сообщения */}
          <div ref={scrollRef} className="chat-wall warm-scroll min-h-0 flex-1 overflow-y-auto px-4 py-5 sm:px-8">
            {peer.kind !== "loading" && msgLoaded && messages.length === 0 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex h-full flex-col items-center justify-center text-center">
                <div className="breathe mb-4 flex h-20 w-20 items-center justify-center rounded-[28px] bg-gradient-to-br from-orange-400 to-amber-300 text-3xl text-white shadow-orangeGlow">
                  <SendHorizontal size={30} />
                </div>
                <p className="text-sm font-semibold text-cocoa">
                  Напиши первым — <span className="text-orange-600">{p?.nickname}</span> будет рад
                </p>
                <p className="mt-1 text-xs text-cocoa-soft">сообщения доставляются мгновенно</p>
              </motion.div>
            )}
            {groups.map((g) => (
              <div key={g.day}>
                <div className="my-4 flex justify-center">
                  <span className="rounded-full bg-white/80 px-4 py-1.5 text-[11px] font-bold uppercase tracking-widest text-cocoa-soft shadow-warm">
                    {g.label || "…"}
                  </span>
                </div>
                <div className="space-y-1.5">
                  {g.items.map((m, i) => {
                    const mine = m.from === user.uid;
                    const prev = g.items[i - 1];
                    const next = g.items[i + 1];
                    const firstOfChain = !prev || prev.from !== m.from;
                    const lastOfChain = !next || next.from !== m.from;
                    const kind =
                      m.type === "call"
                        ? "call"
                        : m.type === "sticker" && m.image
                        ? "sticker"
                        : m.type === "image" && m.image
                          ? "image"
                          : m.type === "voice" && m.audio
                            ? "voice"
                            : "text";
                    const ms = (m.createdAt as { seconds?: number } | undefined)?.seconds;
                    const isRead = mine && !!ms && peerReadAt >= ms * 1000;
                    return (
                      <motion.div
                        key={m.id}
                        id={`msg-${m.id}`}
                        initial={{ opacity: 0, y: 10, scale: 0.97 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        transition={{ type: "spring", stiffness: 420, damping: 32 }}
                        onContextMenu={(e) => (kind === "call" ? e.preventDefault() : openMenu(e, m))}
                        className={cx(
                          "group/msg relative flex",
                          kind === "call" ? "justify-center" : mine ? "justify-end" : "justify-start"
                        )}
                      >
                        {kind === "call" ? (
                          (() => {
                            const good = m.callOutcome === "ended";
                            return (
                              <div
                                className={cx(
                                  "my-1 flex items-center gap-2.5 rounded-full border px-4 py-2 shadow-warm",
                                  good ? "border-orange-100 bg-white/85" : "border-red-200 bg-red-50/85"
                                )}
                              >
                                <span
                                  className={cx(
                                    "flex h-7 w-7 shrink-0 items-center justify-center rounded-full",
                                    good ? "bg-emerald-100 text-emerald-600" : "bg-red-100 text-red-500"
                                  )}
                                >
                                  {m.callKind === "video" ? (
                                    good ? <Video size={13} /> : <VideoOff size={13} />
                                  ) : good ? (
                                    <PhoneCall size={13} />
                                  ) : (
                                    <PhoneMissed size={13} />
                                  )}
                                </span>
                                <div className="min-w-0">
                                  <div
                                    className={cx(
                                      "truncate text-[12.5px] font-bold",
                                      good ? "text-cocoa" : "text-red-600"
                                    )}
                                  >
                                    {callLabel(m, mine)}
                                  </div>
                                  <div className="text-[10.5px] font-semibold text-cocoa-soft/70">
                                    {mine ? "исходящий" : "входящий"} · {fmtTime(m.createdAt)}
                                  </div>
                                </div>
                                {!good && !mine && p && (
                                  <button
                                    onClick={() => startCall(p, m.callKind === "video" ? "video" : "audio")}
                                    disabled={callBusy}
                                    className="btn-press ml-1 shrink-0 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-3 py-1.5 text-[11px] font-bold text-white shadow-orangeSoft disabled:opacity-50"
                                  >
                                    Перезвонить
                                  </button>
                                )}
                              </div>
                            );
                          })()
                        ) : m.deleted ? (
                          <div
                            className={cx(
                              "msg-bubble max-w-[78%] border border-dashed px-4 py-2.5 text-[13px] italic sm:max-w-[64%]",
                              mine ? "border-white/50 bg-orange-100/60 text-cocoa-soft" : "border-orange-200 bg-white/60 text-cocoa-soft"
                            )}
                          >
                            Сообщение удалено
                          </div>
                        ) : (
                        <div
                          className={cx(
                            "msg-bubble relative max-w-[78%] text-[14.5px] leading-relaxed sm:max-w-[64%]",
                            kind === "image" ? "p-1.5" : kind === "voice" ? "px-3.5 py-2.5" : kind === "sticker" ? "" : "px-4 py-2.5",
                            kind === "sticker"
                              ? "!bg-transparent !shadow-none"
                              : mine
                              ? "bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeSoft"
                              : "border border-orange-100 bg-white text-cocoa shadow-warm",
                            mine ? (lastOfChain ? "rounded-br-md" : "") : lastOfChain ? "rounded-bl-md" : "",
                            !firstOfChain && "-mt-0.5"
                          )}
                          style={{ wordBreak: "break-word" }}
                        >
                          {m.replyTo && (
                            <button
                              onClick={() => {
                                const el = document.getElementById(`msg-${m.replyTo!.id}`);
                                el?.scrollIntoView({ behavior: "smooth", block: "center" });
                                sfx.tick();
                              }}
                              className={cx(
                                "mb-1.5 flex w-full items-center gap-2 rounded-xl border-l-[3px] px-2.5 py-1.5 text-left text-[12px]",
                                mine ? "border-white/70 bg-white/15 text-white/90" : "border-orange-400 bg-orange-50 text-cocoa-soft"
                              )}
                            >
                              <Reply size={11} className="shrink-0 opacity-70" />
                              <span className="truncate">{m.replyTo.preview || "Сообщение"}</span>
                            </button>
                          )}
                            {kind === "sticker" ? (
                              <div className="relative">
                                <motion.button
                                  whileHover={{ scale: 1.05, rotate: -1.5 }}
                                  whileTap={{ scale: 0.95 }}
                                  onClick={() => {
                                    if (m.packId) {
                                      sfx.click();
                                      setViewPack(m.packId);
                                    }
                                  }}
                                  title="Посмотреть стикер-пак"
                                  className="block"
                                >
                                  <img
                                    src={m.image}
                                    alt={m.emoji ?? "стикер"}
                                    className="h-[132px] w-[132px] object-contain drop-shadow-md sm:h-[150px] sm:w-[150px]"
                                    draggable={false}
                                  />
                                </motion.button>
                                <span
                                  className={cx(
                                    "mt-0.5 flex items-center gap-1 text-[10px] font-semibold text-cocoa-soft/70",
                                    mine ? "justify-end" : "justify-start"
                                  )}
                                >
                                  {fmtTime(m.createdAt) || "…"}
                                  {mine && <Ticks read={isRead} light={false} />}
                                </span>
                              </div>
                            ) : kind === "image" ? (
                              <div className="relative">
                                <ImageBubble src={m.image as string} />
                              <span className="absolute bottom-2.5 right-2.5 flex items-center gap-1 rounded-full bg-black/45 px-2 py-0.5 text-[10px] font-bold text-white backdrop-blur-sm">
                                {fmtTime(m.createdAt) || "…"}
                                {mine && <Ticks read={isRead} light />}
                              </span>
                            </div>
                          ) : kind === "voice" ? (
                            <div className="flex flex-col gap-0.5">
                              <VoiceBubble src={m.audio as string} duration={m.duration ?? 0} mine={mine} seed={m.id} />
                              <span
                                className={cx(
                                  "-mt-0.5 flex items-center gap-1 self-end text-[9.5px] font-semibold",
                                  mine ? "text-white/60" : "text-cocoa-soft/50"
                                )}
                              >
                                {fmtTime(m.createdAt)}
                                {mine && <Ticks read={isRead} light />}
                              </span>
                            </div>
                          ) : (
                              <>
                                <span className="whitespace-pre-wrap">{m.text ?? ""}</span>
                                <span
                                  className={cx(
                                    "ml-2 inline-flex translate-y-[3px] select-none items-center gap-1 text-[10px] font-semibold",
                                    mine ? "text-white/75" : "text-cocoa-soft/60"
                                  )}
                                >
                                  {m.editedAt ? <Pencil size={8.5} className="mr-0.5 opacity-80" /> : null}
                                  {m.editedAt ? "изм. " : ""}
                                  {fmtTime(m.createdAt) || "…"}
                                  {mine && <Ticks read={isRead} light />}
                                </span>
                              </>
                            )}

                            {/* реакции */}
                            {m.reactions && Object.keys(m.reactions).length > 0 && (
                              <div className={cx("mt-1.5 flex flex-wrap gap-1", kind === "image" && "px-1 pb-1")}>
                                {Object.entries(
                                  Object.values(m.reactions).reduce<Record<string, number>>((acc, e) => {
                                    acc[e] = (acc[e] ?? 0) + 1;
                                    return acc;
                                  }, {})
                                ).map(([emoji, count]) => {
                                  const isMine = user && m.reactions?.[user.uid] === emoji;
                                  return (
                                    <motion.button
                                      key={emoji}
                                      initial={{ scale: 0.6, opacity: 0 }}
                                      animate={{ scale: 1, opacity: 1 }}
                                      whileTap={{ scale: 0.88 }}
                                      onClick={(ev) => {
                                        ev.stopPropagation();
                                        void handleReact(m.id, emoji);
                                      }}
                                      className={cx(
                                        "flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[11px] font-bold transition-colors",
                                        mine
                                          ? isMine
                                            ? "bg-white text-orange-600"
                                            : "bg-white/25 text-white"
                                          : isMine
                                            ? "bg-orange-500 text-white"
                                            : "bg-orange-100 text-cocoa"
                                      )}
                                    >
                                      <span className="text-[12px] leading-none">{emoji}</span>
                                      {count > 1 && count}
                                    </motion.button>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        )}
                        </motion.div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* ввод */}
          <div className="border-t border-orange-100/80 bg-white/60 p-3.5 sm:px-6">
            {blockedMe ? (
              <div className="flex items-center justify-center gap-2 rounded-2xl bg-orange-50 px-4 py-3.5 text-[13px] font-semibold text-cocoa-soft">
                <Lock size={14} className="text-orange-400" /> Пользователь ограничил переписку с тобой
              </div>
            ) : iBlocked ? null : peer.kind === "loading" ? null : recording ? (
              <div className="flex items-end gap-2.5">
                <RecorderBar
                  onSend={(d, s) => void sendVoice(d, s)}
                  onCancel={() => setRecording(false)}
                  onError={() => {
                    setRecording(false);
                    toast("Нет доступа к микрофону — проверь разрешения браузера", "err");
                  }}
                />
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void send();
                }}
                className="flex flex-col gap-2"
              >
                <AnimatePresence>
                  {(replyTo || editing) && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="flex items-center gap-2.5 rounded-2xl border border-orange-200 bg-orange-50/80 px-3.5 py-2">
                        {editing ? (
                          <Pencil size={14} className="shrink-0 text-orange-500" />
                        ) : (
                          <Reply size={14} className="shrink-0 text-orange-500" />
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="text-[10px] font-bold uppercase tracking-wider text-orange-600">
                            {editing ? "Редактирование" : "Ответ на сообщение"}
                          </div>
                          <div className="truncate text-[12.5px] font-medium text-cocoa">
                            {editing ? editing.text : replyTo?.preview}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            sfx.close();
                            setReplyTo(null);
                            if (editing) {
                              setEditing(null);
                              setText("");
                            }
                          }}
                          className="btn-press shrink-0 rounded-full p-1.5 text-cocoa-soft transition-colors hover:bg-white hover:text-orange-600"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* подсказки стикеров по эмодзи */}
                <AnimatePresence>
                  {suggest.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, height: 0 }}
                      animate={{ opacity: 1, y: 0, height: "auto" }}
                      exit={{ opacity: 0, y: 8, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="flex items-center gap-2 rounded-2xl border border-orange-200 bg-white/90 px-3 py-2">
                        <span className="shrink-0 text-[10.5px] font-bold uppercase tracking-wider text-orange-600">
                          стикеры
                        </span>
                        <div className="warm-scroll flex min-w-0 flex-1 gap-1.5 overflow-x-auto">
                          {suggest.map((s) => (
                            <motion.button
                              key={s.id}
                              type="button"
                              whileHover={{ scale: 1.12, y: -2 }}
                              whileTap={{ scale: 0.9 }}
                              onClick={() => void sendSticker(s)}
                              className="h-14 w-14 shrink-0 rounded-xl p-1 transition-colors hover:bg-orange-50"
                              title={s.packTitle ?? s.emoji}
                            >
                              <img src={s.image} alt={s.emoji} className="h-full w-full object-contain" draggable={false} />
                            </motion.button>
                          ))}
                        </div>
                        <button
                          type="button"
                          onClick={() => setSuggest([])}
                          className="btn-press shrink-0 rounded-full p-1 text-cocoa-soft hover:text-orange-600"
                        >
                          <X size={13} />
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="relative flex items-end gap-2">
                <input
                  ref={imageRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void sendImage(f);
                    e.target.value = "";
                  }}
                />
                <div className="flex flex-1 items-end gap-1 rounded-[22px] border-2 border-orange-200/60 bg-white transition-colors focus-within:border-orange-400">
                  <button
                    type="button"
                    onClick={() => {
                      sfx.tick();
                      imageRef.current?.click();
                    }}
                    disabled={!canWrite}
                    className="btn-press mb-1.5 ml-1.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-cocoa-soft transition-colors hover:bg-orange-50 hover:text-orange-600 disabled:opacity-40"
                    title="Отправить изображение"
                  >
                    <ImagePlus size={18} />
                  </button>
                  <textarea
                    ref={taRef}
                    rows={1}
                    value={text}
                    placeholder={sentReq || isContact ? "Напиши что-нибудь тёплое…" : "Можно писать и до добавления в контакты…"}
                    className="no-scrollbar max-h-[130px] w-full resize-none bg-transparent px-2 py-3 text-[14.5px] font-medium outline-none placeholder:text-cocoa-soft/55"
                    onChange={(e) => {
                      setText(e.target.value);
                      const el = e.target;
                      el.style.height = "auto";
                      el.style.height = Math.min(el.scrollHeight, 130) + "px";
                      // транслируем «печатает…» собеседнику
                      if (peerUid && canWrite) {
                        const chatId = chatIdOf(user.uid, peerUid);
                        if (!typingOn.current) {
                          typingOn.current = true;
                          void setTyping(chatId, user.uid, true).catch(() => undefined);
                        }
                        if (typingTimer.current) window.clearTimeout(typingTimer.current);
                        typingTimer.current = window.setTimeout(() => {
                          typingOn.current = false;
                          void setTyping(chatId, user.uid, false).catch(() => undefined);
                        }, 3500);
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey && prefs.enterToSend) {
                        e.preventDefault();
                        void send();
                      }
                    }}
                  />
                </div>
                <button
                  type="button"
                  onClick={() => {
                    sfx.click();
                    setStickersOpen((v) => !v);
                  }}
                  disabled={!canWrite}
                  title="Стикеры"
                  className={cx(
                    "btn-press flex h-[50px] w-[50px] shrink-0 items-center justify-center rounded-full border-2 transition-colors disabled:opacity-40",
                    stickersOpen
                      ? "border-orange-500 bg-orange-50 text-orange-600"
                      : "border-orange-200/70 bg-white text-cocoa-soft hover:border-orange-400 hover:text-orange-600"
                  )}
                >
                  <Smile size={19} />
                </button>

                <StickerPanel
                  open={stickersOpen}
                  onClose={() => setStickersOpen(false)}
                  onPick={(s) => void sendSticker(s)}
                  onOpenPack={(id) => {
                    setStickersOpen(false);
                    setViewPack(id);
                  }}
                />

                {text.trim() ? (
                  <motion.button
                    type="submit"
                    disabled={!canWrite}
                    whileTap={{ scale: 0.88 }}
                    className={cx(
                      "flex h-[50px] w-[50px] shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeGlow transition-all",
                      !canWrite && "cursor-not-allowed opacity-40 saturate-50"
                    )}
                    title="Отправить"
                  >
                    <SendHorizontal size={19} className="-translate-x-[1px] translate-y-[1px]" />
                  </motion.button>
                ) : (
                  <motion.button
                    type="button"
                    disabled={!canWrite}
                    whileTap={{ scale: 0.88 }}
                    onClick={() => {
                      if (!canWrite) return;
                      sfx.click();
                      setRecording(true);
                    }}
                    className={cx(
                      "flex h-[50px] w-[50px] shrink-0 items-center justify-center rounded-full border-2 border-orange-300/70 bg-white text-orange-500 shadow-warm transition-all hover:border-orange-500 hover:bg-orange-50 hover:text-orange-600",
                      !canWrite && "cursor-not-allowed opacity-40"
                    )}
                    title="Записать голосовое сообщение"
                  >
                    <Mic size={19} />
                  </motion.button>
                )}
                </div>
              </form>
            )}
          </div>
        </>
      )}

      <MessageMenu
        target={menu}
        onClose={() => setMenu(null)}
        onAction={(a, id) => void handleAction(a, id)}
        onReact={(id, emoji) => void handleReact(id, emoji)}
      />

      {viewPack && (
        <PackViewer packId={viewPack} onClose={() => setViewPack("")} onPick={(s) => void sendSticker(s)} />
      )}

      <UserInfoModal
        open={infoOpen}
        onClose={() => setInfoOpen(false)}
        profile={p}
        isContact={isContact}
        isFav={!!(peerUid && contactOf(peerUid)?.fav)}
        blocked={iBlocked}
        onToggleFav={() => {
          if (!user || !peerUid) return;
          const cur = contactOf(peerUid);
          void setContactFavorite(user.uid, peerUid, !cur?.fav).catch(() => undefined);
          sfx.tick();
        }}
        onBlock={() => {
          setInfoOpen(false);
          void (iBlocked ? doUnblock() : doBlock());
        }}
      />
    </div>
  );
}
