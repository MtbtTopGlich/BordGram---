import { motion } from "framer-motion";
import { AtSign, Bell, MousePointer2 } from "lucide-react";

export default function EmptyChat() {
  return (
    <div className="flex h-full flex-col items-center justify-center p-8 text-center max-md:hidden">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 120, damping: 16 }}
        className="breathe relative"
      >
        <div className="h-48 w-48 overflow-hidden rounded-[44%] border-4 border-white shadow-2xl sm:h-56 sm:w-56">
          <img src="/images/blob-empty.jpg" alt="" className="h-full w-full object-cover" draggable={false} />
        </div>
        <motion.span
          animate={{ y: [0, -8, 0] }}
          transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -right-3 -top-2 rounded-full bg-white px-3.5 py-1.5 text-xs font-bold text-orange-600 shadow-orangeSoft"
        >
          привет!
        </motion.span>
      </motion.div>

      <motion.h2
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12 }}
        className="mt-7 font-display text-2xl font-bold sm:text-3xl"
      >
        Выбери чат — и погнали
      </motion.h2>
      <motion.p
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-3 max-w-sm text-sm leading-relaxed text-cocoa-soft"
      >
        Наведи на меню слева, чтобы раскрыть контакты, или найди собеседника по точному @username
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.28 }}
        className="mt-7 flex flex-wrap items-center justify-center gap-2.5"
      >
        {[
          { icon: AtSign, text: "поиск по @username" },
          { icon: MousePointer2, text: "наведи — меню раскроется" },
          { icon: Bell, text: "заявки прилетают сюда" },
        ].map(({ icon: Icon, text }) => (
          <span
            key={text}
            className="flex items-center gap-2 rounded-full border border-orange-200/70 bg-white/80 px-4 py-2 text-xs font-semibold text-cocoa-soft shadow-warm"
          >
            <Icon size={13} className="text-orange-500" /> {text}
          </span>
        ))}
      </motion.div>
    </div>
  );
}
