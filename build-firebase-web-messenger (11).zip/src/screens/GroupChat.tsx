import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ImagePlus,
  Info,
  Mic,
  Pencil,
  Phone,
  PhoneCall,
  Reply,
  SendHorizontal,
  Smile,
  Users,
  Video,
  X,
} from "lucide-react";
import { Avatar, Spinner } from "../components/bits";
import { ImageBubble, RecorderBar, VoiceBubble } from "../components/media";
import MessageMenu, { type MenuAction, type MenuTarget } from "../components/MessageMenu";
import StickerPanel, { PackViewer } from "../components/StickerPanel";
import { GroupInfoModal } from "../components/GroupModals";
import { useCalls } from "../components/CallUI";
import { useAuth, useToast } from "../state";
import { useData } from "./AppShell";
import {
  canManage,
  deleteGroupMessage,
  editGroupMessage,
  listenGroup,
  listenGroupCall,
  listenGroupMessages,
  listenMembers,
  sendGroupMessage,
  toggleGroupReaction,
  type Group,
  type GroupCallState,
  type GroupMember,
  type GroupMessage,
} from "../lib/groups";
import { previewOf, type ReplyInfo } from "../db";
import { cx, dayKey, fileToImage, fmtDay, fmtTime } from "../lib/utils";
import { usePrefs } from "../lib/theme";
import { type Sticker } from "../lib/stickers";
import { sfx } from "../lib/sounds";

export default function GroupChat() {
  const { gid = "" } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const { contacts } = useData();
  const { prefs } = usePrefs();
  const { startGroupCall, busy: callBusy } = useCalls();
  const navigate = useNavigate();

  const [group, setGroup] = useState<Group | null>(null);
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [messages, setMessages] = useState<GroupMessage[]>([]);
  const [callState, setCallState] = useState<GroupCallState>({ active: false });
  const [text, setText] = useState("");
  const [recording, setRecording] = useState(false);
  const [menu, setMenu] = useState<MenuTarget | null>(null);
  const [editing, setEditing] = useState<GroupMessage | null>(null);
  const [replyTo, setReplyTo] = useState<ReplyInfo | null>(null);
  const [stickersOpen, setStickersOpen] = useState(false);
  const [viewPack, setViewPack] = useState("");
  const [infoOpen, setInfoOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const imageRef = useRef<HTMLInputElement>(null);
  const prevCount = useRef(0);
  const inited = useRef(false);

  useEffect(() => {
    if (!gid) return;
    inited.current = false;
    prevCount.current = 0;
    setLoaded(false);
    const u1 = listenGroup(gid, setGroup);
    const u2 = listenMembers(gid, setMembers);
    const u3 = listenGroupCall(gid, setCallState);
    const u4 = listenGroupMessages(gid, (items) => {
      const last = items[items.length - 1];
      if (inited.current && items.length > prevCount.current && last && last.from !== user?.uid) sfx.receive();
      inited.current = true;
      prevCount.current = items.length;
      setMessages(items);
      setLoaded(true);
    });
    return () => {
      u1();
      u2();
      u3();
      u4();
    };
  }, [gid, user?.uid]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const near = el.scrollHeight - el.scrollTop - el.clientHeight < 260;
    const last = messages[messages.length - 1];
    if (near || last?.from === user?.uid) {
      el.scrollTo({ top: el.scrollHeight, behavior: inited.current ? "smooth" : "auto" });
    }
  }, [messages, user?.uid]);

  const groups = useMemo(() => {
    const out: Array<{ day: string; label: string; items: GroupMessage[] }> = [];
    for (const m of messages) {
      const d = dayKey(m.createdAt);
      const g = out[out.length - 1];
      if (g && g.day === d) g.items.push(m);
      else out.push({ day: d, label: fmtDay(m.createdAt), items: [m] });
    }
    return out;
  }, [messages]);

  if (!user) return null;

  const myRole = members.find((m) => m.uid === user.uid)?.role;
  const amMember = !!group?.members.includes(user.uid);

  const send = async () => {
    if (editing) {
      const t = text.trim();
      if (!t) return;
      const target = editing;
      setEditing(null);
      setText("");
      if (taRef.current) taRef.current.style.height = "auto";
      await editGroupMessage(gid, target.id, t).catch(() => toast("Не удалось изменить", "err"));
      sfx.success();
      return;
    }
    const t = text.trim();
    if (!t || !amMember) return;
    setText("");
    if (taRef.current) taRef.current.style.height = "auto";
    sfx.send();
    try {
      await sendGroupMessage(gid, user, { type: "text", text: t, replyTo });
      setReplyTo(null);
    } catch {
      setText(t);
      toast("Сообщение не улетело", "err");
    }
  };

  const sendImage = async (f: File) => {
    try {
      const img = await fileToImage(f);
      sfx.send();
      await sendGroupMessage(gid, user, { type: "image", image: img, replyTo });
      setReplyTo(null);
    } catch {
      toast("Не удалось отправить изображение", "err");
    }
  };

  const sendSticker = async (s: Sticker) => {
    try {
      sfx.send();
      await sendGroupMessage(gid, user, {
        type: "sticker",
        image: s.image,
        emoji: s.emoji,
        packId: s.packId,
        replyTo,
      });
      setReplyTo(null);
    } catch {
      toast("Стикер не отправился", "err");
    }
  };

  const handleAction = async (a: MenuAction, id: string) => {
    const m = messages.find((x) => x.id === id);
    if (!m) return;
    if (a === "copy") {
      await navigator.clipboard.writeText(m.text ?? previewOf(m)).catch(() => undefined);
      toast("Скопировано", "ok");
      return;
    }
    if (a === "reply") {
      setReplyTo({ id: m.id, from: m.from, preview: previewOf(m), kind: (m.type ?? "text") as ReplyInfo["kind"] });
      taRef.current?.focus();
      return;
    }
    if (a === "edit") {
      setEditing(m);
      setText(m.text ?? "");
      setTimeout(() => taRef.current?.focus(), 30);
      return;
    }
    if (a === "delete") {
      await deleteGroupMessage(gid, id).catch(() => toast("Не удалось удалить", "err"));
      sfx.close();
      return;
    }
    toast("В группах закрепление пока недоступно", "info");
  };

  const react = async (id: string, emoji: string) => {
    await toggleGroupReaction(gid, id, user.uid, emoji).catch(() => undefined);
  };

  if (!group) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner size={26} />
      </div>
    );
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* шапка */}
      <div className="flex items-center gap-3 border-b border-orange-100/80 bg-white/60 px-4 py-3.5 sm:px-6">
        <button
          onClick={() => navigate("/")}
          className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-orange-100/70 text-cocoa-soft md:hidden"
        >
          <ArrowLeft size={17} />
        </button>
        <button onClick={() => setInfoOpen(true)} className="btn-press shrink-0">
          <Avatar src={group.avatar} name={group.title} seed={group.invite} size={44} />
        </button>
        <button onClick={() => setInfoOpen(true)} className="min-w-0 flex-1 text-left">
          <div className="flex items-center gap-1.5">
            <span className="truncate text-[15.5px] font-bold">{group.title}</span>
            <span className="flex shrink-0 items-center gap-1 rounded-full bg-orange-100 px-2 py-0.5 text-[10px] font-bold text-orange-700">
              <Users size={9} /> группа
            </span>
          </div>
          <div className="truncate text-[12.5px] font-semibold text-cocoa-soft">
            {members.length} участников
          </div>
        </button>

        <div className="flex shrink-0 items-center gap-1.5">
          <button
            onClick={() => startGroupCall(group, "audio")}
            disabled={callBusy || !amMember}
            title="Групповой аудиозвонок"
            className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-orange-100/80 text-orange-600 hover:bg-orange-200/80 disabled:opacity-40"
          >
            <Phone size={17} />
          </button>
          <button
            onClick={() => startGroupCall(group, "video")}
            disabled={callBusy || !amMember}
            title="Групповой видеозвонок"
            className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeSoft disabled:opacity-40"
          >
            <Video size={17} />
          </button>
          <button
            onClick={() => setInfoOpen(true)}
            title="О группе"
            className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-orange-100/80 text-cocoa-soft hover:text-orange-600"
          >
            <Info size={17} />
          </button>
        </div>
      </div>

      {/* идёт звонок */}
      <AnimatePresence>
        {callState.active && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden px-4 pt-3 sm:px-6"
          >
            <div className="flex items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-2.5">
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[12.5px] font-bold text-emerald-800">
                  Групповой звонок · {callState.participants?.length ?? 0} в звонке
                </div>
                <div className="truncate text-[11px] font-semibold text-emerald-700/70">
                  начал(а) {callState.startedName}
                </div>
              </div>
              <button
                onClick={() => startGroupCall(group, callState.kind ?? "audio")}
                disabled={callBusy}
                className="btn-press shrink-0 rounded-full bg-emerald-500 px-4 py-2 text-xs font-bold text-white shadow disabled:opacity-50"
              >
                Присоединиться
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* сообщения */}
      <div ref={scrollRef} className="chat-wall warm-scroll min-h-0 flex-1 overflow-y-auto px-4 py-5 sm:px-8">
        {loaded && messages.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="breathe mb-4 flex h-20 w-20 items-center justify-center rounded-[28px] bg-gradient-to-br from-orange-400 to-amber-300 text-white shadow-orangeGlow">
              <Users size={30} />
            </div>
            <p className="text-sm font-semibold text-cocoa">Группа создана — напиши первым!</p>
            <p className="mt-1 text-xs text-cocoa-soft">{members.length} участников уже здесь</p>
          </div>
        )}

        {groups.map((g) => (
          <div key={g.day}>
            <div className="my-4 flex justify-center">
              <span className="rounded-full bg-white/80 px-4 py-1.5 text-[11px] font-bold uppercase tracking-widest text-cocoa-soft shadow-warm">
                {g.label}
              </span>
            </div>
            <div className="space-y-1.5">
              {g.items.map((m, i) => {
                const mine = m.from === user.uid;
                const prev = g.items[i - 1];
                const first = !prev || prev.from !== m.from;
                const kind =
                  m.type === "sticker" && m.image
                    ? "sticker"
                    : m.type === "image" && m.image
                      ? "image"
                      : m.type === "voice" && m.audio
                        ? "voice"
                        : "text";

                return (
                  <motion.div
                    key={m.id}
                    id={`gmsg-${m.id}`}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    onContextMenu={(e) => {
                      if (m.deleted) return;
                      e.preventDefault();
                      sfx.tick();
                      setMenu({
                        id: m.id,
                        mine,
                        canEdit: mine && kind === "text",
                        x: e.clientX,
                        y: e.clientY,
                        myReaction: m.reactions?.[user.uid],
                      });
                    }}
                    className={cx("flex items-end gap-2", mine ? "justify-end" : "justify-start")}
                  >
                    {!mine && (
                      <div className="w-7 shrink-0">
                        {first && <Avatar src={m.fromAvatar} name={m.fromName ?? "?"} seed={m.from} size={28} />}
                      </div>
                    )}

                    {m.deleted ? (
                      <div className="msg-bubble border border-dashed border-orange-200 bg-white/60 px-4 py-2.5 text-[13px] italic text-cocoa-soft">
                        Сообщение удалено
                      </div>
                    ) : (
                      <div
                        className={cx(
                          "msg-bubble relative max-w-[78%] sm:max-w-[62%]",
                          kind === "sticker"
                            ? ""
                            : kind === "image"
                              ? "p-1.5"
                              : kind === "voice"
                                ? "px-3.5 py-2"
                                : "px-3.5 py-2",
                          kind === "sticker"
                            ? "!bg-transparent !shadow-none"
                            : mine
                              ? "bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeSoft"
                              : "border border-orange-100 bg-white text-cocoa shadow-warm"
                        )}
                        style={{ wordBreak: "break-word" }}
                      >
                        {/* автор */}
                        {!mine && first && kind !== "sticker" && (
                          <div className="mb-0.5 text-[11.5px] font-bold text-orange-600">{m.fromName}</div>
                        )}
                        {!mine && first && kind === "sticker" && (
                          <div className="mb-0.5 text-[11.5px] font-bold text-orange-600">{m.fromName}</div>
                        )}

                        {m.replyTo && (
                          <div
                            className={cx(
                              "mb-1.5 truncate rounded-xl border-l-[3px] px-2.5 py-1.5 text-[11.5px]",
                              mine ? "border-white/70 bg-white/15 text-white/90" : "border-orange-400 bg-orange-50 text-cocoa-soft"
                            )}
                          >
                            <Reply size={10} className="mr-1 inline opacity-70" />
                            {m.replyTo.preview}
                          </div>
                        )}

                        {kind === "sticker" ? (
                          <button onClick={() => m.packId && setViewPack(m.packId)}>
                            <img src={m.image} alt={m.emoji} className="h-[120px] w-[120px] object-contain drop-shadow" />
                          </button>
                        ) : kind === "image" ? (
                          <ImageBubble src={m.image as string} />
                        ) : kind === "voice" ? (
                          <VoiceBubble src={m.audio as string} duration={m.duration ?? 0} mine={mine} seed={m.id} />
                        ) : (
                          <span className="whitespace-pre-wrap text-[14.5px] leading-relaxed">{m.text}</span>
                        )}

                        <span
                          className={cx(
                            "ml-2 inline-flex translate-y-[2px] items-center gap-1 text-[10px] font-semibold",
                            kind === "sticker" ? "text-cocoa-soft/70" : mine ? "text-white/75" : "text-cocoa-soft/60"
                          )}
                        >
                          {m.editedAt ? "изм. " : ""}
                          {fmtTime(m.createdAt)}
                        </span>

                        {m.reactions && Object.keys(m.reactions).length > 0 && (
                          <div className="mt-1 flex flex-wrap gap-1">
                            {Object.entries(
                              Object.values(m.reactions).reduce<Record<string, number>>((a, e) => {
                                a[e] = (a[e] ?? 0) + 1;
                                return a;
                              }, {})
                            ).map(([emoji, count]) => (
                              <button
                                key={emoji}
                                onClick={() => void react(m.id, emoji)}
                                className={cx(
                                  "rounded-full px-1.5 py-0.5 text-[11px] font-bold",
                                  mine ? "bg-white/25 text-white" : "bg-orange-100 text-cocoa"
                                )}
                              >
                                {emoji} {count > 1 ? count : ""}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* ввод */}
      <div className="border-t border-orange-100/80 bg-white/60 p-3.5 sm:px-6">
        {!amMember ? (
          <div className="rounded-2xl bg-orange-50 px-4 py-3.5 text-center text-[13px] font-semibold text-cocoa-soft">
            Ты больше не участник этой группы
          </div>
        ) : recording ? (
          <RecorderBar
            onSend={(d, s) => {
              setRecording(false);
              void sendGroupMessage(gid, user, { type: "voice", audio: d, duration: s });
            }}
            onCancel={() => setRecording(false)}
            onError={() => {
              setRecording(false);
              toast("Нет доступа к микрофону", "err");
            }}
          />
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void send();
            }}
            className="flex flex-col gap-2"
          >
            <AnimatePresence>
              {(replyTo || editing) && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                  <div className="flex items-center gap-2.5 rounded-2xl border border-orange-200 bg-orange-50/80 px-3.5 py-2">
                    {editing ? <Pencil size={14} className="text-orange-500" /> : <Reply size={14} className="text-orange-500" />}
                    <div className="min-w-0 flex-1">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-orange-600">
                        {editing ? "Редактирование" : "Ответ"}
                      </div>
                      <div className="truncate text-[12.5px] text-cocoa">{editing ? editing.text : replyTo?.preview}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setReplyTo(null);
                        if (editing) {
                          setEditing(null);
                          setText("");
                        }
                      }}
                      className="btn-press rounded-full p-1.5 text-cocoa-soft hover:text-orange-600"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="relative flex items-end gap-2">
              <input
                ref={imageRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void sendImage(f);
                  e.target.value = "";
                }}
              />
              <div className="flex flex-1 items-end gap-1 rounded-[22px] border-2 border-orange-200/60 bg-white focus-within:border-orange-400">
                <button
                  type="button"
                  onClick={() => imageRef.current?.click()}
                  className="btn-press mb-1.5 ml-1.5 flex h-9 w-9 items-center justify-center rounded-full text-cocoa-soft hover:bg-orange-50 hover:text-orange-600"
                >
                  <ImagePlus size={18} />
                </button>
                <textarea
                  ref={taRef}
                  rows={1}
                  value={text}
                  placeholder="Написать в группу…"
                  className="no-scrollbar max-h-[130px] w-full resize-none bg-transparent px-2 py-3 text-[14.5px] font-medium outline-none placeholder:text-cocoa-soft/55"
                  onChange={(e) => {
                    setText(e.target.value);
                    const el = e.target;
                    el.style.height = "auto";
                    el.style.height = Math.min(el.scrollHeight, 130) + "px";
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey && prefs.enterToSend) {
                      e.preventDefault();
                      void send();
                    }
                  }}
                />
              </div>

              <button
                type="button"
                onClick={() => setStickersOpen((v) => !v)}
                className={cx(
                  "btn-press flex h-[50px] w-[50px] shrink-0 items-center justify-center rounded-full border-2",
                  stickersOpen ? "border-orange-500 bg-orange-50 text-orange-600" : "border-orange-200/70 bg-white text-cocoa-soft"
                )}
              >
                <Smile size={19} />
              </button>

              <StickerPanel
                open={stickersOpen}
                onClose={() => setStickersOpen(false)}
                onPick={(s) => void sendSticker(s)}
                onOpenPack={(id) => {
                  setStickersOpen(false);
                  setViewPack(id);
                }}
              />

              {text.trim() ? (
                <motion.button
                  type="submit"
                  whileTap={{ scale: 0.88 }}
                  className="flex h-[50px] w-[50px] shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-orange-600 to-amber-500 text-white shadow-orangeGlow"
                >
                  <SendHorizontal size={19} className="-translate-x-[1px]" />
                </motion.button>
              ) : (
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.88 }}
                  onClick={() => setRecording(true)}
                  className="flex h-[50px] w-[50px] shrink-0 items-center justify-center rounded-full border-2 border-orange-300/70 bg-white text-orange-500 shadow-warm"
                >
                  <Mic size={19} />
                </motion.button>
              )}
            </div>
          </form>
        )}
      </div>

      <MessageMenu
        target={menu}
        onClose={() => setMenu(null)}
        onAction={(a, id) => void handleAction(a, id)}
        onReact={(id, e) => void react(id, e)}
      />
      {viewPack && <PackViewer packId={viewPack} onClose={() => setViewPack("")} onPick={(s) => void sendSticker(s)} />}
      <GroupInfoModal
        open={infoOpen}
        onClose={() => setInfoOpen(false)}
        group={group}
        contacts={contacts}
        onLeave={() => navigate("/")}
      />
      {canManage(myRole) && <span className="hidden" aria-hidden />}
      {callState.active && <PhoneCall className="hidden" aria-hidden />}
    </div>
  );
}
