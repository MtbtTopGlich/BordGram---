import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useLocation, useNavigate } from "react-router-dom";
import {
  Ban,
  Bell,
  Check,
  Cog,
  Clock3,
  LogOut,
  MessageCircle,
  Plus,
  Search,
  SendHorizontal,
  Star,
  UserRound,
  Users,
  WifiOff,
  X,
} from "lucide-react";
import { Avatar, Logo, ModalShell, SoundToggle, Spinner, WarmBackdrop } from "../components/bits";
import SettingsModal from "../components/SettingsModal";
import { CallProvider } from "../components/CallUI";
import { CreateGroupModal } from "../components/GroupModals";
import { listenMyGroups, type Group } from "../lib/groups";
import { AFTER_LOGIN_KEY } from "./JoinGroup";
import { useAuth, useToast } from "../state";
import {
  acceptContactRequest,
  blockUser,
  cancelContactRequest,
  getUserByUsername,
  listenContacts,
  listenOutgoing,
  listenRequests,
  setContactFavorite,
  type ContactDoc,
  type OutgoingDoc,
  type Profile,
  type RequestDoc,
} from "../db";
import { cx, fmtTime, normalizeUsername, truncate } from "../lib/utils";
import { useLiveContacts, useNetworkStatus, usePresenceHeartbeat } from "../lib/live";
import { sfx } from "../lib/sounds";

/* ================= data context ================= */

type DataCtx = {
  contacts: ContactDoc[];
  requests: RequestDoc[];
  contactOf: (uid: string) => ContactDoc | undefined;
};

const DataContext = createContext<DataCtx>({ contacts: [], requests: [], contactOf: () => undefined });

export function useData() {
  return useContext(DataContext);
}

/* ================= shell ================= */

const COLLAPSED = 96;
const EXPANDED = 322;

export default function AppShell({ children }: { children: ReactNode }) {
  const { user, signOut } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const inChat = location.pathname.startsWith("/@");

  const [hover, setHover] = useState(false);
  const [searchFocus, setSearchFocus] = useState(false);
  const [isMobile] = useState(() => typeof window !== "undefined" && window.innerWidth < 768);
  const open = hover || searchFocus || isMobile;

  const [contacts, setContacts] = useState<ContactDoc[]>([]);
  const [requests, setRequests] = useState<RequestDoc[]>([]);
  const [outgoing, setOutgoing] = useState<OutgoingDoc[]>([]);
  const [requestsOpen, setRequestsOpen] = useState(false);
  const [outgoingOpen, setOutgoingOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const prevReqCount = useRef(0);
  const firstReqLoad = useRef(true);

  useEffect(() => {
    if (!user) return;
    const u1 = listenContacts(user.uid, setContacts);
    const u2 = listenRequests(user.uid, setRequests);
    const u3 = listenOutgoing(user.uid, setOutgoing);
    return () => {
      u1();
      u2();
      u3();
    };
  }, [user]);

  // звук + тост на новую заявку
  useEffect(() => {
    if (firstReqLoad.current) {
      firstReqLoad.current = false;
      prevReqCount.current = requests.length;
      return;
    }
    if (requests.length > prevReqCount.current) {
      sfx.notify();
      toast("Новая заявка в контакты!", "ok");
    }
    prevReqCount.current = requests.length;
  }, [requests, toast]);

  const contactOf = useMemo(() => {
    const map = new Map(contacts.map((c) => [c.uid, c]));
    return (uid: string) => map.get(uid);
  }, [contacts]);

  // живые данные: онлайн, непрочитанные, свежие профили
  usePresenceHeartbeat(user?.uid);
  const netOnline = useNetworkStatus();
  const live = useLiveContacts(user?.uid, contacts);

  // контакты с подтянутыми «на лету» ником и аватаркой
  const liveContacts = useMemo(
    () => contacts.map((c) => ({ ...c, ...(live.fresh[c.uid] ?? {}) })),
    [contacts, live.fresh]
  );

  const favorites = useMemo(() => liveContacts.filter((c) => c.fav), [liveContacts]);
  const others = useMemo(() => liveContacts.filter((c) => !c.fav), [liveContacts]);

  // мои группы
  const [groups, setGroups] = useState<Group[]>([]);
  const [createGroupOpen, setCreateGroupOpen] = useState(false);

  useEffect(() => {
    if (!user) return;
    return listenMyGroups(user.uid, setGroups);
  }, [user]);

  // возврат по приглашению после входа
  useEffect(() => {
    if (!user) return;
    const after = localStorage.getItem(AFTER_LOGIN_KEY);
    if (after) {
      localStorage.removeItem(AFTER_LOGIN_KEY);
      navigate(after, { replace: true });
    }
  }, [user, navigate]);

  const toggleFav = async (c: ContactDoc) => {
    if (!user) return;
    sfx.tick();
    try {
      await setContactFavorite(user.uid, c.uid, !c.fav);
      toast(c.fav ? `@${c.usernameDisplay} убран из избранных` : `@${c.usernameDisplay} в избранных`, "ok");
    } catch {
      toast("Не удалось обновить избранное", "err");
    }
  };

  if (!user) return null;

  const doLogout = () => {
    sfx.close();
    signOut();
    navigate("/login", { replace: true });
  };

  return (
    <DataContext.Provider value={{ contacts, requests, contactOf }}>
      <CallProvider me={user} groups={groups}>
      <div className="relative flex h-dvh overflow-hidden">
        <WarmBackdrop />

        {/* плашка офлайна — появляется и исчезает сама */}
        <AnimatePresence>
          {!netOnline && (
            <motion.div
              initial={{ y: -40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -40, opacity: 0 }}
              className="fixed left-1/2 top-3 z-[95] flex -translate-x-1/2 items-center gap-2 rounded-full bg-cocoa/90 px-4 py-2 text-xs font-bold text-white shadow-2xl backdrop-blur"
            >
              <WifiOff size={13} /> Нет сети — сообщения уйдут автоматически
            </motion.div>
          )}
        </AnimatePresence>

        {/* ============ сайдбар ============ */}
        <motion.aside
          initial={{ x: -60, opacity: 0, width: COLLAPSED }}
          animate={{ x: 0, opacity: 1, width: open ? EXPANDED : COLLAPSED }}
          transition={{ type: "spring", stiffness: 290, damping: 32 }}
          onMouseEnter={() => {
            if (!open) sfx.open();
            setHover(true);
          }}
          onMouseLeave={() => setHover(false)}
          className={cx(
            "z-40 m-3 mr-0 flex shrink-0 flex-col overflow-hidden rounded-[30px] border border-orange-100/90 bg-white/72 shadow-2xl backdrop-blur-xl",
            inChat && "max-md:hidden"
          )}
        >
          {/* лого */}
          <div className={cx("flex items-center", open ? "justify-between px-5 pt-5" : "justify-center pt-5")}>
            {open ? <Logo size={34} /> : <Logo size={38} withWord={false} />}
            {open && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <SoundToggle />
              </motion.div>
            )}
          </div>

          {/* моя мини-карточка */}
          <button
            onClick={() => {
              sfx.click();
              setSettingsOpen(true);
            }}
            title="Открыть настройки"
            className={cx(
              "btn-press group relative mx-auto mt-4 flex items-center rounded-3xl transition-colors hover:bg-orange-50",
              open ? "w-[calc(100%-24px)] gap-3 p-3" : "w-[64px] justify-center p-2"
            )}
          >
            <Avatar src={user.avatar} name={user.nickname} seed={user.username} size={open ? 48 : 46} />
            {open && (
              <motion.div initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.05 }} className="min-w-0 flex-1 text-left">
                <div className="truncate text-[15px] font-bold leading-tight">{user.nickname}</div>
                <div className="truncate text-[12.5px] font-semibold text-orange-600">@{user.usernameDisplay}</div>
              </motion.div>
            )}
            {open && (
              <span className="rounded-full bg-orange-100/80 p-1.5 text-cocoa-soft opacity-0 transition-opacity group-hover:opacity-100">
                <Cog size={13} />
              </span>
            )}
            <span className="absolute bottom-1 right-1 h-3 w-3 rounded-full border-2 border-white bg-emerald-400" style={{ right: open ? 14 : 8 }} />
          </button>

          {/* поиск */}
          <div className={cx("mt-4", open ? "px-4" : "flex justify-center px-2")}>
            {open ? (
              <div className="relative">
                <Search size={15} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                <SearchBox autoFocus={searchFocus} onFocusChange={setSearchFocus} />
              </div>
            ) : (
              <button
                onClick={() => {
                  sfx.click();
                  setSearchFocus(true);
                }}
                className="btn-press flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-100/80 text-orange-600 transition-colors hover:bg-orange-200/80"
                title="Поиск по @username"
              >
                <Search size={18} />
              </button>
            )}
          </div>

          {/* заявки */}
          <div className={cx("mt-3.5 grid gap-2", open ? "grid-cols-2 px-4" : "grid-cols-1 justify-items-center px-2")}>
            <RequestsButton
              open={open}
              icon={<Bell size={16} className="shrink-0 text-orange-600" />}
              label="Входящие"
              title="Заявки в контакты"
              count={requests.length}
              pulse
              onClick={() => {
                sfx.click();
                setRequestsOpen(true);
              }}
            />
            <RequestsButton
              open={open}
              icon={<SendHorizontal size={15} className="shrink-0 text-orange-600" />}
              label="Ваши заявки"
              title="Ваши отправленные заявки"
              count={outgoing.length}
              onClick={() => {
                sfx.click();
                setOutgoingOpen(true);
              }}
            />
          </div>

          {/* контакты */}
          <div className="warm-scroll mt-3 flex-1 overflow-y-auto overflow-x-hidden pb-3" onWheel={(e) => e.stopPropagation()}>
            {contacts.length === 0 && open && (
              <div className="mx-5 mt-4 rounded-2xl border border-dashed border-orange-200 bg-white/50 p-4 text-center">
                <UserRound size={22} className="mx-auto mb-2 text-orange-300" />
                <p className="text-[12.5px] leading-relaxed text-cocoa-soft">
                  Пока пусто. Найди друга по <span className="font-semibold text-orange-600">@username</span> выше
                </p>
              </div>
            )}

            {/* группы */}
            <div className={cx("mb-1 mt-3 flex items-center gap-1.5", open ? "px-6" : "justify-center")}>
              {open ? (
                <>
                  <Users size={11} className="text-orange-500" />
                  <span className="flex-1 text-[10.5px] font-bold uppercase tracking-[0.2em] text-cocoa-soft/70">
                    Группы
                  </span>
                  <button
                    onClick={() => {
                      sfx.click();
                      setCreateGroupOpen(true);
                    }}
                    title="Создать группу"
                    className="btn-press rounded-full bg-orange-100 p-1 text-orange-600 hover:bg-orange-200"
                  >
                    <Plus size={12} />
                  </button>
                </>
              ) : (
                <button
                  onClick={() => {
                    sfx.click();
                    setCreateGroupOpen(true);
                  }}
                  title="Создать группу"
                  className="btn-press flex h-9 w-9 items-center justify-center rounded-xl bg-orange-100/80 text-orange-600"
                >
                  <Users size={15} />
                </button>
              )}
            </div>

            {groups.map((g) => {
              const active = location.pathname === `/g/${g.id}`;
              return (
                <button
                  key={g.id}
                  onClick={() => {
                    sfx.click();
                    navigate(`/g/${g.id}`);
                  }}
                  title={g.title}
                  className={cx(
                    "relative flex w-full items-center transition-colors",
                    open ? "gap-3 px-4 py-2.5 hover:bg-orange-50/90" : "justify-center px-2 py-1.5",
                    active && "bg-orange-50"
                  )}
                >
                  <Avatar src={g.avatar} name={g.title} seed={g.invite} size={open ? 44 : 46} active={active} />
                  {open && (
                    <div className="min-w-0 flex-1 text-left">
                      <div className="truncate text-[14px] font-bold text-cocoa">{g.title}</div>
                      <div className="truncate text-[11.5px] text-cocoa-soft/85">
                        {g.lastFromName ? `${g.lastFromName}: ` : ""}
                        {truncate(g.lastSnippet ?? "Группа создана", 26)}
                      </div>
                    </div>
                  )}
                </button>
              );
            })}

            {favorites.length > 0 && (
              <>
                <SectionLabel open={open} icon={<Star size={11} className="fill-orange-400 text-orange-400" />} text="Избранные" />
                {favorites.map((c, i) => (
                  <ContactRow
                    key={c.uid}
                    c={c}
                    open={open}
                    index={i}
                    online={live.isOnline(c.uid)}
                    unread={!!live.unread[c.uid]}
                    active={location.pathname === `/@${c.usernameDisplay.toLowerCase()}`}
                    onClick={() => navigate(`/@${c.usernameDisplay.toLowerCase()}`)}
                    onToggleFav={() => void toggleFav(c)}
                  />
                ))}
              </>
            )}

            {others.length > 0 && (
              <>
                <SectionLabel open={open} text="Контакты" />
                {others.map((c, i) => (
                  <ContactRow
                    key={c.uid}
                    c={c}
                    open={open}
                    index={i}
                    online={live.isOnline(c.uid)}
                    unread={!!live.unread[c.uid]}
                    active={location.pathname === `/@${c.usernameDisplay.toLowerCase()}`}
                    onClick={() => navigate(`/@${c.usernameDisplay.toLowerCase()}`)}
                    onToggleFav={() => void toggleFav(c)}
                  />
                ))}
              </>
            )}
          </div>

          {/* низ */}
          <div className={cx("flex border-t border-orange-100/80 p-3", open ? "items-center justify-between px-5" : "flex-col items-center gap-2")}>
            {!open && <SoundToggle compact />}
            {open && <span className="text-[10.5px] font-semibold uppercase tracking-widest text-cocoa-soft/60">bordgram 1.0</span>}
            <div className={cx("flex items-center", open ? "gap-1.5" : "flex-col gap-2")}>
              <button
                onClick={() => {
                  sfx.click();
                  setSettingsOpen(true);
                }}
                className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-orange-100/70 text-cocoa-soft transition-colors hover:bg-orange-200/70 hover:text-orange-600"
                title="Настройки"
              >
                <Cog size={16} />
              </button>
              <button
                onClick={doLogout}
                className="btn-press flex h-10 w-10 items-center justify-center rounded-full bg-orange-100/70 text-cocoa-soft transition-colors hover:bg-red-50 hover:text-red-500"
                title="Выйти"
              >
                <LogOut size={16} />
              </button>
            </div>
          </div>
        </motion.aside>

        {/* ============ контент ============ */}
        <main
          className={cx(
            "relative m-3 ml-0 flex min-w-0 flex-1 flex-col overflow-hidden rounded-[30px] border border-orange-100/90 bg-white/55 shadow-2xl backdrop-blur-xl max-md:m-3 max-md:ml-3",
            !inChat && "max-md:hidden"
          )}
        >
          {children}
        </main>
      </div>

      <RequestsModal
        open={requestsOpen}
        onClose={() => setRequestsOpen(false)}
        requests={requests}
        myUid={user.uid}
        onChat={(p) => navigate(`/@${p}`)}
      />
      <OutgoingModal
        open={outgoingOpen}
        onClose={() => setOutgoingOpen(false)}
        items={outgoing}
        myUid={user.uid}
        onChat={(p) => navigate(`/@${p}`)}
      />
      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} onLogout={doLogout} />
      <CreateGroupModal
        open={createGroupOpen}
        onClose={() => setCreateGroupOpen(false)}
        contacts={contacts}
        onCreated={(gid) => navigate(`/g/${gid}`)}
      />
      </CallProvider>
    </DataContext.Provider>
  );
}

/* ================= кнопка заявок ================= */

function RequestsButton({
  open,
  icon,
  label,
  title,
  count,
  pulse,
  onClick,
}: {
  open: boolean;
  icon: ReactNode;
  label: string;
  title: string;
  count: number;
  pulse?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={cx(
        "btn-press relative flex min-w-0 items-center rounded-2xl border border-orange-200/70 bg-white/70 font-semibold transition-colors hover:border-orange-300 hover:bg-orange-50",
        open ? "w-full gap-1.5 px-2.5 py-2.5" : "h-12 w-12 justify-center text-orange-600"
      )}
    >
      {icon}
      {open && (
        <>
          <span className="min-w-0 flex-1 truncate text-left text-[12px] leading-tight text-cocoa">{label}</span>
          {count > 0 && (
            <span
              className={cx(
                "flex h-5 min-w-[20px] shrink-0 items-center justify-center rounded-full px-1 text-[10.5px] font-bold",
                pulse ? "badge-pulse bg-gradient-to-r from-orange-600 to-amber-500 text-white" : "bg-orange-100 text-orange-700"
              )}
            >
              {count}
            </span>
          )}
        </>
      )}
      {!open && count > 0 && (
        <span
          className={cx(
            "absolute right-0.5 top-0.5 flex h-4 min-w-[16px] items-center justify-center rounded-full px-1 text-[9.5px] font-bold",
            pulse ? "badge-pulse bg-gradient-to-r from-orange-600 to-amber-500 text-white" : "bg-orange-200 text-orange-700"
          )}
        >
          {count}
        </span>
      )}
    </button>
  );
}

/* ================= модалка «Ваши заявки» ================= */

function OutgoingModal({
  open,
  onClose,
  items,
  myUid,
  onChat,
}: {
  open: boolean;
  onClose: () => void;
  items: OutgoingDoc[];
  myUid: string;
  onChat: (username: string) => void;
}) {
  const { toast } = useToast();
  const [busyId, setBusyId] = useState<string | null>(null);

  const openChat = (o: OutgoingDoc) => {
    sfx.click();
    onClose();
    onChat(o.usernameDisplay.toLowerCase());
  };

  const cancel = async (o: OutgoingDoc) => {
    setBusyId(o.toUid);
    try {
      await cancelContactRequest(myUid, o.toUid);
      toast(`Заявка к @${o.usernameDisplay} отозвана`, "info");
    } catch {
      toast("Не удалось отозвать заявку", "err");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <ModalShell open={open} onClose={onClose} maxW="max-w-lg">
      <div className="mb-5 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-amber-400 text-white shadow-orangeSoft">
          <SendHorizontal size={18} />
        </span>
        <div>
          <h3 className="font-display text-lg font-bold">Ваши заявки</h3>
          <p className="text-xs font-medium text-cocoa-soft">
            {items.length > 0 ? `Ожидают ответа: ${items.length}` : "Ты пока никому не отправлял заявок"}
          </p>
        </div>
      </div>

      <div className="warm-scroll max-h-[55vh] space-y-2.5 overflow-y-auto pr-1">
        {items.length === 0 && (
          <div className="rounded-2xl border border-dashed border-orange-200 bg-white/60 p-8 text-center text-sm leading-relaxed text-cocoa-soft">
            Найди человека по <span className="font-semibold text-orange-600">@username</span> и отправь заявку — она
            появится здесь
          </div>
        )}
        <AnimatePresence>
          {items.map((o) => (
            <motion.div
              key={o.toUid}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="rounded-2xl border border-orange-100 bg-white p-3 shadow-warm"
            >
              <div className="flex items-center gap-3">
                <button onClick={() => openChat(o)} className="btn-press shrink-0" title="Открыть чат">
                  <Avatar src={o.avatar} name={o.nickname} seed={o.usernameDisplay} size={48} />
                </button>
                <button onClick={() => openChat(o)} className="min-w-0 flex-1 text-left">
                  <div className="truncate text-sm font-bold transition-colors hover:text-orange-600">{o.nickname}</div>
                  <div className="truncate text-xs font-semibold text-orange-600">@{o.usernameDisplay}</div>
                </button>
                <span className="flex shrink-0 items-center gap-1 rounded-full bg-orange-50 px-2.5 py-1 text-[10.5px] font-bold text-orange-600">
                  <Clock3 size={10} /> ждём
                </span>
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-2 pl-[60px]">
                <button
                  onClick={() => openChat(o)}
                  className="btn-press flex items-center gap-1.5 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-4 py-2 text-xs font-bold text-white shadow-orangeSoft transition hover:brightness-105"
                >
                  <MessageCircle size={13} /> Открыть чат
                </button>
                <button
                  disabled={busyId === o.toUid}
                  onClick={() => void cancel(o)}
                  className="btn-press flex items-center gap-1.5 rounded-full bg-orange-100/80 px-4 py-2 text-xs font-bold text-cocoa-soft transition hover:bg-red-50 hover:text-red-500 disabled:opacity-50"
                >
                  {busyId === o.toUid ? <Spinner size={12} /> : <X size={13} />} Отозвать
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ModalShell>
  );
}

/* ================= заголовок секции ================= */

function SectionLabel({ open, text, icon }: { open: boolean; text: string; icon?: ReactNode }) {
  if (!open) return <div className="mx-auto my-2 h-px w-8 bg-orange-200" />;
  return (
    <div className="mb-1 mt-3 flex items-center gap-1.5 px-6">
      {icon}
      <span className="text-[10.5px] font-bold uppercase tracking-[0.2em] text-cocoa-soft/70">{text}</span>
    </div>
  );
}

/* ================= строка контакта ================= */

function ContactRow({
  c,
  open,
  index,
  active,
  online,
  unread,
  onClick,
  onToggleFav,
}: {
  c: ContactDoc;
  open: boolean;
  index: number;
  active: boolean;
  online?: boolean;
  unread?: boolean;
  onClick: () => void;
  onToggleFav: () => void;
}) {
  const time = fmtTime(c.lastAt ?? c.addedAt);
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.03 * index + 0.05 }}
      onClick={() => {
        sfx.click();
        onClick();
      }}
      role="button"
      title={c.nickname}
      className={cx(
        "group relative flex w-full cursor-pointer items-center transition-colors",
        open ? "gap-3 px-4 py-2.5 hover:bg-orange-50/90" : "justify-center px-2 py-1.5",
        active && open && "bg-orange-50",
        active && !open && "bg-orange-50/70"
      )}
    >
      {active && open && (
        <motion.span layoutId="contact-active" className="absolute left-1.5 top-1/2 h-8 w-1 -translate-y-1/2 rounded-full bg-gradient-to-b from-orange-500 to-amber-400" />
      )}
      <div className="relative shrink-0">
        <Avatar src={c.avatar} name={c.nickname} seed={c.usernameDisplay} size={open ? 46 : 48} active={active} />
        {online && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute bottom-0 right-0 h-3.5 w-3.5 rounded-full border-[2.5px] border-white bg-emerald-400"
            title="В сети"
          />
        )}
        {!open && unread && (
          <span className="absolute -left-0.5 -top-0.5 h-3 w-3 rounded-full border-2 border-white bg-orange-500" />
        )}
      </div>
      {open && (
        <motion.div initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.05 }} className="min-w-0 flex-1 text-left">
          <div className={cx("truncate text-[14.5px] leading-tight text-cocoa", unread ? "font-extrabold" : "font-bold")}>
            {c.nickname}
          </div>
          <div className="mt-0.5 truncate text-[12px] font-semibold text-orange-600/90">@{c.usernameDisplay}</div>
          {c.lastSnippet && (
            <div className={cx("mt-0.5 truncate text-[11.5px]", unread ? "font-semibold text-cocoa" : "text-cocoa-soft/85")}>
              {truncate(c.lastSnippet, 34)}
            </div>
          )}
        </motion.div>
      )}
      {open && (
        <div className="flex shrink-0 flex-col items-end gap-1 self-start">
          {unread ? (
            <span className="badge-pulse h-2.5 w-2.5 rounded-full bg-orange-500" title="Новое сообщение" />
          ) : (
            time && <span className="text-[10.5px] font-semibold text-cocoa-soft/60">{time}</span>
          )}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFav();
            }}
            title={c.fav ? "Убрать из избранных" : "В избранные"}
            className={cx(
              "btn-press rounded-full p-1 transition-all",
              c.fav ? "text-orange-500 opacity-100" : "text-cocoa-soft/40 opacity-0 hover:text-orange-500 group-hover:opacity-100"
            )}
          >
            <Star size={13} className={c.fav ? "fill-orange-400 text-orange-400" : ""} />
          </button>
        </div>
      )}
      {!open && c.fav && (
        <span className="absolute right-2 top-1 text-orange-500">
          <Star size={10} className="fill-orange-400 text-orange-400" />
        </span>
      )}
    </motion.div>
  );
}

/* ================= поиск ================= */

type SearchState =
  | { kind: "idle" }
  | { kind: "loading" }
  | { kind: "none" }
  | { kind: "found"; profile: Profile };

export function SearchBox({
  onPick,
  autoFocus = false,
  onFocusChange,
}: {
  onPick?: () => void;
  autoFocus?: boolean;
  onFocusChange?: (v: boolean) => void;
}) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [value, setValue] = useState("");
  const [state, setState] = useState<SearchState>({ kind: "idle" });
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (timer.current) window.clearTimeout(timer.current);
    const q = normalizeUsername(value);
    if (q.length < 3) {
      setState({ kind: "idle" });
      return;
    }
    setState({ kind: "loading" });
    timer.current = window.setTimeout(async () => {
      try {
        const p = await getUserByUsername(q);
        setState(p ? { kind: "found", profile: p } : { kind: "none" });
      } catch {
        setState({ kind: "none" });
      }
    }, 380);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [value]);

  return (
    <div className="relative">
      <input
        className="field !rounded-2xl !py-3 pl-10 pr-3 text-sm"
        placeholder="Точный @username"
        value={value}
        autoFocus={autoFocus}
        onChange={(e) => setValue(e.target.value)}
        onFocus={() => {
          sfx.tick();
          onFocusChange?.(true);
        }}
        onBlur={() => {
          if (!value) onFocusChange?.(false);
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter" && state.kind === "found") {
            sfx.click();
            navigate(`/@${state.profile.usernameDisplay.toLowerCase()}`);
            setValue("");
            onPick?.();
          }
        }}
      />
      <AnimatePresence>
        {state.kind !== "idle" && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 380, damping: 28 }}
            className="absolute inset-x-0 top-[calc(100%+8px)] z-50 overflow-hidden rounded-2xl border border-orange-100 bg-white shadow-2xl"
          >
            {state.kind === "loading" && (
              <div className="flex items-center gap-3 px-4 py-3.5 text-sm font-semibold text-cocoa-soft">
                <Spinner size={16} /> ищем…
              </div>
            )}
            {state.kind === "none" && (
              <div className="px-4 py-3.5 text-sm font-medium text-cocoa-soft">
                Никого не нашли по <span className="font-semibold text-cocoa">@{normalizeUsername(value)}</span>
              </div>
            )}
            {state.kind === "found" && (
              <button
                onClick={() => {
                  sfx.click();
                  navigate(`/@${state.profile.usernameDisplay.toLowerCase()}`);
                  setValue("");
                  onPick?.();
                }}
                className="flex w-full items-center gap-3 px-3.5 py-3 text-left transition-colors hover:bg-orange-50"
              >
                <Avatar src={state.profile.avatar} name={state.profile.nickname} seed={state.profile.username} size={42} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-bold">
                    {state.profile.nickname}
                    {state.profile.uid === user?.uid && <span className="ml-1.5 text-[10px] font-bold text-cocoa-soft">— это ты</span>}
                  </div>
                  <div className="truncate text-xs font-semibold text-orange-600">@{state.profile.usernameDisplay}</div>
                </div>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-orange-100 text-orange-600">
                  <MessageCircle size={15} />
                </span>
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ================= модалка заявок ================= */

function RequestsModal({
  open,
  onClose,
  requests,
  myUid,
  onChat,
}: {
  open: boolean;
  onClose: () => void;
  requests: RequestDoc[];
  myUid: string;
  onChat: (username: string) => void;
}) {
  const { toast } = useToast();
  const [busyId, setBusyId] = useState<string | null>(null);

  const accept = async (r: RequestDoc) => {
    setBusyId(r.fromUid);
    try {
      await acceptContactRequest(myUid, r);
      toast(`@${r.usernameDisplay} теперь в твоих контактах`, "ok");
    } catch {
      toast("Не получилось принять заявку", "err");
    } finally {
      setBusyId(null);
    }
  };

  const block = async (r: RequestDoc) => {
    setBusyId(r.fromUid);
    try {
      await blockUser(myUid, r.fromUid);
      toast(`@${r.usernameDisplay} заблокирован`, "info");
    } catch {
      toast("Ошибка блокировки", "err");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <ModalShell open={open} onClose={onClose} maxW="max-w-lg">
      <div className="mb-5 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-amber-400 text-white shadow-orangeSoft">
          <Bell size={19} />
        </span>
        <div>
          <h3 className="font-display text-lg font-bold">Заявки в контакты</h3>
          <p className="text-xs font-medium text-cocoa-soft">{requests.length > 0 ? `Ждут решения: ${requests.length}` : "Пока никто не написал"}</p>
        </div>
      </div>

      <div className="warm-scroll max-h-[55vh] space-y-2.5 overflow-y-auto pr-1">
        {requests.length === 0 && (
          <div className="rounded-2xl border border-dashed border-orange-200 bg-white/60 p-8 text-center text-sm text-cocoa-soft">
            Когда кто-то отправит тебе заявку — она появится здесь
          </div>
        )}
        <AnimatePresence>
          {requests.map((r) => (
            <motion.div
              key={r.fromUid}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="rounded-2xl border border-orange-100 bg-white p-3 shadow-warm"
            >
              <div className="flex items-center gap-3">
                <Avatar src={r.avatar} name={r.nickname} seed={r.usernameDisplay} size={48} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-bold">{r.nickname}</div>
                  <button onClick={() => { onClose(); onChat(r.usernameDisplay.toLowerCase()); }} className="truncate text-xs font-semibold text-orange-600 hover:underline">
                    @{r.usernameDisplay}
                  </button>
                </div>
                {busyId === r.fromUid && <Spinner size={18} />}
              </div>
              {/* две кнопки — слева внутри карточки */}
              <div className="mt-3 flex items-center gap-2 pl-[60px]">
                <button
                  disabled={busyId === r.fromUid}
                  onClick={() => void accept(r)}
                  className="btn-press flex items-center gap-1.5 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-4 py-2 text-xs font-bold text-white shadow-orangeSoft transition hover:brightness-105 disabled:opacity-50"
                >
                  <Check size={13} /> Принять в контакты
                </button>
                <button
                  disabled={busyId === r.fromUid}
                  onClick={() => void block(r)}
                  className="btn-press flex items-center gap-1.5 rounded-full bg-red-50 px-4 py-2 text-xs font-bold text-red-500 transition hover:bg-red-100 disabled:opacity-50"
                >
                  <Ban size={13} /> Заблокировать
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ModalShell>
  );
}


