import { useEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  AtSign,
  BadgeCheck,
  Check,
  Eye,
  EyeOff,
  ImagePlus,
  KeyRound,
  Lock,
  Mail,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Trash2,
  User,
} from "lucide-react";
import { Avatar, CodeInput, Logo, PrimaryButton, Spinner, WarmBackdrop } from "../components/bits";
import { useAuth, useToast } from "../state";
import {
  checkLogin,
  createUser,
  emailExists,
  resetPasswordByEmail,
  usernameExists,
  type Profile,
} from "../db";
import { generateCode, sendVerificationCode, EMAIL_CONFIG } from "../lib/mail";
import { hashPassword, isValidEmail, isValidUsername, normalizeUsername, fileToAvatar, cx } from "../lib/utils";
import { sfx } from "../lib/sounds";

type Mode = "login" | "register";

/* ---------- общие мелочи ---------- */

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <label className="block text-left">
      <span className="mb-1.5 flex items-center justify-between text-[13px] font-semibold text-cocoa-soft">
        {label}
        {error && <span className="text-[12px] font-semibold text-red-500">{error}</span>}
      </span>
      {children}
    </label>
  );
}

function ErrorText({ text }: { text?: string }) {
  if (!text) return null;
  return <div className="mt-1.5 flex items-center gap-1 text-[12.5px] font-medium text-red-500">{text}</div>;
}

function DevMailCard({ code, email }: { code: string; email: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mt-4 overflow-hidden rounded-2xl border border-orange-200 bg-white/80 text-left shadow-warm"
    >
      <div className="flex items-center gap-2 border-b border-orange-100 bg-gradient-to-r from-orange-500 to-amber-400 px-4 py-2.5 text-white">
        <Mail size={14} />
        <span className="text-xs font-bold tracking-wide">BordGram Mail · dev-режим</span>
      </div>
      <div className="px-4 py-3">
        <p className="text-xs leading-relaxed text-cocoa-soft">
          Настрой <span className="font-semibold text-cocoa">template_id</span> и{" "}
          <span className="font-semibold text-cocoa">public_key</span> EmailJS — и письмо улетит на{" "}
          <span className="font-semibold text-cocoa">{email}</span>. А пока код тут:
        </p>
        <div className="mt-2 text-center font-display text-3xl font-bold tracking-[0.3em] text-orange-600">
          {code}
        </div>
      </div>
    </motion.div>
  );
}

/* ================= экран ================= */

export default function AuthScreen() {
  const { user, ready } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("login");

  useEffect(() => {
    if (ready && user) navigate("/", { replace: true });
  }, [ready, user, navigate]);

  return (
    <div className="relative flex min-h-full items-stretch">
      <WarmBackdrop />
      {/* левая бренд-панель */}
      <div className="relative hidden w-[46%] flex-col justify-between overflow-hidden p-12 lg:flex">
        <Logo size={46} />
        <div className="relative z-10 max-w-xl">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-4 inline-flex items-center gap-2 rounded-full border border-orange-300/60 bg-white/70 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.18em] text-orange-600 backdrop-blur"
          >
            <Sparkles size={13} /> тёплые переписки
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.18 }}
            className="font-display text-[clamp(2.2rem,3.6vw,3.4rem)] font-bold leading-[1.12] tracking-tight text-cocoa"
          >
            Bord<span className="bg-gradient-to-r from-orange-600 to-amber-500 bg-clip-text text-transparent">Gram</span>
            <span className="mt-3 block font-sans text-[clamp(1.25rem,2vw,1.7rem)] font-semibold tracking-normal text-cocoa-soft">
              Общайся по-настоящему
            </span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.26 }}
            className="mt-5 max-w-md text-[15px] leading-relaxed text-cocoa-soft"
          >
            Тёплый веб-мессенджер с личными чатами, голосовыми сообщениями, видеозвонками, демонстрацией
            экрана и собственными стикер-паками.
          </motion.p>
        </div>
        <motion.div
          initial={{ opacity: 0, scale: 0.94, rotate: -2 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ delay: 0.3, type: "spring", stiffness: 80, damping: 16 }}
          className="relative z-0 mt-6"
        >
          <div className="breathe overflow-hidden rounded-[36px] border-4 border-white/70 shadow-2xl">
            <img src="/images/auth-art.jpg" alt="" className="h-64 w-full object-cover" draggable={false} />
          </div>
        </motion.div>
      </div>

      {/* правая форма */}
      <div className="flex flex-1 items-center justify-center p-5 sm:p-10">
        <motion.div
          initial={{ opacity: 0, y: 26 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 120, damping: 20 }}
          className="w-full max-w-[460px] rounded-[32px] border border-orange-100/80 bg-white/65 p-7 shadow-2xl backdrop-blur-xl sm:p-9"
        >
          <div className="mb-6 flex justify-center lg:hidden">
            <div className="text-center">
              <Logo size={42} />
              <p className="mt-2 text-xs font-medium text-cocoa-soft">Веб-мессенджер для тёплого общения</p>
            </div>
          </div>

          {/* табы */}
          <div className="relative mb-7 grid grid-cols-2 rounded-full bg-orange-100/70 p-1.5">
            {(["login", "register"] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => {
                  sfx.click();
                  setMode(m);
                }}
                className="relative z-10 rounded-full py-2.5 text-sm font-bold transition-colors"
              >
                {mode === m && (
                  <motion.span
                    layoutId="auth-tab"
                    className="absolute inset-0 -z-10 rounded-full bg-white shadow-warm"
                    transition={{ type: "spring", stiffness: 400, damping: 32 }}
                  />
                )}
                <span className={mode === m ? "text-orange-600" : "text-cocoa-soft"}>
                  {m === "login" ? "Вход" : "Регистрация"}
                </span>
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {mode === "login" ? (
              <motion.div key="login" initial={{ opacity: 0, x: -18 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 18 }} transition={{ duration: 0.22 }}>
                <LoginForm />
              </motion.div>
            ) : (
              <motion.div key="reg" initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -18 }} transition={{ duration: 0.22 }}>
                <RegisterWizard />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
}

/* ================= вход ================= */

function LoginForm() {
  const { signIn } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [sentCode, setSentCode] = useState("");
  const [devCode, setDevCode] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [phase, setPhase] = useState<"email" | "code">("email");
  const [err, setErr] = useState("");
  const [shakeKey, setShakeKey] = useState(0);
  const [resendIn, setResendIn] = useState(0);
  const [forgot, setForgot] = useState(false);
  const [newPw, setNewPw] = useState("");
  const [newPw2, setNewPw2] = useState("");

  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);

  const fail = (msg: string) => {
    setErr(msg);
    setShakeKey((k) => k + 1);
    sfx.error();
  };

  const sendCode = async () => {
    const e = email.trim().toLowerCase();
    if (!isValidEmail(e)) return fail("Введите корректную Gmail-почту");
    setBusy(true);
    setErr("");
    try {
      const exists = await emailExists(e);
      if (!exists) {
        fail("Аккаунт с такой почтой не найден");
        return;
      }
      const c = generateCode();
      setSentCode(c);
      const res = await sendVerificationCode(e, c, "друг");
      setDevCode(res.dev ? c : "");
      setPhase("code");
      setResendIn(30);
      sfx.notify();
      toast(res.delivered ? "Код отправлен на почту" : "Dev-режим: код показан ниже", "ok");
    } catch {
      fail("Не удалось отправить код. Попробуй ещё раз");
    } finally {
      setBusy(false);
    }
  };

  const submit = async () => {
    if (code.length !== 6) return fail("Введи код из письма полностью");
    if (code !== sentCode) return fail("Неверный код подтверждения");
    const pw = password.replace(/^\s+|\s+$/g, "");
    if (!pw) return fail("Введи пароль");
    setBusy(true);
    setErr("");
    try {
      // проверяем и обрезанный, и «сырой» пароль — ловит старые аккаунты и пробелы
      const variants = pw === password ? [pw] : [pw, password];
      const hashes = await Promise.all(variants.map((p) => hashPassword(p)));
      const res = await checkLogin(email.trim().toLowerCase(), hashes);
      if (res.status === "ok") {
        sfx.success();
        signIn(res.profile);
        navigate("/", { replace: true });
        return;
      }
      if (res.status === "no-email") return fail("Аккаунт с такой почтой не найден — зарегистрируйся");
      if (res.status === "stale-index") return fail("Эта учётка была удалена вместе с базой. Зарегистрируйся заново — теперь получится");
      fail("Неверный пароль — проверь глазком, или нажми «Забыл пароль» внизу");
    } catch {
      fail("Ошибка входа. Проверь подключение");
    } finally {
      setBusy(false);
    }
  };

  const doReset = async () => {
    if (code.length !== 6) return fail("Введи код из письма полностью");
    if (code !== sentCode) return fail("Неверный код подтверждения");
    const np = newPw.replace(/^\s+|\s+$/g, "");
    if (np.length < 6) return fail("Новый пароль — минимум 6 символов");
    if (np !== newPw2.replace(/^\s+|\s+$/g, "")) return fail("Новые пароли не совпадают");
    setBusy(true);
    setErr("");
    try {
      const okReset = await resetPasswordByEmail(email.trim().toLowerCase(), np);
      if (!okReset) return fail("Аккаунт не найден — зарегистрируйся");
      const hashes = await Promise.all([hashPassword(np)]);
      const res = await checkLogin(email.trim().toLowerCase(), hashes);
      if (res.status === "ok") {
        sfx.success();
        signIn(res.profile);
        navigate("/", { replace: true });
        return;
      }
      fail("Пароль обновлён — попробуй войти ещё раз");
      setForgot(false);
    } catch {
      fail("Не удалось сбросить пароль");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="mb-5 text-center">
        <h2 className="font-display text-2xl font-bold text-cocoa">С возвращением</h2>
        <p className="mt-1.5 text-sm text-cocoa-soft">{EMAIL_CONFIG.templateId ? "Код придёт на почту" : "Войди по коду с почты"}</p>
      </div>

      <AnimatePresence mode="wait">
        {phase === "email" ? (
          <motion.div key="pe" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
            <Field label="Gmail">
              <div className="relative">
                <Mail size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                <input
                  className={cx("field pl-11", err && phase === "email" && "field-error")}
                  placeholder="you@gmail.com"
                  value={email}
                  autoFocus
                  autoComplete="email"
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && void sendCode()}
                />
              </div>
            </Field>
            <div key={shakeKey}>
              {err && <ErrorText text={err} />}
            </div>
            <PrimaryButton className="w-full" loading={busy} onClick={() => void sendCode()}>
              Отправить код <ArrowRight size={16} />
            </PrimaryButton>
            <button
              onClick={() => {
                setForgot(true);
                setErr("");
                sfx.tick();
              }}
              className="mx-auto flex w-fit items-center gap-1.5 text-[13px] font-semibold text-cocoa-soft transition-colors hover:text-orange-600"
            >
              <KeyRound size={13} /> Забыл пароль?
            </button>
          </motion.div>
        ) : (
          <motion.div key="pc" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
            <div className="text-center text-sm text-cocoa-soft">
              Код летит на <span className="font-semibold text-cocoa">{email}</span>
            </div>
            <div key={shakeKey}>
              <CodeInput value={code} onChange={setCode} autoFocus invalid={!!err} />
            </div>
            {devCode && <DevMailCard code={devCode} email={email} />}
            {forgot && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2.5 rounded-2xl border border-orange-200 bg-orange-50/80 px-4 py-2.5 text-[12.5px] font-semibold text-orange-700"
              >
                <KeyRound size={14} className="shrink-0" /> Режим восстановления: старый пароль не нужен — задай новый
              </motion.div>
            )}
            <AnimatePresence mode="wait">
              {!forgot ? (
                <motion.div key="lp" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
                  <Field label="Пароль">
                    <div className="relative">
                      <Lock size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                      <input
                        type={showPw ? "text" : "password"}
                        autoComplete="current-password"
                        className={cx("field pl-11 pr-12", err.includes("парол") && "field-error")}
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && void submit()}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPw((v) => !v)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-cocoa-soft transition-colors hover:text-orange-600"
                      >
                        {showPw ? <EyeOff size={17} /> : <Eye size={17} />}
                      </button>
                    </div>
                  </Field>
                  {err && <ErrorText text={err} />}
                  <PrimaryButton className="w-full" loading={busy} onClick={() => void submit()}>
                    <ShieldCheck size={17} /> Войти
                  </PrimaryButton>
                </motion.div>
              ) : (
                <motion.div key="fp" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
                  <Field label="Новый пароль">
                    <div className="relative">
                      <Lock size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                      <input
                        type={showPw ? "text" : "password"}
                        autoComplete="new-password"
                        className={cx("field pl-11 pr-12", err.includes("парол") && "field-error")}
                        placeholder="Придумай новый пароль"
                        value={newPw}
                        onChange={(e) => setNewPw(e.target.value)}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPw((v) => !v)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-cocoa-soft transition-colors hover:text-orange-600"
                      >
                        {showPw ? <EyeOff size={17} /> : <Eye size={17} />}
                      </button>
                    </div>
                  </Field>
                  <Field label="Confirm password">
                    <div className="relative">
                      <Lock size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                      <input
                        type={showPw ? "text" : "password"}
                        autoComplete="new-password"
                        className={cx(
                          "field pl-11 pr-11",
                          newPw2 && newPw2.trim() !== newPw.trim() && "field-error",
                          newPw2 && newPw2.trim() === newPw.trim() && "!border-emerald-400"
                        )}
                        placeholder="Повтори новый пароль"
                        value={newPw2}
                        onChange={(e) => setNewPw2(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && void doReset()}
                      />
                      {newPw2 && newPw2.trim() === newPw.trim() && (
                        <Check size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-emerald-500" />
                      )}
                    </div>
                  </Field>
                  {err && <ErrorText text={err} />}
                  <PrimaryButton className="w-full" loading={busy} onClick={() => void doReset()}>
                    <KeyRound size={16} /> Сохранить и войти
                  </PrimaryButton>
                </motion.div>
              )}
            </AnimatePresence>
            <div className="flex items-center justify-between text-sm">
              <button
                onClick={() => {
                  setPhase("email");
                  setCode("");
                  setErr("");
                  sfx.close();
                }}
                className="font-semibold text-cocoa-soft transition-colors hover:text-orange-600"
              >
                Сменить почту
              </button>
              <button
                disabled={resendIn > 0 || busy}
                onClick={() => void sendCode()}
                className="flex items-center gap-1.5 font-semibold text-orange-600 transition-colors hover:text-orange-500 disabled:text-cocoa-soft/50"
              >
                <RefreshCw size={13} className={resendIn > 0 ? "animate-spin" : ""} style={{ animationDuration: "2.5s" }} />
                {resendIn > 0 ? `Повтор через ${resendIn}с` : "Отправить ещё раз"}
              </button>
            </div>
            <button
              onClick={() => {
                setForgot((v) => !v);
                setErr("");
                if (forgot) sfx.close();
                else sfx.tick();
              }}
              className="mx-auto flex w-fit items-center gap-1.5 text-[13px] font-semibold transition-colors"
            >
              {forgot ? (
                <span className="flex items-center gap-1.5 text-orange-600 hover:text-orange-500">
                  <ShieldCheck size={13} /> Помню пароль — вернуться ко входу
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-cocoa-soft hover:text-orange-600">
                  <KeyRound size={13} /> Забыл пароль?
                </span>
              )}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ================= регистрация ================= */

const STEP_TITLES = ["Аккаунт", "Почта", "Профиль", "Пароль"];

function RegisterWizard() {
  const { signIn } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [shakeKey, setShakeKey] = useState(0);
  const [err, setErr] = useState("");

  // step 0
  const [nickname, setNickname] = useState("");
  const [usernameRaw, setUsernameRaw] = useState("");
  const [email, setEmail] = useState("");
  const [uErr, setUErr] = useState("");
  const [uOk, setUOk] = useState(false);
  const uTimer = useRef<number | null>(null);

  // step 1
  const [sentCode, setSentCode] = useState("");
  const [devCode, setDevCode] = useState("");
  const [code, setCode] = useState("");
  const [resendIn, setResendIn] = useState(0);

  // step 2
  const [avatar, setAvatar] = useState("");
  const [bio, setBio] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  // step 3
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);

  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);

  const fail = (msg: string) => {
    setErr(msg);
    setShakeKey((k) => k + 1);
    sfx.error();
  };

  // live-проверка username
  const onUsernameChange = (v: string) => {
    setUsernameRaw(v);
    setUOk(false);
    setUErr("");
    const u = normalizeUsername(v);
    if (!u) return;
    if (!isValidUsername(u)) {
      setUErr("3–20 символов: a-z, 0–9 и _");
      return;
    }
    setUErr("проверяем…");
    if (uTimer.current) window.clearTimeout(uTimer.current);
    uTimer.current = window.setTimeout(async () => {
      try {
        const taken = await usernameExists(u);
        if (taken) {
          setUErr("уже занят");
          setUOk(false);
        } else {
          setUErr("");
          setUOk(true);
          sfx.tick();
        }
      } catch {
        setUErr("");
      }
    }, 450);
  };

  const nextAccount = async () => {
    const u = normalizeUsername(usernameRaw);
    if (nickname.trim().length < 2) return fail("Никнейм — минимум 2 символа");
    if (!isValidUsername(u)) return fail("Проверь username: 3–20 символов");
    if (!isValidEmail(email)) return fail("Введите корректную Gmail-почту");
    setBusy(true);
    setErr("");
    try {
      const [taken, mailTaken] = await Promise.all([usernameExists(u), emailExists(email.trim().toLowerCase())]);
      if (taken) return fail("Этот username уже занят");
      if (mailTaken) return fail("Эта почта уже зарегистрирована");
      const c = generateCode();
      setSentCode(c);
      const res = await sendVerificationCode(email.trim().toLowerCase(), c, nickname.trim());
      setDevCode(res.dev ? c : "");
      setStep(1);
      setResendIn(30);
      sfx.open();
      toast(res.delivered ? "Код отправлен на почту" : "Dev-режим: код показан ниже", "ok");
    } catch {
      fail("Ошибка соединения. Попробуй ещё раз");
    } finally {
      setBusy(false);
    }
  };

  const resend = async () => {
    setBusy(true);
    try {
      const c = generateCode();
      setSentCode(c);
      setCode("");
      const res = await sendVerificationCode(email.trim().toLowerCase(), c, nickname.trim());
      setDevCode(res.dev ? c : "");
      setResendIn(30);
      sfx.notify();
    } finally {
      setBusy(false);
    }
  };

  const nextCode = () => {
    if (code.length !== 6) return fail("Введи код из 6 цифр");
    if (code !== sentCode) return fail("Код не совпадает — проверь письмо");
    setErr("");
    setStep(2);
    sfx.open();
  };

  const nextProfile = () => {
    if (bio.length > 140) return fail("Био — максимум 140 символов");
    setErr("");
    setStep(3);
    sfx.open();
  };

  const pwStrength = (): number => {
    let s = 0;
    if (password.length >= 6) s++;
    if (password.length >= 10) s++;
    if (/\d/.test(password)) s++;
    if (/[A-ZА-Я]/.test(password)) s++;
    return s;
  };

  const finish = async () => {
    const pw = password.replace(/^\s+|\s+$/g, "");
    if (pw.length < 6) return fail("Пароль — минимум 6 символов");
    if (pw !== confirm.replace(/^\s+|\s+$/g, "")) return fail("Пароли не совпадают");
    setBusy(true);
    setErr("");
    try {
      const u = normalizeUsername(usernameRaw);
      const display = u;
      const hash = await hashPassword(pw);
      const profile: Profile = await createUser({
        nickname: nickname.trim(),
        username: u,
        usernameDisplay: display,
        email: email.trim().toLowerCase(),
        bio: bio.trim(),
        avatar,
        passwordHash: hash,
      });
      sfx.success();
      toast(`Добро пожаловать, ${profile.nickname}!`, "ok");
      signIn(profile);
      navigate("/", { replace: true });
    } catch {
      fail("Не получилось создать аккаунт. Попробуй ещё раз");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="text-left">
      {/* прогресс */}
      <div className="mb-6 flex items-center gap-1.5">
        {STEP_TITLES.map((t, i) => (
          <div key={t} className="flex flex-1 flex-col gap-1.5">
            <div className="h-1.5 overflow-hidden rounded-full bg-orange-100">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-orange-500 to-amber-400"
                initial={false}
                animate={{ width: i < step ? "100%" : i === step ? "55%" : "0%" }}
                transition={{ duration: 0.4, ease: "easeOut" }}
              />
            </div>
            <span className={cx("text-[10px] font-bold uppercase tracking-wider", i <= step ? "text-orange-600" : "text-cocoa-soft/50")}>
              {t}
            </span>
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* ---------- шаг 0: аккаунт ---------- */}
        {step === 0 && (
          <motion.div key="s0" initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.22 }} className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-cocoa">Создай аккаунт</h2>
            <Field label="NickName">
              <div className="relative">
                <User size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                <input className="field pl-11" placeholder="Как тебя называть" value={nickname} autoFocus onChange={(e) => setNickname(e.target.value)} maxLength={40} />
              </div>
            </Field>
            <Field label="UserName" error={uErr}>
              <div className="relative">
                <AtSign size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                <input
                  className={cx("field pl-11 pr-11", uErr && !uErr.includes("…") && "field-error", uOk && "!border-emerald-400")}
                  placeholder="bordgram"
                  value={usernameRaw}
                  onChange={(e) => onUsernameChange(e.target.value)}
                  maxLength={20}
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2">
                  {uOk ? <BadgeCheck size={18} className="text-emerald-500" /> : uErr.includes("…") ? <Spinner size={15} /> : null}
                </span>
              </div>
            </Field>
            <Field label="Gmail">
              <div className="relative">
                <Mail size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                <input className="field pl-11" placeholder="you@gmail.com" value={email} autoComplete="email" onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => e.key === "Enter" && void nextAccount()} />
              </div>
            </Field>
            <div key={shakeKey}>{err && <ErrorText text={err} />}</div>
            <PrimaryButton className="w-full" loading={busy} onClick={() => void nextAccount()}>
              Получить код <ArrowRight size={16} />
            </PrimaryButton>
          </motion.div>
        )}

        {/* ---------- шаг 1: код ---------- */}
        {step === 1 && (
          <motion.div key="s1" initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.22 }} className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-cocoa">Проверь почту</h2>
            <p className="text-sm text-cocoa-soft">
              Мы отправили 6-значный код на <span className="font-semibold text-cocoa">{email}</span>
            </p>
            <div key={shakeKey} className="py-1">
              <CodeInput value={code} onChange={setCode} autoFocus invalid={!!err} />
            </div>
            {devCode && <DevMailCard code={devCode} email={email} />}
            {err && <ErrorText text={err} />}
            <PrimaryButton className="w-full" onClick={nextCode}>
              Подтвердить <ArrowRight size={16} />
            </PrimaryButton>
            <div className="flex items-center justify-between text-sm">
              <button onClick={() => { setStep(0); sfx.close(); }} className="flex items-center gap-1 font-semibold text-cocoa-soft transition-colors hover:text-orange-600">
                <ArrowLeft size={14} /> Назад
              </button>
              <button disabled={resendIn > 0 || busy} onClick={() => void resend()} className="flex items-center gap-1.5 font-semibold text-orange-600 transition-colors hover:text-orange-500 disabled:text-cocoa-soft/50">
                <RefreshCw size={13} /> {resendIn > 0 ? `Повтор через ${resendIn}с` : "Отправить ещё раз"}
              </button>
            </div>
          </motion.div>
        )}

        {/* ---------- шаг 2: профиль ---------- */}
        {step === 2 && (
          <motion.div key="s2" initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.22 }} className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-cocoa">Оформи профиль</h2>
            <div className="flex items-center gap-4">
              <motion.div whileHover={{ scale: 1.04 }} className="relative">
                <Avatar src={avatar} name={nickname || "?"} seed={normalizeUsername(usernameRaw)} size={76} />
                {avatar && (
                  <button
                    onClick={() => {
                      setAvatar("");
                      sfx.tick();
                    }}
                    className="btn-press absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-white shadow-warm"
                    title="Убрать фото"
                  >
                    <Trash2 size={11} />
                  </button>
                )}
              </motion.div>
              <div className="flex-1">
                <button
                  onClick={() => fileRef.current?.click()}
                  className="btn-press flex items-center gap-2 rounded-full border-2 border-dashed border-orange-300 bg-white/60 px-4 py-2.5 text-sm font-semibold text-orange-600 transition-colors hover:border-orange-500 hover:bg-orange-50"
                >
                  <ImagePlus size={16} /> Загрузить аватарку
                </button>
                <p className="mt-2 text-xs text-cocoa-soft">Или оставь так — сделаем тёплый градиент</p>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    try {
                      setAvatar(await fileToAvatar(f));
                      sfx.success();
                    } catch {
                      toast("Не удалось прочитать картинку", "err");
                    }
                    e.target.value = "";
                  }}
                />
              </div>
            </div>
            <Field label="Био">
              <textarea
                className="field min-h-[96px] resize-none"
                placeholder="Пара слов о себе…"
                value={bio}
                maxLength={140}
                onChange={(e) => setBio(e.target.value)}
              />
            </Field>
            <div className="-mt-2 text-right text-xs text-cocoa-soft/70">{bio.length}/140</div>
            {err && <ErrorText text={err} />}
            <div className="flex gap-3">
              <button onClick={() => { setStep(1); sfx.close(); }} className="btn-press flex items-center gap-1.5 rounded-full bg-orange-100/70 px-5 py-3.5 text-sm font-bold text-cocoa-soft transition-colors hover:text-orange-600">
                <ArrowLeft size={15} />
              </button>
              <PrimaryButton className="flex-1" onClick={nextProfile}>
                Дальше <ArrowRight size={16} />
              </PrimaryButton>
            </div>
          </motion.div>
        )}

        {/* ---------- шаг 3: пароль ---------- */}
        {step === 3 && (
          <motion.div key="s3" initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.22 }} className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-cocoa">Защити аккаунт</h2>
            <Field label="Password">
              <div className="relative">
                <Lock size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                <input
                  type={showPw ? "text" : "password"}
                  autoComplete="new-password"
                  className="field pl-11 pr-12"
                  placeholder="Придумай пароль"
                  value={password}
                  autoFocus
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button type="button" onClick={() => setShowPw((v) => !v)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-cocoa-soft transition-colors hover:text-orange-600">
                  {showPw ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
              <div className="mt-2 flex items-center gap-1.5">
                {Array.from({ length: 4 }).map((_, i) => (
                  <motion.span
                    key={i}
                    initial={false}
                    animate={{ scaleY: i < pwStrength() ? 1 : 0.55, opacity: i < pwStrength() ? 1 : 0.35 }}
                    className={cx("h-1.5 flex-1 origin-left rounded-full", i < pwStrength() ? (pwStrength() <= 2 ? "bg-amber-400" : "bg-emerald-500") : "bg-orange-200")}
                  />
                ))}
                <span className="ml-1 text-[11px] font-bold text-cocoa-soft">
                  {pwStrength() <= 1 ? "слабый" : pwStrength() <= 3 ? "норм" : "надёжный"}
                </span>
              </div>
            </Field>
            <Field label="Confirm password">
              <div className="relative">
                <Lock size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-cocoa-soft/70" />
                <input
                  type={showPw ? "text" : "password"}
                  autoComplete="new-password"
                  className={cx("field pl-11", confirm && confirm !== password && "field-error", confirm && confirm === password && "!border-emerald-400")}
                  placeholder="Повтори пароль"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && void finish()}
                />
                {confirm && confirm === password && <Check size={17} className="absolute right-4 top-1/2 -translate-y-1/2 text-emerald-500" />}
              </div>
            </Field>
            <div key={shakeKey}>{err && <ErrorText text={err} />}</div>
            <div className="flex gap-3">
              <button onClick={() => { setStep(2); sfx.close(); }} className="btn-press flex items-center gap-1.5 rounded-full bg-orange-100/70 px-5 py-3.5 text-sm font-bold text-cocoa-soft transition-colors hover:text-orange-600">
                <ArrowLeft size={15} />
              </button>
              <PrimaryButton className="flex-1" loading={busy} onClick={() => void finish()}>
                <Sparkles size={16} /> Создать аккаунт
              </PrimaryButton>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
