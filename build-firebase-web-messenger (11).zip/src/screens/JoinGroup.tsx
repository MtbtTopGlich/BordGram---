import { useEffect, useState } from "react";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { Spinner, WarmBackdrop } from "../components/bits";
import { JoinBanner } from "../components/GroupModals";
import { useAuth, useToast } from "../state";
import { getGroupByInvite, joinGroup, normalizeInvite, type Group } from "../lib/groups";
import { sfx } from "../lib/sounds";

export const AFTER_LOGIN_KEY = "bg_after_login";

export default function JoinGroup() {
  const { code = "" } = useParams();
  const { user, ready } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [group, setGroup] = useState<Group | null>(null);
  const [state, setState] = useState<"loading" | "ok" | "none">("loading");
  const [busy, setBusy] = useState(false);

  // не вошёл — запомним ссылку и отправим на вход
  useEffect(() => {
    if (ready && !user) {
      try {
        localStorage.setItem(AFTER_LOGIN_KEY, `/join/${normalizeInvite(code)}`);
      } catch {
        /* noop */
      }
    }
  }, [ready, user, code]);

  useEffect(() => {
    if (!user) return;
    let alive = true;
    void getGroupByInvite(normalizeInvite(code)).then((g) => {
      if (!alive) return;
      setGroup(g);
      setState(g ? "ok" : "none");
    });
    return () => {
      alive = false;
    };
  }, [code, user]);

  if (!ready) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner size={26} />
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;

  // уже участник — сразу в группу
  if (group && group.members.includes(user.uid)) {
    return <Navigate to={`/g/${group.id}`} replace />;
  }

  const join = async () => {
    if (!group) return;
    setBusy(true);
    try {
      await joinGroup(group.id, user);
      sfx.success();
      toast(`Ты вступил в «${group.title}»`, "ok");
      navigate(`/g/${group.id}`, { replace: true });
    } catch {
      toast("Не удалось вступить в группу", "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="relative h-full">
      <WarmBackdrop />
      {state === "loading" && (
        <div className="flex h-full items-center justify-center">
          <Spinner size={26} />
        </div>
      )}
      {state === "none" && (
        <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center">
          <h2 className="font-display text-xl font-bold">Ссылка недействительна</h2>
          <p className="max-w-xs text-sm text-cocoa-soft">
            Приглашение устарело или группа была удалена
          </p>
          <button
            onClick={() => navigate("/")}
            className="btn-press mt-2 rounded-full bg-gradient-to-r from-orange-600 to-amber-500 px-6 py-3 text-sm font-bold text-white shadow-orangeGlow"
          >
            На главную
          </button>
        </div>
      )}
      {state === "ok" && group && (
        <JoinBanner group={group} busy={busy} onJoin={() => void join()} onCancel={() => navigate("/")} />
      )}
    </div>
  );
}
